let currentPage = 1;
const rowsPerPage = 7;
let usersData = [];
let filteredData = [];

// Load Data
function loadTable() {
  const xhttp = new XMLHttpRequest();
  xhttp.open("GET", "./assets/php/get-users.php", true);
  xhttp.send();
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      usersData = JSON.parse(this.responseText);
      filteredData = [...usersData]; // Start with full data
      renderTable(currentPage);
      renderPagination(filteredData.length);
    }
  };
}

// Render Table
function renderTable(page) {
  currentPage = page;
  const start = (page - 1) * rowsPerPage;
  const end = start + rowsPerPage;
  const paginatedItems = filteredData.slice(start, end);

  let trHTML = "";

  if (paginatedItems.length === 0) {
    trHTML += `<tr><td colspan="12" class="text-center">No accounts found</td></tr>`;
  } else {
    for (let object of paginatedItems) {
      trHTML += "<tr>";
      trHTML += "<td>" + object["account_id"] + "</td>";
      trHTML += '<td><img width="50px" src="' + object["avatar"] + '" class="avatar"></td>';
      trHTML += "<td>" + object["first_name"] + "</td>";
      trHTML += "<td>" + object["last_name"] + "</td>";
      trHTML += "<td>" + object["email"] + "</td>";
      trHTML += "<td>" + object["phone_number"] + "</td>";
      trHTML += "<td>" + object["account_type"] + "</td>";
      trHTML += "<td>" + object["Date_of_birth"] + "</td>";
      trHTML += "<td>" + object["create_at"] + "</td>";
      trHTML += "<td>" + object["active_state"] + "</td>";
      trHTML += "<td>" + object["gender"] + "</td>";
      trHTML +=
        '<td><button class="btn btn-outline-secondary" onclick="showUserEditBox(' +
        object["account_id"] +
        ')">Edit</button> ';
      trHTML +=
        '<button class="btn btn-outline-danger" onclick="userDelete(' +
        object["account_id"] +
        ')">Del</button></td>';
      trHTML += "</tr>";
    }
  }


  document.getElementById("mytable").innerHTML = trHTML;
}

// Render Pagination
function renderPagination(totalItems) {
  const totalPages = Math.ceil(totalItems / rowsPerPage);
  let paginationHTML = "";

  paginationHTML += `<li class="page-item ${currentPage === 1 ? "disabled" : ""}">
      <a class="page-link" href="#" onclick="changePage(${currentPage - 1})">Previous</a>
    </li>`;

  for (let i = 1; i <= totalPages; i++) {
    paginationHTML += `<li class="page-item ${currentPage === i ? "active" : ""}">
      <a class="page-link" href="#" onclick="changePage(${i})">${i}</a>
    </li>`;
  }

  paginationHTML += `<li class="page-item color-greey ${currentPage === totalPages ? "disabled" : ""}">
      <a class="page-link" href="#" onclick="changePage(${currentPage + 1})">Next</a>
    </li>`;

  document.getElementById("pagination").innerHTML = paginationHTML;
}

// Page Change
function changePage(page) {
  const totalPages = Math.ceil(filteredData.length / rowsPerPage);
  if (page >= 1 && page <= totalPages) {
    renderTable(page);
    renderPagination(filteredData.length);
  }
}

// Filter/Search
function filterTable(query) {
  query = query.toLowerCase();
  filteredData = usersData.filter((user) => {
    return (
      user.account_id.toString().includes(query) ||
      user.first_name.toLowerCase().includes(query) ||
      user.last_name.toLowerCase().includes(query) ||
      user.email.toLowerCase().includes(query) ||
      user.phone_number.toLowerCase().includes(query) ||
      user.account_type.toLowerCase().includes(query)
    );
  });

  currentPage = 1; // Reset to first page
  renderTable(currentPage);
  renderPagination(filteredData.length);
}

function changePage(page) {
  const totalPages = Math.ceil(usersData.length / rowsPerPage);
  if (page >= 1 && page <= totalPages) {
    currentPage = page;
    renderTable(currentPage);
    renderPagination(usersData.length);
  }
}


function showUserCreateBox() {
  Swal.fire({
    title: "Create Account",
    html:
      '<div class="createUserForm">' +
      '<input id="account_id" type="hidden">' +
      '<div class="Name">' +
      '<input id="first_name" class=" swal2-input input_name " type="text" placeholder="First name">' +
      '<input id="last_name" class="swal2-input input_name" type="text" placeholder="Last name">' +
      '</div>' +
      '<input id="email" type="email" class="swal2-input input_email" placeholder="Email">' +
      '<input id="password" class="swal2-input input_password" type="password" placeholder="Password">' +
      '<input id="phone_number" class="swal2-input phone_number" placeholder="Phone Number">' +

      '<input id="createimage" type="file" class="swal2-file">' +
      '<input type="hidden" id="CreatedImageUrl" name="uploadedImageUrl" />' +



      '<div class="Name">' +
      '<div class ="select_with_lable">'+
      '<label class="lable_name" for="gender">Gender</label>'+
      '<select id="gender" class="swal2-input select">' +
      '<option class="option" value="" disabled selected>Select gender</option>' +
      '<option  class="option" value="Male">Male</option>' +
      '<option class="option"  value="Female">Female</option>' +
      '</select>' +
      '</div>' +
      '<div class ="select_with_lable">'+
      '<label class="lable_name" for="Date_of_birth">Date_of_birth</label>'+
      '<input id="Date_of_birth" class="swal2-input select" type="date" placeholder="Date of birth">' +
      '</div>' +
      '</div>' +


      '<div class="Name">' +
      '<div class ="select_with_lable">'+
      '<label class="lable_name" for="is_active">Active state</label>'+
      '<select id="is_active" class="swal2-input select"  placeholder="Date of birth">' +
      '<option class="option" value="" disabled selected >Select active state</option>' +
      '<option class="option" value="Active">Active</option>' +
      '<option class="option" value="Non-Active">Non-Active</option>' +
      '</select>' +
      '</div>'+

      '<div class ="select_with_lable">'+
      '<label class="lable_name" for="account_type">Account type</label>'+
      '<select id="account_type" class="swal2-input select">' +
      '<option class="option" value="" disabled selected>Select account type</option>' +
      '<option class="option" value="Customer">Customer</option>' +
      '<option class="option" value="Employee">Employee</option>' +
      '</select>' +
      '<div>'+
      '</div>' +

      '</div>',
    focusConfirm: false,
    preConfirm: () => {
      const file = document.getElementById('createimage').files[0];
      if (file) {
        return uploadImage(); // سترجع Promise
      } else {
        return userCreate();
      }
    }
  });
}


function userCreate() {
  let image = document.getElementById("CreatedImageUrl").value.trim();
  const first_name = document.getElementById("first_name").value.trim();
  const last_name = document.getElementById("last_name").value.trim();
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value.trim();
  const phone_number = document.getElementById("phone_number").value.trim();
  const account_type = document.getElementById("account_type").value;
  const date_of_birth = document.getElementById("Date_of_birth").value.trim();
  const is_active = document.getElementById("is_active").value.trim();
  const gender = document.getElementById("gender").value;
  const phoneRegex = /^[0-9]{1,10}$/;

  if (!first_name || !last_name || !account_type || !date_of_birth || !is_active || !gender) {
    Swal.fire("Please fill in all fields.");
    return;
  }

  else if (!phoneRegex.test(phone_number)) {
    Swal.fire("Phone number must be digits only and no more than 10 digits.");
    return;
  }
  else {
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/;
    if (!passwordRegex.test(password)) {
      Swal.fire("Password must be at least 8 characters and include upper/lowercase letters, a number, and a symbol.");
      return;
    }
  }
  if (!image) {
    image = " ";
  }

  const xhttp = new XMLHttpRequest();
  xhttp.open("POST", "./assets/php/create-user.php", true);
  xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
  xhttp.send(
    JSON.stringify({
      first_name: first_name,
      last_name: last_name,
      email: email,
      phone_number: phone_number,
      account_type: account_type,
      date_of_birth: date_of_birth,
      is_active: is_active,
      password: password,
      gender: gender,
      image: image,
    }
    ));

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      const objects = JSON.parse(this.responseText);
      Swal.fire(objects["message"]);
      loadTable();
    }
  };
}

let upload_flage = 0;
function showUserEditBox(id) {
  upload_flage = 1;

  const xhttp = new XMLHttpRequest();
  xhttp.open("GET", "./assets/php/get-user.php?id=" + id, true);
  xhttp.send();
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      const user = JSON.parse(this.responseText).user;

      Swal.fire({
        title: "Edit Account",
        html: `
        <div class="createUserForm">
        <input id="account_id" type="hidden" value="${user.account_id}">
        <div class="Name">
        <input id="first_name" class="swal2-input input_name " placeholder="First Name" value="${user.first_name || ''}">
        <input id="last_name" class="swal2-input input_name " placeholder="Last Name" value="${user.last_name || ''}">
        </div>
        <input id="email" class="swal2-input input_email" type"email" placeholder="Email" value="${user.email || ''}">
        <input id="password" type="password" class="swal2-input input_password" placeholder="New Password (leave blank to keep)">
        <input id="phone_number" class="swal2-input phone_number" placeholder="Phone Number" value="${user.phone_number || ''}">

       
        <input id="image" type="file" class="swal2-file" >
        <input type="hidden" id="uploadedImageUrl" name="uploadedImageUrl" />
        
        <div class="Name">
        <div class ="select_with_lable">
        <label class="lable_name" for="gender">Gender</label>
        <select id="gender" class="swal2-input select">
          <option class="option" value="" disabled>Select gender</option>
          <option class="option" value="Male" ${user.gender === 'Male' ? 'selected' : ''}>Male</option>
          <option class="option" value="Female" ${user.gender === 'Female' ? 'selected' : ''}>Female</option>
        </select>
        </div>
        <div class ="select_with_lable">
         <label class="lable_name" for="data_of_birth">Data_of_birth</label>
        <input id="data_of_birth" type="date" class="swal2-input select" value="${user.data_of_birth || ''}">
        </div>
        </div>

        <div class="Name">

         <div class ="select_with_lable">
         <label class="lable_name" for="account_type">Account type</label>
        <select id="account_type" class="swal2-input select">
          <option class="option" value="" disabled>Select account type</option>
          <option class="option" value="Customer" ${user.account_type === 'Customer' ? 'selected' : ''}>Customer</option>
          <option class="option" value="Employee" ${user.account_type === 'Employee' ? 'selected' : ''}>Employee</option>
        </select>
        </div>

         <div class ="select_with_lable">
         <label class="lable_name" for="is_active">Active state</label>
        <select id="is_active" class="swal2-input select">
          <option  class="option" value="" disabled>Select active state</option>
          <option  class="option" value="Active" ${user.is_active === 'Active' ? 'selected' : ''}>Active</option>
          <option  class="option" value="Non-Active" ${user.is_active === 'Non-Active' ? 'selected' : ''}>Non-Active</option>
        </select>
        </div>
        </div>

        </div>
      `,
        focusConfirm: false,
        preConfirm: () => {
          let file = document.getElementById('image').files[0];

          if (file == undefined) {
            document.getElementById("uploadedImageUrl").value = user.image;
            return userEdit();
          } else {
            return uploadImage();
          }
        }

      });
    }
  };
}


function userEdit() {
  const data = {
    account_id: document.getElementById("account_id").value.trim(),
    first_name: document.getElementById("first_name").value.trim(),
    last_name: document.getElementById("last_name").value.trim(),
    email: document.getElementById("email").value.trim(),
    phone_number: document.getElementById("phone_number").value.trim(),
    account_type: document.getElementById("account_type").value,
    data_of_birth: document.getElementById("data_of_birth").value,
    image: document.getElementById("uploadedImageUrl").value.trim(),
    is_active: document.getElementById("is_active").value,
    gender: document.getElementById("gender").value,
    password: document.getElementById("password").value.trim()

  };

  // ✅ Basic validation
  if (!data.first_name || !data.last_name || !data.email || !data.phone_number) {
    Swal.fire("Validation Error", "Please fill in all required fields.", "warning");
    return;
  }

  // ✅ Email format
  const emailRegex = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
  if (!emailRegex.test(data.email)) {
    Swal.fire("Validation Error", "Invalid email format.", "warning");
    return;
  }

  // ✅ Phone number format (digits only, 7–15 length)
  const phoneRegex = /^\d{7,15}$/;
  if (!phoneRegex.test(data.phone_number)) {
    Swal.fire("Validation Error", "Invalid phone number. Use digits only (7-15 characters).", "warning");
    return;
  }

  // ✅ Password 
  if (data.password && !/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/.test(data.password)) {
    Swal.fire(
      "Validation Error",
      "Password must be at least 8 characters and include upper/lowercase letters, a number, and a special character.",
      "warning"
    );
    return;
  }



  // ✅ account_type, gender, and is_active required
  if (!data.account_type || !data.gender || !(data.is_active)) {
    Swal.fire("Validation Error", "Please select account type, gender, and active state.", "warning");
    return;
  }

  // ✅ Send data if valid
  const xhttp = new XMLHttpRequest();
  xhttp.open("PUT", "./assets/php/update-user.php", true);
  xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
  xhttp.send(JSON.stringify(data));

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      try {
        const res = JSON.parse(this.responseText);
        if (this.status == 200 && !res.error) {
          Swal.fire("Success", res.message, "success");
          loadTable();
        } else {
          Swal.fire("Error", res.error || "Update failed", "error");
        }
      } catch (err) {
        Swal.fire("Error", "Invalid server response.", "error");

      }
    }
  };
}


function uploadImage() {
  return new Promise((resolve, reject) => {
    let fileInput;

    if (upload_flage == 1) {
      fileInput = Swal.getPopup().querySelector('#image');
    } else {
      fileInput = Swal.getPopup().querySelector('#createimage');
    }

    const file = fileInput?.files?.[0];

    if (!file) {
      Swal.fire("Validation Error", "Please select an image.", "warning");
      return reject(); // Reject if no file selected
    }

    const formData = new FormData();
    formData.append("file", file);
    formData.append("upload_preset", "unsigned_user_uploads");

    fetch("https://api.cloudinary.com/v1_1/dpjwslspm/image/upload", {
      method: "POST",
      body: formData
    })
      .then(res => res.json())
      .then(data => {
        if (data.secure_url) {
          if (upload_flage == 1) {
            document.getElementById('uploadedImageUrl').value = data.secure_url;
          } else {
            document.getElementById('CreatedImageUrl').value = data.secure_url;
          }

          console.log("Uploaded Image URL:", data.secure_url);

          if (upload_flage == 1) {
            userEdit();
            upload_flage = 0;
          } else {
            userCreate();
          }

          resolve(data.secure_url); // Resolve promise with URL
        } else {
          Swal.fire("Upload Error", data.error?.message || "Failed to upload image.", "error");
          reject();
        }
      })
      .catch(err => {
        console.error("Upload error:", err);
        Swal.fire("Upload Error", "Something went wrong while uploading.", "error");
        reject();
      });
  });
}

function userDelete(id) {
  Swal.fire({
    title: "Are you sure?",
    text: "This action cannot be undone!",
    icon: "warning",
    showCancelButton: true,
    confirmButtonText: "Yes, delete it!",
  }).then((result) => {
    if (result.isConfirmed) {
      const xhttp = new XMLHttpRequest();
      xhttp.open("DELETE", "./assets/php/delete-user.php", true);
      xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
      xhttp.send(JSON.stringify({ id: id }));
      console.log(id);
      xhttp.onreadystatechange = function () {
        if (this.readyState == 4) {
          const res = JSON.parse(this.responseText);
          if (this.status === 200 && !res.error) {
            Swal.fire("Deleted!", res.message, "success");
            loadTable();
          } else {
            Swal.fire("Error", res.error || "Failed to delete user", "error");
          }
        }
      };
    }
  });
}


loadTable();
