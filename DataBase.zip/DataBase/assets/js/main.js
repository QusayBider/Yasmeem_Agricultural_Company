

(function () {
  "use strict";

  /**
   * Apply .scrolled class to the body as the page is scrolled down
   */
  function toggleScrolled() {
    const selectBody = document.querySelector('body');
    const selectHeader = document.querySelector('#header');
    if (!selectHeader.classList.contains('scroll-up-sticky') && !selectHeader.classList.contains('sticky-top') && !selectHeader.classList.contains('fixed-top')) return;
    window.scrollY > 100 ? selectBody.classList.add('scrolled') : selectBody.classList.remove('scrolled');
  }

  document.addEventListener('scroll', toggleScrolled);
  window.addEventListener('load', toggleScrolled);

  /**
   * Scroll up sticky header to headers with .scroll-up-sticky class
   */
  let lastScrollTop = 0;
  window.addEventListener('scroll', function () {
    const selectHeader = document.querySelector('#header');
    if (!selectHeader.classList.contains('scroll-up-sticky')) return;

    let scrollTop = window.pageYOffset || document.documentElement.scrollTop;

    if (scrollTop > lastScrollTop && scrollTop > selectHeader.offsetHeight) {
      selectHeader.style.setProperty('position', 'sticky', 'important');
      selectHeader.style.top = `-${header.offsetHeight + 50}px`;
    } else if (scrollTop > selectHeader.offsetHeight) {
      selectHeader.style.setProperty('position', 'sticky', 'important');
      selectHeader.style.top = "0";
    } else {
      selectHeader.style.removeProperty('top');
      selectHeader.style.removeProperty('position');
    }
    lastScrollTop = scrollTop;
  });

  /**
   * Mobile nav toggle
   */
  const mobileNavToggleBtn = document.querySelector('.mobile-nav-toggle');

  function mobileNavToogle() {
    document.querySelector('body').classList.toggle('mobile-nav-active');
    mobileNavToggleBtn.classList.toggle('bi-list');
    mobileNavToggleBtn.classList.toggle('bi-x');
  }
  mobileNavToggleBtn.addEventListener('click', mobileNavToogle);

  /**
   * Hide mobile nav on same-page/hash links
   */
  document.querySelectorAll('#navmenu a').forEach(navmenu => {
    navmenu.addEventListener('click', () => {
      if (document.querySelector('.mobile-nav-active')) {
        mobileNavToogle();
      }
    });

  });

  /**
   * Toggle mobile nav dropdowns
   */
  document.querySelectorAll('.navmenu .toggle-dropdown').forEach(navmenu => {
    navmenu.addEventListener('click', function (e) {
      e.preventDefault();
      this.parentNode.classList.toggle('active');
      this.parentNode.nextElementSibling.classList.toggle('dropdown-active');
      e.stopImmediatePropagation();
    });
  });

  /**
   * Preloader
   */
  const preloader = document.querySelector('#preloader');
  if (preloader) {
    window.addEventListener('load', () => {
      preloader.remove();
    });
  }

  /**
   * Scroll top button
   */
  let scrollTop = document.querySelector('.scroll-top');

  function toggleScrollTop() {
    if (scrollTop) {
      window.scrollY > 100 ? scrollTop.classList.add('active') : scrollTop.classList.remove('active');
    }
  }
  scrollTop.addEventListener('click', (e) => {
    e.preventDefault();
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  });

  window.addEventListener('load', toggleScrollTop);
  document.addEventListener('scroll', toggleScrollTop);

  /**
   * Animation on scroll function and init
   */
  function aosInit() {
    AOS.init({
      duration: 600,
      easing: 'ease-in-out',
      once: true,
      mirror: false
    });
  }
  window.addEventListener('load', aosInit);

  /**
   * Auto generate the carousel indicators
   */
  document.querySelectorAll('.carousel-indicators').forEach((carouselIndicator) => {
    carouselIndicator.closest('.carousel').querySelectorAll('.carousel-item').forEach((carouselItem, index) => {
      if (index === 0) {
        carouselIndicator.innerHTML += `<li data-bs-target="#${carouselIndicator.closest('.carousel').id}" data-bs-slide-to="${index}" class="active"></li>`;
      } else {
        carouselIndicator.innerHTML += `<li data-bs-target="#${carouselIndicator.closest('.carousel').id}" data-bs-slide-to="${index}"></li>`;
      }
    });
  });

  /**
   * Init swiper sliders
   */
  function initSwiper() {
    document.querySelectorAll(".init-swiper").forEach(function (swiperElement) {
      let config = JSON.parse(
        swiperElement.querySelector(".swiper-config").innerHTML.trim()
      );

      if (swiperElement.classList.contains("swiper-tab")) {
        initSwiperWithCustomPagination(swiperElement, config);
      } else {
        new Swiper(swiperElement, config);
      }
    });
  }

  window.addEventListener("load", initSwiper);

  /**
   * Initiate glightbox
   */
  const glightbox = GLightbox({
    selector: '.glightbox'
  });

})();

/** 
 this is temp arrry for test the hero section of swiper
 */

let herosection = [
  {
    "Image": "./assets/img/hero_1.jpg",
    "Title": "Farming is the best solution for world starvation",
    "Description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
  },
  {
    "Image": "./assets/img/hero_2.jpg",
    "Title": "Sustainable agriculture for a better future",
    "Description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
  }
];

const herosectionswiperImge = document.getElementById("hero-carousel");

if (herosectionswiperImge) {
  const slidesofSwiperHome = herosection.map((Slide, index) => {
    return `
    <div class="carousel-item  ${index === 0 ? "active" : ""}">
      <img src="${Slide.Image}" alt="${Slide.Title}">
      <div class="carousel-container">
        <h2>${Slide.Title}</h2>
        <p>${Slide.Description}</p>
      </div>
    </div>
    `
  }).join('');

  herosectionswiperImge.insertAdjacentHTML("afterbegin", slidesofSwiperHome);
}


/** 
 this is temp arrry for test the Services Section of swiper
 */
const servicesSectionTitle = document.getElementById("section-of-service-Title");
const servicesSectionDescription = document.getElementById("section-of-service-Description");
let swiperWrapperOfServise = [
  {
    "Image": "assets/img/img_sq_1.jpg",
    "serviceItemTitle": "Qusay3",
    "Link": "#",
    "serviceItemCategory": "Test3"
  },
  {
    "Image": "assets/img/img_sq_3.jpg",
    "serviceItemTitle": "Qusay2",
    "Link": "#",
    "serviceItemCategory": "Test2"
  },
  {
    "Image": "assets/img/img_sq_4.jpg",
    "serviceItemTitle": "Qusay1",
    "Link": "#",
    "serviceItemCategory": "Test1"
  },
  {
    "Image": "assets/img/img_sq_5.jpg",
    "serviceItemTitle": "Qusay",
    "Link": "#",
    "serviceItemCategory": "Test"
  }
];
const service_swiper_wrapper = document.getElementById("service_swiper");
servicesSectionTitle.innerHTML = "SERVICES";
servicesSectionDescription.innerHTML = "Providing Fresh Produce Every Single Day";

const service_swiper_wrapper_slider = swiperWrapperOfServise.map((service_slide, index) => {
  return `
                <div class="swiper-slide">
                  <div class="service-item">
                    <div class="service-item-contents">
                      <a href="${service_slide.Link}">
                        <span class="service-item-category">${service_slide.serviceItemCategory}</span>
                        <h2 class="service-item-title">${service_slide.serviceItemTitle}</h2>
                      </a>
                    </div>
                    <img src="${service_slide.Image}" alt="Image" class="img-fluid">
                  </div>
                </div>
  `

}).join('');
service_swiper_wrapper.innerHTML += service_swiper_wrapper_slider;


/** 
 this is temp arrry for test the About Section of swiper
 */
const About_Section_Image_add = document.getElementById("About_Section_Image");
const About_Section_Image = "./assets/img/img_long_5.jpg";
const About_Section_FirstQustion = document.getElementById("About_Section_FirstQustion");
const About_Section_Ttile = document.getElementById("About_Section_Ttile");
const About_Section_Description = document.getElementById("About_Section_Description");
About_Section_FirstQustion.innerHTML = "Why Choose Us";
About_Section_Ttile.innerHTML = "More than <strong>50 year experience</strong> in agricultureindustry";
About_Section_Description.innerHTML = "Reprehenderit, odio laboriosam? Blanditiis quae ullam quasi illumminima nostrum perspiciatis error consequatur sit nulla.";
About_Section_Image_add.innerHTML = `<img src="${About_Section_Image}" alt="Image " class="img-fluid img-overlap" data-aos="zoom-out"></img>`;
let About_Section_Features_data = [
  {
    "Image": "bi bi-cloud-rain me-4 display-6",
    "Title": "Plants needs rain",
    "Description": "Lorem ipsum dolor sit amet."
  },
  {
    "Image": "bi bi-heart me-4 display-6",
    "Title": "Love organic foods",
    "Description": "Lorem ipsum dolor sit amet."
  },
  {
    "Image": "bi bi-shop me-4 display-6",
    "Title": "Sell vegies",
    "Description": "Lorem ipsum dolor sit amet."
  }
];
const About_Section_Features = document.getElementById("About_Section_Features");

const About_Section_Features_options = About_Section_Features_data.map((option, index) => {
  return `<div class="col-lg-12 d-flex align-items-start mb-4">
                  <i class="${option.Image}"></i>
                  <div>
                    <h4 class="m-0 h5 text-white">${option.Title}</h4>
                    <p class="text-white opacity-50">${option.Description}</p>
                  </div>
                </div>`
}).join('');
About_Section_Features.innerHTML = About_Section_Features_options;


/** 
 this is temp arrry for test the our Team Section of swiper
 */
const OurTeam_section_title = document.getElementById("OurTeam_section_title");
OurTeam_section_title.innerHTML = "Our Team";
const OurTeam_section_Descrption = document.getElementById("OurTeam_section_Descrption");
OurTeam_section_Descrption.innerHTML = "Necessitatibus eius consequatur";
let departmentHeads = [
  {
    name: "Joshua Stefan",
    department: "Farmer",
    image: "assets/img/team/team-1.jpg",
    socialMedia: [
      "https://www.facebook.com/",
      "https://x.com/",
      "https://www.linkedin.com/"
    ]
  }
  ,
  {
    name: "Sheena Anderson",
    department: "Marketing",
    image: "assets/img/team/team-2.jpg",
    socialMedia: [
      "https://www.facebook.com/",
      "https://x.com/",
      "https://www.linkedin.com/"
    ]
  },
  {
    name: "Evan Smith",
    department: "Content",
    image: "assets/img/team/team-3.jpg",
    socialMedia: [
      "https://www.facebook.com/",
      "https://x.com/",
      "https://www.linkedin.com/"
    ]
  },
  {
    name: "Kaylie Jones",
    department: "Accountant",
    image: "assets/img/team/team-4.jpg",
    socialMedia: [
      "https://www.facebook.com/",
      "https://x.com/",
      "https://www.linkedin.com/"
    ]
  }

];

const Our_Team_section = document.getElementById("Out_Team_secion_Swiper");
const ourTeam_Slider = departmentHeads.map((ourTeam_Slide, index) => {
  return `
   <div class="col-lg-3 col-md-6 mb-4">
              <div class="person">
                <figure>
                  <img src="${ourTeam_Slide.image}" alt="Image" class="img-fluid">
                  <div class="social">
                    <a target="_blank" href="${ourTeam_Slide.socialMedia[0]}"><span class="bi bi-facebook"></span></a>
                    <a target="_blank" href="${ourTeam_Slide.socialMedia[1]}"><span class="bi bi-twitter-x"></span></a>
                    <a target="_blank" href="${ourTeam_Slide.socialMedia[2]}"><span class="bi bi-linkedin"></span></a>
                  </div>
                </figure>
                <div class="person-contents">
                  <h3>${ourTeam_Slide.name}</h3>
                  <span class="position">${ourTeam_Slide.department}</span>
                </div>
              </div>
            </div>
  `
}
).join('');
Our_Team_section.innerHTML = ourTeam_Slider;


/** 
 this is temp arrry for test the Recent Posts Section Section of swiper
 */
const RecentPostsSection_swiper = document.getElementById("RecentPostsSection_Slider");
const RecentPostsSection_title=document.getElementById("RecentPostsSection_title");
const RecentPostsSection_Descrption=document.getElementById("RecentPostsSection_Descrption");
RecentPostsSection_title.innerHTML="Recent Posts";
RecentPostsSection_Descrption.innerHTML="Necessitatibus eius consequatur";
document.addEventListener("DOMContentLoaded", () => {
  const sliders = document.querySelectorAll(".booking-slider");

  if (!sliders.length) return;

  const list = [];

  sliders.forEach((element) => {
    const [slider, prevEl, nextEl, pagination] = [
      element.querySelector(".swiper"),
      element.querySelector(".slider-nav__item_prev"),
      element.querySelector(".slider-nav__item_next"),
      element.querySelector(".slider-pagination")
    ];

    list.push(
      new Swiper(slider, {
        slidesPerView: 1.15,
        spaceBetween: 20,
        slidesOffsetBefore: 20,
        slidesOffsetAfter: 20,
        speed: 600,
        observer: true,
        watchOverflow: true,
        watchSlidesProgress: true,
        loop: true,
        navigation: { nextEl, prevEl, disabledClass: "disabled" },
        pagination: {
          el: pagination,
          type: "bullets",
          modifierClass: "slider-pagination",
          bulletClass: "slider-pagination__item",
          bulletActiveClass: "active",
          clickable: true
        },
        breakpoints: {
          575: {
            slidesPerView: 1.5
          },
          992: {
            slidesPerView: 2,
            slidesOffsetBefore: 0,
            slidesOffsetAfter: 0
          },
          1366: {
            slidesPerView: 3,
            spaceBetween: 40,
            slidesOffsetBefore: 0,
            slidesOffsetAfter: 0
          }
        }
      })
    );
  });
});


let Recent_Posts = [
  {
    name: "Julia Parker",
    Publication_date: "December 12",
    imge: "assets/img/blog/blog-1.jpg",
    title: "Eum ad dolor et. Autem aut fugiat debitis",
    location: "29 Terrace Rd, BH2 5EL",
    post_category: "Politics"
  },
  {
    name: "Mario Douglas",
    Publication_date: "July 17",
    imge: "assets/img/blog/blog-2.jpg",
    title: "Et repellendus molestiae qui est sed omnis",
    location: "29 Terrace Rd, BH2 5EL",
    post_category: "Sports"
  },
  {
    name: "Lisa Hunter",
    Publication_date: "September 05",
    imge: "assets/img/blog/blog-3.jpg",
    title: "Quia assumenda est et veritati tirana ploder",
    location: "29 Terrace Rd, BH2 5EL",
    post_category: "Economics"
  }
  
];

const RecentPostsSection_Slider = Recent_Posts.map((slide, index) => {
  return `
<div class="booking-slider__slide swiper-slide" data-aos="fade-up" data-aos-delay="${(index+1)*100}">
    <div class="booking-slider__item booking-slider-item">
      <div title="Publication date" class="booking-slider-item__badge text-white ">
        ${slide.Publication_date}
      </div>

      <a title="" href="blog-details.html" class="booking-slider-item__image">
        <img src="${slide.imge}" alt="" />
      </a>

      <div class="booking-slider-item__content">

        <h2 class="booking-slider-item__title">
          <a title="" href="blog-details.html">${slide.title} </a>
        </h2>

        <div title="Address" class="booking-slider-item__address">
          <span class="booking-slider-item__address-icon">
            <img src="https://bato-web-agency.github.io/bato-shared/img/slider-2/icon-address.svg"
              alt="Address" />
          </span>
          ${slide.location}
        </div>

        <div class="booking-slider-item__footer">
          <div class="booking-slider-item__footer-inner">
            <div class="booking-slider-item__amenities">
              <div class="booking-slider-item__amenity">
                <div class="d-flex align-items-center">
                  <i class="bi bi-person"></i> <span class="ps-3">${slide.name}</span>
                </div>
                <span class="px-1 text-white-50">/</span>
                <div class="d-flex align-items-center">
                  <i class="bi bi-folder2"></i> <span class="ps-3">${slide.post_category}</span>
                </div>
              </div>
            </div>
            <a class="booking-slider-item__btn" href="blog-details.html">
              <span class="booking-slider-item__btn-text">Read More</span>
              <span class="booking-slider-item__btn-icon"></span>
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
  `
}).join('');
RecentPostsSection_swiper.innerHTML = RecentPostsSection_Slider;