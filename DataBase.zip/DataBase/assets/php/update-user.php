<?php
header('Content-Type: application/json');

// connection stting
$servername = "localhost";
$username = "root";
$password = "";      
$database = "Yasmeem_Agricultural_Company";
$port = 3307;             

// create connection
$conn = new mysqli($servername, $username, $password, $database, $port);

// Check the connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Connection failed: " . $conn->connect_error]);
    exit;
}


$data = json_decode(file_get_contents("php://input"));

if (!isset($data->account_id)) {
    http_response_code(400);
    echo json_encode(["error" => "Missing account_id"]);
    exit;
}

// Assign variables safely
$account_id     = intval($data->account_id);
$first_name     = trim($data->first_name ?? '');
$last_name      = trim($data->last_name ?? '');
$email          = trim($data->email ?? '');
$phone_number   = trim($data->phone_number ?? '');
$account_type   = trim($data->account_type ?? '');
$data_of_birth  = trim($data->data_of_birth ?? null);
$image          = trim($data->image ?? '');
$is_active      = trim($data->is_active ?? '');
$gender         = trim($data->gender ?? '');
$password       = $data->password ?? null;


// Email validation
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid email format"]);
    exit;
}

// Phone number validation
if (!preg_match('/^[0-9]{1,10}$/', $phone_number)) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid phone number"]);
    exit;
}

// Optional password validation & hashing
$updatePassword = false;
if (!empty($password)) {
    if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/', $password)) {
        http_response_code(400);
        echo json_encode([
            "error" => "Password must be at least 8 characters and include upper/lowercase letters, a number, and a symbol."
        ]);
        exit;
    }
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $updatePassword = true;
}

if ($updatePassword) {
    $stmt = $conn->prepare("UPDATE account_Table SET 
        first_name = ?, 
        last_name = ?, 
        email = ?, 
        phone_number = ?, 
        account_type = ?, 
        data_of_birth = ?, 
        image = ?, 
        is_active = ?, 
        gender = ?,
        password_hash = ?
        WHERE account_id = ?");
    $stmt->bind_param(
        "ssssssssssi",
        $first_name,
        $last_name,
        $email,
        $phone_number,
        $account_type,
        $data_of_birth,
        $image,
        $is_active,
        $gender,
        $hashed_password,
        $account_id
    );
} else {
    $stmt = $conn->prepare("UPDATE account_Table SET 
        first_name = ?, 
        last_name = ?, 
        email = ?, 
        phone_number = ?, 
        account_type = ?, 
        data_of_birth = ?, 
        image = ?, 
        is_active = ?, 
        gender = ?
        WHERE account_id = ?");
    $stmt->bind_param(
        "sssssssssi",
        $first_name,
        $last_name,
        $email,
        $phone_number,
        $account_type,
        $data_of_birth,
        $image,
        $is_active,
        $gender,
        $account_id
    );
}

if ($stmt->execute()) {
    echo json_encode(["message" => "User updated successfully"]);
} else {
    http_response_code(500);
    echo json_encode(["error" => "Failed to update user"]);
}
?>
