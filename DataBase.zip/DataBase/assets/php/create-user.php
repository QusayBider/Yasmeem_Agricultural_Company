<?php
header('Content-Type: application/json');

// connection stting
$servername = "localhost";
$username = "root";
$password = "";      
$database = "Yasmeem_Agricultural_Company";
$port = 3307;             

// create connection
$conn = new mysqli($servername, $username, $password, $database, $port);

// Check the connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Connection failed: " . $conn->connect_error]);
    exit;
}


$data = json_decode(file_get_contents("php://input"), true);


$first_name = $data['first_name'];
$last_name = $data['last_name'];
$email = $data['email'];
$phone_number = $data['phone_number'];
$account_type = $data['account_type'];
$image = $data['image'];
$data_of_birth = $data['date_of_birth'];
$password = $data['password'];
$is_active = $data['is_active'];
$gender = $data['gender'];


if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid email format"]);
    exit;
}


if (!preg_match('/^[0-9]{1,10}$/', $phone_number)) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid phone number"]);
    exit;
}


if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/', $password)) {
    http_response_code(400);
    echo json_encode([
        "error" => "Password must be at least 8 characters and include upper/lowercase letters, a number, and a symbol."
    ]);
    exit;
}


$hashed_password = password_hash($password, PASSWORD_DEFAULT);


$sql = "INSERT INTO account_table (first_name, last_name, email, phone_number,account_type, image,data_of_birth,password_hash,is_active,gender) 
        VALUES ('$first_name', '$last_name', '$email', '$phone_number','$account_type' ,'$image','$data_of_birth','$hashed_password','$is_active','$gender')";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["message" => "User created successfully!"]);
} else {
    echo json_encode(["message" => "Error: " . $conn->error]);
}


$conn->close();
?>
