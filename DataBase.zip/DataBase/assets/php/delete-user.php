<?php
header("Content-Type: application/json");

// Connection settings
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

$conn = new mysqli($servername, $username, $password, $database, $port);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Connection failed"]);
    exit;
}

$data = json_decode(file_get_contents("php://input"));

if (!isset($data->id)) {
    http_response_code(400);
    echo json_encode(["error" => "Missing user ID"]);
    exit;
}

$id = intval($data->id);

$stmt = $conn->prepare("DELETE FROM account_Table WHERE account_id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo json_encode(["message" => "User deleted successfully"]);
} else {
    http_response_code(500);
    echo json_encode(["error" => "Failed to delete user"]);
}
?>
