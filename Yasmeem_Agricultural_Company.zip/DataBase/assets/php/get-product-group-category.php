<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

$conn = new mysqli($servername, $username, $password, $database, $port);
header('Content-Type: application/json');
session_start();

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Connection failed: " . $conn->connect_error]);
    exit();
}

$sql = "
    SELECT 
        Category.category_id,
        Category.category_name,
        Product.product_id,
        Product.name AS product_name
    FROM Category
    LEFT JOIN Product ON Category.category_id = Product.category_id
    ORDER BY Category.category_name, Product.name
";

$result = $conn->query($sql);

$categories = [];

while ($row = $result->fetch_assoc()) {
    $cat_id = $row['category_id'];
    $cat_name = $row['category_name'];

    if (!isset($categories[$cat_id])) {
        $categories[$cat_id] = [
            "category_id" => $cat_id,
            "category_name" => $cat_name,
            "products" => []
        ];
    }

    if ($row['product_id']) {
        $categories[$cat_id]['products'][] = [
            "product_id" => $row['product_id'],
            "product_name" => $row['product_name']
        ];
    }
}

echo json_encode(array_values($categories), JSON_PRETTY_PRINT);
$conn->close();
?>
