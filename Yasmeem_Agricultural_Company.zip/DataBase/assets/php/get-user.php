<?php
header('Content-Type: application/json');

// Database connection settings
$servername = "localhost";
$username = "root";
$password = "";      
$database = "Yasmeem_Agricultural_Company";
$port = 3307;             
session_start();
// Create connection
$conn = new mysqli($servername, $username, $password, $database, $port);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Connection failed: " . $conn->connect_error]);
    exit;
}

// Check for ID parameter
if (!isset($_GET['id'])) {
    http_response_code(400);
    echo json_encode(["error" => "Missing ID"]);
    exit;
}

$id = intval($_GET['id']);

$stmt = $conn->prepare("SELECT account_id, account_type, created_at, date_of_birth, email, first_name,password_hash,gender, image, is_active, last_name, phone_number,address,city FROM account_Table WHERE account_id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if ($user) {
    echo json_encode(["user" => $user]);
} else {
    http_response_code(404);
    echo json_encode(["error" => "User not found"]);
}

$stmt->close();
$conn->close();
?>
