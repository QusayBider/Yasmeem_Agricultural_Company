<?php
session_start();
header('Content-Type: application/json');

// Read JSON POST input
$input = json_decode(file_get_contents("php://input"), true);

if (!$input || !isset($input['order_id'], $input['status_of_order'])) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid input"]);
    exit();
}

$orderId = (int)$input['order_id'];
$newStatus = $input['status_of_order'];

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

$conn = new mysqli($servername, $username, $password, $database, $port);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed"]);
    exit();
}

// Fetch the specific Branch_Product record by branch_product_id
$stmt = $conn->prepare("
    SELECT bp.*, p.name 
    FROM Branch_Product bp 
    JOIN Product p ON bp.product_id = p.product_id 
    WHERE bp.branch_product_id = ?
");
$stmt->bind_param("i", $orderId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    http_response_code(404);
    echo json_encode(["error" => "Branch product record not found"]);
    exit();
}

$row = $result->fetch_assoc();

$branch_product_id = $row['branch_product_id'];
$product_id = $row['product_id'];
$branch_id = $row['branch_id'];
$requested_quantity = $row['total_stock_quantity'];
$product_name = $row['name'];

// Status logic
if ($newStatus === 'Available in branch') {
    // Check warehouse stock
    $stmt = $conn->prepare("
        SELECT total_stock_quantity 
        FROM Warehouse_Product 
        WHERE product_id = ?
    ");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $warehouse_result = $stmt->get_result();

    if ($warehouse_result->num_rows > 0) {
        $warehouse_row = $warehouse_result->fetch_assoc();
        $available_quantity = $warehouse_row['total_stock_quantity'];

        if ($available_quantity >= $requested_quantity) {
            // Start transaction
            $conn->begin_transaction();
            try {
                // Decrease warehouse stock
                $updateWarehouse = $conn->prepare("
                    UPDATE Warehouse_Product 
                    SET total_stock_quantity = total_stock_quantity - ? 
                    WHERE product_id = ?
                ");
                $updateWarehouse->bind_param("ii", $requested_quantity, $product_id);
                $updateWarehouse->execute();

                // Update product_condition
                $updateBranch = $conn->prepare("
                    UPDATE Branch_Product 
                    SET product_condition = ? 
                    WHERE branch_product_id = ?
                ");
                $updateBranch->bind_param("si", $newStatus, $branch_product_id);
                $updateBranch->execute();

                $conn->commit();
                echo json_encode(["success" => "Product condition updated successfully"]);
                exit();
            } catch (Exception $e) {
                $conn->rollback();
                http_response_code(500);
                echo json_encode(["error" => "Transaction failed: " . $e->getMessage()]);
                exit();
            }
        } else {
            // Insufficient stock
            http_response_code(409);
            echo json_encode([
                "error" => "Insufficient stock in warehouse",
                "details" => [[
                    "product_id" => $product_id,
                    "product_name" => $product_name,
                    "required" => $requested_quantity,
                    "available" => $available_quantity
                ]]
            ]);
            exit();
        }
    } else {
        // No warehouse record
        http_response_code(404);
        echo json_encode([
            "error" => "Product not found in warehouse",
            "details" => [[
                "product_id" => $product_id,
                "product_name" => $product_name,
                "required" => $requested_quantity,
                "available" => 0
            ]]
        ]);
        exit();
    }
} elseif ($newStatus === 'Cancelled') {
    // Delete the branch product
    $deleteStmt = $conn->prepare("
        DELETE FROM Branch_Product 
        WHERE branch_product_id = ?
    ");
    $deleteStmt->bind_param("i", $branch_product_id);

    if ($deleteStmt->execute()) {
        echo json_encode(["success" => "Cancelled product removed successfully"]);
    } else {
        http_response_code(500);
        echo json_encode(["error" => "Failed to remove cancelled product"]);
    }
    exit();
} else {
    // Other status update
    $updateStmt = $conn->prepare("
        UPDATE Branch_Product 
        SET product_condition = ? 
        WHERE branch_product_id = ?
    ");
    $updateStmt->bind_param("si", $newStatus, $branch_product_id);

    if ($updateStmt->execute()) {
        echo json_encode(["success" => "Product condition updated successfully"]);
    } else {
        http_response_code(500);
        echo json_encode(["error" => "Failed to update product condition"]);
    }
    exit();
}

?>
