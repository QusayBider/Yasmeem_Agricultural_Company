<?php
session_start();
header('Content-Type: application/json');

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

$conn = new mysqli($servername, $username, $password, $database, $port);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed"]);
    exit();
}

// Get supplier_id from query string or JSON input
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (!isset($_GET['supplier_id']) || !is_numeric($_GET['supplier_id'])) {
        http_response_code(400);
        echo json_encode(["error" => "Valid supplier_id is required"]);
        exit();
    }
    $supplier_id = intval($_GET['supplier_id']);
} else {
    $data = json_decode(file_get_contents("php://input"), true);
    if (!isset($data['supplier_id']) || !is_numeric($data['supplier_id'])) {
        http_response_code(400);
        echo json_encode(["error" => "Valid supplier_id is required"]);
        exit();
    }
    $supplier_id = intval($data['supplier_id']);
}

// Prepare and execute SELECT query
$stmt = $conn->prepare("SELECT * FROM Supplier WHERE supplier_id = ?");
$stmt->bind_param("i", $supplier_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $supplier = $result->fetch_assoc();
    echo json_encode(["success" => true, "supplier" => $supplier]);
} else {
    http_response_code(404);
    echo json_encode(["error" => "Supplier not found"]);
}

$stmt->close();
$conn->close();
?>
