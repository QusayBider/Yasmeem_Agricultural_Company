<?php
// Connection settings
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;
session_start();

header('Content-Type: application/json');

// Check for order_id in GET parameters
if (!isset($_GET['order_id']) || empty($_GET['order_id'])) {
    http_response_code(400); // Bad Request
    echo json_encode(["error" => "Missing or invalid order_id parameter."]);
    exit();
}

$order_id = $_GET['order_id'];

// Create connection
$conn = new mysqli($servername, $username, $password, $database, $port);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Connection failed: " . $conn->connect_error]);
    exit();
}

// Updated SQL to include phone number
$sql = "
SELECT 
    o.order_id,
    c.customer_id,
    CONCAT(a.first_name, ' ', a.last_name) AS customer_name,
    a.phone_number,
    o.employee_id,
    o.order_date,
    o.total_amount,
    o.city,
    o.street,
    o.apt_number,
    o.payment_method,
    o.status_of_order,

    od.product_id,
    od.quantity,
    od.added_at,

    p.name AS product_name,
    p.price AS unit_price,
    (p.price * od.quantity) AS product_total_price,
    p.description_product,
    p.image

FROM Order_Table o
JOIN Customer c ON o.customer_id = c.customer_id
JOIN Account_Table a ON c.account_id = a.account_id
JOIN Order_Details od ON o.order_id = od.order_id
JOIN Product p ON od.product_id = p.product_id
WHERE o.order_id = ?
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $order_id);
$stmt->execute();
$result = $stmt->get_result();

$orderData = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        if (empty($orderData)) {
            // Initialize order once
            $orderData = [
                "order_id" => $row["order_id"],
                "customer_id" => $row["customer_id"],
                "customer_name" => $row["customer_name"],
                "phone_number" => $row["phone_number"], // <- Added here
                "employee_id" => $row["employee_id"],
                "order_date" => $row["order_date"],
                "total_amount" => $row["total_amount"],
                "city" => $row["city"],
                "street" => $row["street"],
                "apt_number" => $row["apt_number"],
                "payment_method" => $row["payment_method"],
                "status_of_order" => $row["status_of_order"],
                "products" => []
            ];
        }

        $orderData["products"][] = [
            "product_id" => $row["product_id"],
            "product_name" => $row["product_name"],
            "unit_price" => $row["unit_price"],
            "quantity" => $row["quantity"],
            "product_total_price" => $row["product_total_price"],
            "added_at" => $row["order_date"],
            "description_product" => $row["description_product"],
            "image" => $row["image"]
        ];
    }

    echo json_encode([
        "success" => true,
        "order" => $orderData
    ], JSON_PRETTY_PRINT);
} else {
    echo json_encode([
        "success" => false,
        "message" => "No order found with ID $order_id."
    ]);
}

$stmt->close();
$conn->close();
?>
