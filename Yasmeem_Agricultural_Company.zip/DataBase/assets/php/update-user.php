<?php
header('Content-Type: application/json');
session_start();

// DB connection settings
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

// Create connection
$conn = new mysqli($servername, $username, $password, $database, $port);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Connection failed: " . $conn->connect_error]);
    exit;
}

$data = json_decode(file_get_contents("php://input"));

if (!isset($data->account_id)) {
    http_response_code(400);
    echo json_encode(["error" => "Missing account_id"]);
    exit;
}

$account_id = intval($data->account_id);
$fields = [];
$params = [];
$types = "";

// Helper
function addField(&$fields, &$params, &$types, $key, $value, $typeChar = 's') {
    $fields[] = "$key = ?";
    $params[] = $value;
    $types .= $typeChar;
}

// Fields
if (isset($data->first_name)) addField($fields, $params, $types, 'first_name', trim($data->first_name));
if (isset($data->last_name)) addField($fields, $params, $types, 'last_name', trim($data->last_name));
if (isset($data->email)) {
    $email = trim($data->email);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        http_response_code(400);
        echo json_encode(["error" => "Invalid email format"]);
        exit;
    }

    $check_stmt = $conn->prepare("SELECT account_id FROM account_table WHERE email = ? AND account_id != ?");
    $check_stmt->bind_param("si", $email, $account_id);
    $check_stmt->execute();
    $check_stmt->store_result();

    if ($check_stmt->num_rows > 0) {
        http_response_code(400);
        echo json_encode(["error" => "Email already exists for another account"]);
        exit;
    }
    $check_stmt->close();

    addField($fields, $params, $types, 'email', $email);
}
if (isset($data->phone_number)) {
    $phone = trim($data->phone_number);
    if (!preg_match('/^[0-9]{1,10}$/', $phone)) {
        http_response_code(400);
        echo json_encode(["error" => "Invalid phone number"]);
        exit;
    }
    addField($fields, $params, $types, 'phone_number', $phone);
}
if (isset($data->account_type)) $new_account_type = trim($data->account_type);
if (isset($data->account_type)) addField($fields, $params, $types, 'account_type', $new_account_type);
if (isset($data->date_of_birth)) addField($fields, $params, $types, 'date_of_birth', trim($data->date_of_birth));
if (isset($data->image)) addField($fields, $params, $types, 'image', trim($data->image));
if (isset($data->is_active)) addField($fields, $params, $types, 'is_active', trim($data->is_active));
if (isset($data->gender)) addField($fields, $params, $types, 'gender', trim($data->gender));
if (isset($data->address)) addField($fields, $params, $types, 'address', trim($data->address));
if (isset($data->city)) addField($fields, $params, $types, 'city', trim($data->city));

if (!empty($data->password)) {
    $password = $data->password;
    if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/', $password)) {
        http_response_code(400);
        echo json_encode(["error" => "Password must be strong (min 8 chars, upper, lower, digit, symbol)"]);
        exit;
    }
    $hashed = password_hash($password, PASSWORD_DEFAULT);
    addField($fields, $params, $types, 'password_hash', $hashed);
}

if (empty($fields)) {
    http_response_code(400);
    echo json_encode(["error" => "No fields to update"]);
    exit;
}

// Perform update
$sql = "UPDATE account_table SET " . implode(", ", $fields) . " WHERE account_id = ?";
$params[] = $account_id;
$types .= "i";

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);

if ($stmt->execute()) {
    if (isset($new_account_type)) {
        // Clean up other roles
        if (strtolower($new_account_type) === 'customer') {
            // Remove from employee
            $removeEmp = $conn->prepare("DELETE FROM employee WHERE account_id = ?");
            $removeEmp->bind_param("i", $account_id);
            $removeEmp->execute();
            $removeEmp->close();

            // Add to customer if not exists
            $checkCust = $conn->prepare("SELECT customer_id FROM customer WHERE account_id = ?");
            $checkCust->bind_param("i", $account_id);
            $checkCust->execute();
            $checkCust->store_result();

            if ($checkCust->num_rows === 0) {
                $insertCust = $conn->prepare("INSERT INTO customer (account_id, registration_date) VALUES (?, NOW())");
                $insertCust->bind_param("i", $account_id);
                $insertCust->execute();
                $insertCust->close();
            }
            $checkCust->close();

        } elseif (strtolower($new_account_type) === 'employee') {
            // Remove from customer
            $removeCust = $conn->prepare("DELETE FROM customer WHERE account_id = ?");
            $removeCust->bind_param("i", $account_id);
            $removeCust->execute();
            $removeCust->close();
        }
    }

    echo json_encode(["message" => "Account updated successfully"]);
} else {
    http_response_code(500);
    echo json_encode(["error" => "Update failed: " . $stmt->error]);
}

$stmt->close();
$conn->close();
?>
