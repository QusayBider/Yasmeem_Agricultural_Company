<?php
session_start();
header('Content-Type: application/json');

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

$conn = new mysqli($servername, $username, $password, $database, $port);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed"]);
    exit();
}

// Get JSON input
$data = json_decode(file_get_contents("php://input"), true);

// Validate input
if (!isset($data['supplier_id']) || !is_numeric($data['supplier_id'])) {
    http_response_code(400);
    echo json_encode(["error" => "Valid supplier_id is required"]);
    exit();
}

$supplier_id = intval($data['supplier_id']);

// Prepare statement to delete supplier
$stmt = $conn->prepare("DELETE FROM Supplier WHERE supplier_id = ?");
$stmt->bind_param("i", $supplier_id);

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        echo json_encode(["success" => true, "message" => "Supplier deleted successfully"]);
    } else {
        http_response_code(404);
        echo json_encode(["error" => "Supplier not found"]);
    }
} else {
    http_response_code(500);
    echo json_encode(["error" => "Failed to delete supplier"]);
}

$stmt->close();
$conn->close();
?>
