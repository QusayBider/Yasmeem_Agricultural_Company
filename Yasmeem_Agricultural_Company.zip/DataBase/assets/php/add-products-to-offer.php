<?php
session_start();
header('Content-Type: application/json');

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

$conn = new mysqli($servername, $username, $password, $database, $port);

$data = json_decode(file_get_contents('php://input'), true);
$offer_id = filter_var($data['offer_id'], FILTER_VALIDATE_INT);
$product_ids = array_filter($data['product_ids'], 'is_numeric');

if (!$offer_id || empty($product_ids)) {
    echo json_encode(['success' => false, 'error' => 'Invalid data']);
    exit;
}

$conn->begin_transaction();

try {
    $stmt = $conn->prepare("INSERT INTO Product_Offers (product_id, offers_id) VALUES (?, ?)");
    
    foreach ($product_ids as $product_id) {
        $stmt->bind_param("ii", $product_id, $offer_id);
        $stmt->execute();
    }
    
    $conn->commit();
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

$conn->close();
?>