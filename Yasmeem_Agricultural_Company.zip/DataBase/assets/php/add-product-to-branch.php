<?php
session_start();
header('Content-Type: application/json');

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

$conn = new mysqli($servername, $username, $password, $database, $port);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
    exit;
}

// Parse JSON input
$input = json_decode(file_get_contents("php://input"), true);

$product_id = isset($input['product_id']) ? intval($input['product_id']) : null;
$branch_id = isset($input['branch_id']) ? intval($input['branch_id']) : null;
$total_stock_quantity = isset($input['total_stock_quantity']) ? intval($input['total_stock_quantity']) : null;
$product_condition = isset($input['product_condition']) ? trim($input['product_condition']) : null;

$errors = [];

// Validate required fields
if ($product_id === null || $branch_id === null || $total_stock_quantity === null || $product_condition === null) {
    $errors[] = "All fields are required.";
}

// Validate total_stock_quantity
if ($total_stock_quantity !== null && $total_stock_quantity < 0) {
    $errors[] = "Total stock quantity must be a non-negative number.";
}

// Validate product_condition
$valid_conditions = ['Product request', 'Available in branch'];
if (!in_array($product_condition, $valid_conditions)) {
    $errors[] = "Invalid product condition.";
}

// Check if product exists
if (empty($errors)) {
    $stmt = $conn->prepare("SELECT 1 FROM Product WHERE product_id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows === 0) {
        $errors[] = "Product ID does not exist.";
    }
    $stmt->close();
}

// Check if branch exists
if (empty($errors)) {
    $stmt = $conn->prepare("SELECT 1 FROM Branch WHERE branch_id = ?");
    $stmt->bind_param("i", $branch_id);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows === 0) {
        $errors[] = "Branch ID does not exist.";
    }
    $stmt->close();
}

// Return validation errors if any
if (!empty($errors)) {
    echo json_encode([
        "success" => false,
        "errors" => $errors
    ]);
    exit;
}

// Check if the product with the same condition exists in the branch
$stmt = $conn->prepare("
    SELECT total_stock_quantity FROM Branch_Product 
    WHERE product_id = ? AND branch_id = ? AND product_condition = ?
");
$stmt->bind_param("iis", $product_id, $branch_id, $product_condition);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    // Entry exists — update the quantity
    $stmt->bind_result($existing_quantity);
    $stmt->fetch();
    $stmt->close();

    $new_quantity = $existing_quantity + $total_stock_quantity;

    $update_stmt = $conn->prepare("
        UPDATE Branch_Product 
        SET total_stock_quantity = ? 
        WHERE product_id = ? AND branch_id = ? AND product_condition = ?
    ");
    $update_stmt->bind_param("iiis", $new_quantity, $product_id, $branch_id, $product_condition);

    if ($update_stmt->execute()) {
        echo json_encode([
            "success" => true,
            "message" => "Stock quantity updated successfully."
        ]);
    } else {
        http_response_code(500);
        echo json_encode([
            "success" => false,
            "error" => "Failed to update stock quantity: " . $update_stmt->error
        ]);
    }

    $update_stmt->close();
} else {
    // Entry does not exist — insert new record
    $stmt->close();

    $insert_stmt = $conn->prepare("
        INSERT INTO Branch_Product (product_id, branch_id, total_stock_quantity, product_condition) 
        VALUES (?, ?, ?, ?)
    ");
    $insert_stmt->bind_param("iiis", $product_id, $branch_id, $total_stock_quantity, $product_condition);

    if ($insert_stmt->execute()) {
        echo json_encode([
            "success" => true,
            "message" => "Product successfully assigned to branch."
        ]);
    } else {
        http_response_code(500);
        echo json_encode([
            "success" => false,
            "error" => "Database insert failed: " . $insert_stmt->error
        ]);
    }

    $insert_stmt->close();
}

$conn->close();
?>
