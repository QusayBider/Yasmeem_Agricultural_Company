<?php
session_start();
header('Content-Type: application/json');

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

$conn = new mysqli($servername, $username, $password, $database, $port);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

// Only allow PUT method
if ($_SERVER['REQUEST_METHOD'] !== 'PUT') {
    http_response_code(405);
    echo json_encode(["error" => "Only PUT method is allowed"]);
    exit();
}

// Get input data
$data = json_decode(file_get_contents("php://input"), true);
if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid JSON input"]);
    exit();
}

// Validate input
if (
    !isset($data['supplier_id']) || !is_numeric($data['supplier_id']) ||
    !isset($data['first_name']) || empty(trim($data['first_name'])) ||
    !isset($data['last_name']) || empty(trim($data['last_name'])) ||
    !isset($data['email']) || empty(trim($data['email'])) ||
    !isset($data['phone_number']) || empty(trim($data['phone_number'])) ||
    !isset($data['address']) || empty(trim($data['address']))
) {
    http_response_code(400);
    echo json_encode(["error" => "Missing or invalid input"]);
    exit();
}

$supplier_id = intval($data['supplier_id']);
$first_name = $conn->real_escape_string(trim($data['first_name']));
$last_name = $conn->real_escape_string(trim($data['last_name']));
$email = $conn->real_escape_string(trim($data['email']));
$phone_number = $conn->real_escape_string(trim($data['phone_number']));
$address = $conn->real_escape_string(trim($data['address']));

// Check if supplier exists first
$check_stmt = $conn->prepare("SELECT supplier_id FROM Supplier WHERE supplier_id = ?");
$check_stmt->bind_param("i", $supplier_id);
$check_stmt->execute();
$check_stmt->store_result();

if ($check_stmt->num_rows === 0) {
    http_response_code(404);
    echo json_encode(["error" => "Supplier not found"]);
    $check_stmt->close();
    $conn->close();
    exit();
}
$check_stmt->close();

// Prepare and execute UPDATE query
$stmt = $conn->prepare("UPDATE Supplier SET first_name = ?, last_name = ?, email = ?, phone_number = ?, address = ? WHERE supplier_id = ?");
if (!$stmt) {
    http_response_code(500);
    echo json_encode(["error" => "Prepare failed: " . $conn->error]);
    $conn->close();
    exit();
}

$stmt->bind_param("sssssi", $first_name, $last_name, $email, $phone_number, $address, $supplier_id);
$success = $stmt->execute();

if ($success) {
    if ($stmt->affected_rows > 0) {
        echo json_encode(["success" => true, "message" => "Supplier updated successfully"]);
    } else {
        echo json_encode(["success" => true, "message" => "No changes made to the supplier"]);
    }
} else {
    http_response_code(500);
    echo json_encode(["error" => "Update failed: " . $stmt->error]);
}

$stmt->close();
$conn->close();
?>