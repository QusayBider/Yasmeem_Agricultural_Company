<?php
// connection settings
$servername = "localhost";
$username = "root";
$password = "";      
$database = "Yasmeem_Agricultural_Company";
$port = 3307;             
session_start();
$conn = new mysqli($servername, $username, $password, $database, $port);

// Check the connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Connection failed: " . $conn->connect_error]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);

// Helper function to validate inputs
function validate_input($data) {
    $errors = [];

    if (empty($data['first_name']) || !preg_match("/^[a-zA-Z]{2,}$/", $data['first_name'])) {
        $errors[] = "Invalid first name.";
    }

    if (empty($data['last_name']) || !preg_match("/^[a-zA-Z]{2,}$/", $data['last_name'])) {
        $errors[] = "Invalid last name.";
    }

    if (empty($data['email']) || !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email address.";
    }

    if (empty($data['phone_number']) || !preg_match("/^\+?[0-9]{7,15}$/", $data['phone_number'])) {
        $errors[] = "Invalid phone number.";
    }

    if (empty($data['account_type']) || !in_array($data['account_type'], ['Employee', 'Customer'])) {
        $errors[] = "Invalid account type.";
    }

    if (empty($data['date_of_birth']) || !preg_match("/^\d{4}-\d{2}-\d{2}$/", $data['date_of_birth'])) {
        $errors[] = "Invalid date of birth.";
    }

    if (empty($data['password']) || strlen($data['password']) < 6) {
        $errors[] = "Password must be at least 6 characters.";
    }

    if (empty($data['gender']) || !in_array(strtolower($data['gender']), ['male', 'female', 'other'])) {
        $errors[] = "Invalid gender.";
    }

    return $errors;
}

// Validate inputs
$errors = validate_input($data);
if (!empty($errors)) {
    echo json_encode(["status" => "error", "message" => $errors]);
    exit;
}

// Sanitized inputs
$first_name = htmlspecialchars($data['first_name']);
$last_name = htmlspecialchars($data['last_name']);
$email = filter_var($data['email'], FILTER_SANITIZE_EMAIL);
$phone = htmlspecialchars($data['phone_number']);
$account_type = htmlspecialchars($data['account_type']);
$image = $data['image'];
$dob = $data['date_of_birth'];
$password = password_hash($data['password'], PASSWORD_BCRYPT);
$gender = htmlspecialchars($data['gender']);

// Check if email already exists
$check_email = $conn->prepare("SELECT account_id FROM Account_Table WHERE email = ?");
$check_email->bind_param("s", $email);
$check_email->execute();
$check_email->store_result();

if ($check_email->num_rows > 0) {
    echo json_encode(["status" => "error", "message" => "Email is already in use."]);
    $check_email->close();
    $conn->close();
    exit;
}
$check_email->close();

// Insert into Account_Table
$stmt = $conn->prepare("INSERT INTO Account_Table (first_name, last_name, email, phone_number, account_type, image, date_of_birth, password_hash, gender) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sssssssss", $first_name, $last_name, $email, $phone, $account_type, $image, $dob, $password, $gender);

if ($stmt->execute()) {
    $account_id = $stmt->insert_id;

    $reg_date = date('Y-m-d');
    $stmt2 = $conn->prepare("INSERT INTO Customer (account_id, registration_date) VALUES (?, ?)");
    $stmt2->bind_param("is", $account_id, $reg_date);

    if ($stmt2->execute()) {
        echo json_encode(["status" => "success", "message" => "Customer registered successfully."]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to insert into Customer table."]);
    }

    $stmt2->close();
} else {
    echo json_encode(["status" => "error", "message" => "Failed to insert into Account_Table."]);
}

$stmt->close();
$conn->close();
?>
