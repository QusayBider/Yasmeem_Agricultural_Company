<?php
session_start();
header('Content-Type: application/json');

// DB connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

$conn = new mysqli($servername, $username, $password, $database, $port);

// Check DB connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

// SQL to get products with category and supplier name
$sql = "
    SELECT 
        p.product_id,
        p.name AS product_name,
        p.price,
        p.wholesale_price,
        p.image,
        p.description_product,
        p.rate,
        p.views_count,
        c.category_name,
        CONCAT(s.first_name, ' ', s.last_name) AS supplier_name
    FROM Product p
    JOIN Category c ON p.category_id = c.category_id
    JOIN Supplier s ON p.supplier_id = s.supplier_id
";

$result = $conn->query($sql);

// Return data as JSON
if ($result && $result->num_rows > 0) {
    $products = [];
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
    echo json_encode($products, JSON_PRETTY_PRINT);
} else {
    echo json_encode(["message" => "No products found."]);
}

// Close the DB connection
$conn->close();
?>
