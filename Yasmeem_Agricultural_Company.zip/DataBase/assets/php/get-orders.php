<?php
// Connection settings
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;
session_start();

// Set the response content type to JSON
header('Content-Type: application/json');

// Create connection
$conn = new mysqli($servername, $username, $password, $database, $port);

// Check connection
if ($conn->connect_error) {
    http_response_code(500); // Internal Server Error
    echo json_encode(["error" => "Connection failed: " . $conn->connect_error]);
    exit();
}

// Simplified query to get only order_id, order_date, total_amount, and status_of_order
$sql = "
SELECT 
    o.order_id,
    o.order_date,
    o.total_amount,
    o.status_of_order
FROM Order_Table o
ORDER BY o.order_id DESC
";

$result = $conn->query($sql);

$orders = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $orders[] = [
            "order_id" => $row["order_id"],
            "order_date" => $row["order_date"],
            "total_amount" => $row["total_amount"],
            "status_of_order" => $row["status_of_order"]
        ];
    }

    echo json_encode([
        "success" => true,
        "orders" => $orders
    ], JSON_PRETTY_PRINT);
} else {
    echo json_encode([
        "success" => false,
        "message" => "No orders found."
    ]);
}

$conn->close();
?>
