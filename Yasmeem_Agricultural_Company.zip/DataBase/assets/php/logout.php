<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

$conn = new mysqli($servername, $username, $password, $database, $port);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set user inactive if logged in
if (isset($_SESSION['user_id'])) {
    $account_id = $_SESSION['user_id'];
    $stmt = $conn->prepare("UPDATE Account_Table SET is_active = 'Not-Active' WHERE account_id = ?");
    $stmt->bind_param("i", $account_id);
    $stmt->execute();
    $stmt->close();
}

$conn->close();

// Clear session
session_unset();
session_destroy();
echo '<script>localStorage.removeItem("welcomeMessageShown"); window.location.href = "/DataBase/index.html";</script>';
?>

