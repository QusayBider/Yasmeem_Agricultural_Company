<?php
session_start();
header('Content-Type: application/json');

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

$conn = new mysqli($servername, $username, $password, $database, $port);
// Get the raw POST data
$data = json_decode(file_get_contents('php://input'), true);

$category_id = filter_input(INPUT_GET, 'category_id', FILTER_VALIDATE_INT);
$offer_id = filter_input(INPUT_GET, 'offer_id', FILTER_VALIDATE_INT);

if (!$category_id) {
    echo json_encode(['error' => 'Invalid category ID']);
    exit;
}

// Get products in this category not already in the offer
$query = $conn->prepare("
    SELECT p.product_id, p.name, p.price 
    FROM Product p
    WHERE p.category_id = ? 
    AND p.product_id NOT IN (
        SELECT product_id FROM Product_Offers WHERE offers_id = ?
    )
");
$query->bind_param("ii", $category_id, $offer_id);
$query->execute();
$products = $query->get_result()->fetch_all(MYSQLI_ASSOC);

echo json_encode([
    'success' => true,
    'products' => $products
]);

$conn->close();
?>