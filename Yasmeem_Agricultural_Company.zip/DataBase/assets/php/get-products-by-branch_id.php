<?php
header('Content-Type: application/json');
session_start();

// Connection settings
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

// Get branch_id from GET request
if (!isset($_GET['branch_id'])) {
    echo json_encode([
        "status" => "error",
        "message" => "Missing branch_id parameter"
    ]);
    exit();
}

$branch_id = intval($_GET['branch_id']);

// Create connection
$conn = new mysqli($servername, $username, $password, $database, $port);

// Check connection
if ($conn->connect_error) {
    die(json_encode([
        "status" => "error",
        "message" => "Connection failed: " . $conn->connect_error
    ]));
}

// Query: only Branch_Product + category_name
$sql = "
    SELECT 
        bp.branch_product_id,
        bp.product_id,
        bp.branch_id,
        bp.total_stock_quantity,
        bp.product_condition,
        c.category_name,
        p.name as product_name
    FROM Branch_Product bp
    JOIN Product p ON bp.product_id = p.product_id
    JOIN Category c ON p.category_id = c.category_id
    WHERE bp.branch_id = ?
";

// Prepare and execute statement
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $branch_id);
$stmt->execute();
$result = $stmt->get_result();

// Fetch results
$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

// Return JSON response
echo json_encode([
    "status" => "success",
    "data" => $data
], JSON_PRETTY_PRINT);

// Close connection
$stmt->close();
$conn->close();
?>
