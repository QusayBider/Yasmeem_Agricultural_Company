<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

header('Content-Type: application/json');

// Get raw POST data
$data = json_decode(file_get_contents('php://input'), true);

// Check if product_id is provided
if (!isset($data['product_id'])) {
    http_response_code(400);
    echo json_encode(["error" => "Missing field: product_id"]);
    exit;
}

$product_id = intval($data['product_id']);

// Create connection
$conn = new mysqli($servername, $username, $password, $database, $port);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Connection failed: " . $conn->connect_error]);
    exit;
}

// Prepare delete statement
$stmt = $conn->prepare("DELETE FROM Product WHERE product_id = ?");
$stmt->bind_param("i", $product_id);

// Execute and respond
if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        echo json_encode(["success" => "Product deleted successfully."]);
    } else {
        http_response_code(404);
        echo json_encode(["error" => "Product not found."]);
    }
} else {
    http_response_code(500);
    echo json_encode(["error" => "Delete failed: " . $stmt->error]);
}

$stmt->close();
$conn->close();
?>
