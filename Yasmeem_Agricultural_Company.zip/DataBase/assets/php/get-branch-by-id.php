<?php
session_start();
header('Content-Type: application/json');

// DB connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

$conn = new mysqli($servername, $username, $password, $database, $port);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database_connection_failed"]);
    exit();
}

// Get branch ID from query string
if (!isset($_GET['id'])) {
    http_response_code(400);
    echo json_encode(["error" => "Missing_branch_id"]);
    exit();
}

$branch_id = intval($_GET['id']); // sanitize input

// Prepare and execute SQL
$stmt = $conn->prepare("SELECT * FROM Branch WHERE branch_id = ?");
$stmt->bind_param("i", $branch_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $row = $result->fetch_assoc()) {
    echo json_encode(["success" => true, "branch" => $row]);
} else {
    http_response_code(404);
    echo json_encode(["error" => "Branch_not_found"]);
}

$stmt->close();
$conn->close();
?>
