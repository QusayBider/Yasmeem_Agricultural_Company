<?php
header('Content-Type: application/json');

// Connection settings
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

session_start();

$conn = new mysqli($servername, $username, $password, $database, $port);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Connection failed: " . $conn->connect_error]);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
$required = ['account_id', 'title', 'start_date', 'end_date', 'status_offer', 'discount_percentage'];
foreach ($required as $field) {
    if (empty($data[$field])) {
        echo json_encode(['success' => false, 'error' => "$field is required"]);
        exit;
    }
}

// Get employee_id and name from account_id
$account_id = $data['account_id'];
$emp_query = $conn->prepare("SELECT e.employee_id, a.first_name, a.last_name 
                             FROM Employee e
                             JOIN Account_Table a ON e.account_id = a.account_id
                             WHERE e.account_id = ?");
$emp_query->bind_param("i", $account_id);
$emp_query->execute();
$emp_result = $emp_query->get_result();

if ($emp_result->num_rows === 0) {
    echo json_encode(['success' => false, 'error' => "No employee found for account_id $account_id"]);
    exit;
}

$employee = $emp_result->fetch_assoc();
$employee_id = $employee['employee_id'];
$created_by = $employee['first_name'] . ' ' . $employee['last_name']; // or just use ID if needed

// Insert offer
$stmt = $conn->prepare("INSERT INTO Offers (employee_id, title, start_date, end_date, status_offer, discount_percentage, created_by) 
                        VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("isssdds", 
    $employee_id,
    $data['title'],
    $data['start_date'],
    $data['end_date'],
    $data['status_offer'],
    $data['discount_percentage'],
    $created_by
);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => $stmt->error]);
}

$stmt->close();
$emp_query->close();
$conn->close();
?>
