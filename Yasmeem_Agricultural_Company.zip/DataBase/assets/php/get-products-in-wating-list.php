<?php
session_start();
header('Content-Type: application/json');

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

$conn = new mysqli($servername, $username, $password, $database, $port);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed"]);
    exit();
}

// SQL query to get branch name, product name, and image
$sql = "
    SELECT 
        bp.branch_product_id,
        b.name AS branch_name,
        p.name AS product_name,
        p.image AS product_image,
        bp.total_stock_quantity,
        bp.product_condition
    FROM 
        Branch_Product bp
    JOIN 
        Branch b ON bp.branch_id = b.branch_id
    JOIN 
        Product p ON bp.product_id = p.product_id
    WHERE 
        bp.product_condition = 'Product request'
";

$result = $conn->query($sql);

// Check for query error
if (!$result) {
    http_response_code(500);
    echo json_encode(["error" => "Query failed: " . $conn->error]);
    $conn->close();
    exit();
}

// Fetch results
$products = [];
while ($row = $result->fetch_assoc()) {
    $products[] = $row;
}

// Return JSON response
echo json_encode(["products" => $products]);

$conn->close();
?>
