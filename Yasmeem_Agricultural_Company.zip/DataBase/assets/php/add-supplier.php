<?php
session_start();
header('Content-Type: application/json');

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

$conn = new mysqli($servername, $username, $password, $database, $port);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

// Only allow POST method for adding new suppliers
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["error" => "Only POST method is allowed"]);
    exit();
}

// Get and validate input data
$data = json_decode(file_get_contents("php://input"), true);

if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid JSON input"]);
    exit();
}

// Required fields validation
$required_fields = ['first_name', 'last_name', 'email', 'phone_number', 'address'];
foreach ($required_fields as $field) {
    if (!isset($data[$field]) || empty(trim($data[$field]))) {
        http_response_code(400);
        echo json_encode(["error" => "Missing or empty field: " . $field]);
        exit();
    }
}

// Sanitize inputs
$first_name = $conn->real_escape_string(trim($data['first_name']));
$last_name = $conn->real_escape_string(trim($data['last_name']));
$email = $conn->real_escape_string(trim($data['email']));
$phone_number = $conn->real_escape_string(trim($data['phone_number']));
$address = $conn->real_escape_string(trim($data['address']));

// Additional validation
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid email format"]);
    exit();
}

if (!preg_match('/^[0-9]{10,15}$/', $phone_number)) {
    http_response_code(400);
    echo json_encode(["error" => "Phone number should be 10-15 digits"]);
    exit();
}

// Check if email already exists
$check_email = $conn->prepare("SELECT supplier_id FROM Supplier WHERE email = ?");
$check_email->bind_param("s", $email);
$check_email->execute();
$check_email->store_result();

if ($check_email->num_rows > 0) {
    http_response_code(409);
    echo json_encode(["error" => "Email already exists"]);
    $check_email->close();
    $conn->close();
    exit();
}
$check_email->close();

// Insert new supplier
$stmt = $conn->prepare("INSERT INTO Supplier (first_name, last_name, email, phone_number, address) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $first_name, $last_name, $email, $phone_number, $address);

if ($stmt->execute()) {
    $new_supplier_id = $stmt->insert_id;
    echo json_encode([
        "success" => true,
        "message" => "Supplier added successfully",
        "supplier_id" => $new_supplier_id
    ]);
} else {
    http_response_code(500);
    echo json_encode(["error" => "Failed to add supplier: " . $stmt->error]);
}

$stmt->close();
$conn->close();
?>