<?php
// Connection settings
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;
session_start();

// Set the response content type to JSON
header('Content-Type: application/json');

// Create connection
$conn = new mysqli($servername, $username, $password, $database, $port);

// Check connection
if ($conn->connect_error) {
    http_response_code(500); // Internal Server Error
    echo json_encode(["error" => "Connection failed: " . $conn->connect_error]);
    exit();
}

// Join Employee with Account_Table and branch to get employee details
$sql = " 
    SELECT 
        e.employee_id,
        e.position,
        e.account_id,
        e.manager_id,
        e.branch_id,
        a.first_name,
        a.last_name,    
        a.image,
        b.name AS branch_name,
        b.address,
        b.city,
        b.phone_number AS branch_phone
    FROM 
        Employee e
    JOIN 
        Account_Table a ON e.account_id = a.account_id
    JOIN 
        Branch b ON e.branch_id = b.branch_id
";

$result = $conn->query($sql);

$data = [];

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    echo json_encode(["employees" => $data]);
} else {
    echo json_encode(["employees" => []]);
}

// Close connection
$conn->close();
?>
