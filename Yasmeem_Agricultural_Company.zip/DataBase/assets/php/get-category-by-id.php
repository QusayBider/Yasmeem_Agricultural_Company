<?php
session_start();
header('Content-Type: application/json');

// DB connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

$conn = new mysqli($servername, $username, $password, $database, $port);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed"]);
    exit();
}

// Validate and get category ID from query or JSON
$category_id = 0;

// Support both GET and POST JSON
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['category_id'])) {
    $category_id = intval($_GET['category_id']);
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents("php://input"), true);
    $category_id = intval($input['category_id'] ?? 0);
}

if ($category_id <= 0) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid or missing category ID"]);
    exit();
}

// Fetch category from DB
$stmt = $conn->prepare("SELECT category_id, category_name, image FROM Category WHERE category_id = ?");
$stmt->bind_param("i", $category_id);
$stmt->execute();
$result = $stmt->get_result();
$category = $result->fetch_assoc();
$stmt->close();
$conn->close();

if ($category) {
    echo json_encode(["success" => true, "data" => $category]);
} else {
    http_response_code(404);
    echo json_encode(["error" => "Category not found"]);
}
?>
