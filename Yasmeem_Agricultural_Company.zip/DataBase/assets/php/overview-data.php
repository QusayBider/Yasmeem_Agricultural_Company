<?php
header('Content-Type: application/json');
session_start();

// DB connection
$servername = "localhost";
$username = "root";
$password = "";      
$database = "Yasmeem_Agricultural_Company";
$port = 3307;             

$conn = new mysqli($servername, $username, $password, $database, $port);

// Check connection
if ($conn->connect_error) {
    echo json_encode(["error" => "Connection failed: " . $conn->connect_error]);
    exit();
}

// Branch name and number of employees per branch
$branchEmployeesQuery = "
    SELECT b.name AS branch_name, COUNT(e.employee_id) AS employee_count
    FROM Branch b
    LEFT JOIN Employee e ON b.branch_id = e.branch_id
    GROUP BY b.branch_id
";

$branchResult = $conn->query($branchEmployeesQuery);
$branchEmployees = [];

while ($row = $branchResult->fetch_assoc()) {
    $branchEmployees[] = [
        'branch_name' => $row['branch_name'],
        'employee_count' => (int)$row['employee_count']
    ];
}

// General statistics (including min and max salary)
$statsQuery = "
    SELECT
        (SELECT COUNT(*) FROM Customer) AS total_customers,
        (SELECT COUNT(*) FROM Employee) AS total_employees,
        (SELECT COUNT(*) FROM Account_Table) AS total_accounts,
        (SELECT COUNT(*) FROM Employee) / NULLIF((SELECT COUNT(*) FROM Branch), 0) AS avg_employees_per_branch,
        (SELECT AVG(salary) FROM Employee) AS avg_salary,
        (SELECT MIN(salary) FROM Employee) AS min_salary,
        (SELECT MAX(salary) FROM Employee) AS max_salary,
        (SELECT COUNT(*) FROM Branch) AS total_branches,
        (SELECT COUNT(*) FROM Account_Table WHERE is_active = 'Active') AS active_users,
        (SELECT COUNT(*) FROM Account_Table WHERE is_active = 'Not-Active') AS inactive_users,
        (SELECT COUNT(*) FROM Account_Table WHERE LOWER(gender) = 'female') AS total_females,
        (SELECT COUNT(*) FROM Account_Table WHERE LOWER(gender) = 'male') AS total_males,
        (SELECT COUNT(DISTINCT manager_id) FROM Employee WHERE manager_id IS NOT NULL) AS total_managers
";

$statsResult = $conn->query($statsQuery);
$stats = [];

if ($statsResult && $row = $statsResult->fetch_assoc()) {
    $stats = [
        'total_customers' => (int)$row['total_customers'],
        'total_employees' => (int)$row['total_employees'],
        'total_accounts' => (int)$row['total_accounts'],
        'avg_employees_per_branch' => is_null($row['avg_employees_per_branch']) ? 0 : round((float)$row['avg_employees_per_branch'], 2),
        'avg_salary' => is_null($row['avg_salary']) ? 0 : round((float)$row['avg_salary'], 2),
        'min_salary' => is_null($row['min_salary']) ? 0 : round((float)$row['min_salary'], 2),
        'max_salary' => is_null($row['max_salary']) ? 0 : round((float)$row['max_salary'], 2),
        'total_branches' => (int)$row['total_branches'],
        'active_users' => (int)$row['active_users'],
        'inactive_users' => (int)$row['inactive_users'],
        'total_females' => (int)$row['total_females'],
        'total_males' => (int)$row['total_males'],
        'total_managers' => (int)$row['total_managers']
    ];
}

echo json_encode([
    'branch_employee_counts' => $branchEmployees,
    'statistics' => $stats
], JSON_PRETTY_PRINT);

$conn->close();
?>
