<?php
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', isset($_SERVER['HTTPS']));

session_start();

$timeout_duration = 1800; // 30 minutes in seconds

if (isset($_SESSION['LAST_ACTIVITY']) &&
    (time() - $_SESSION['LAST_ACTIVITY']) > $timeout_duration) {
    
    // Use server-side redirect
    header("Location: /DataBase/assets/php/logout.php");
    exit;
}


$_SESSION['LAST_ACTIVITY'] = time();

if (!isset($_SESSION['user_id'])) {
    http_response_code(401); 
    echo json_encode(["error" => "User not logged in"]);
    exit;
}

$response = [
    "user_id"      => $_SESSION['user_id'],
    "email"        => $_SESSION['email'],
    "user_name"    => $_SESSION['user_name'],
    "account_type" => $_SESSION['account_type']
];

if ($_SESSION['account_type'] === 'Employee') {
    $response['position'] = $_SESSION['position'];
}

echo json_encode($response);
exit;
?>
