<?php
// Enable error reporting (disable in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
header('Content-Type: application/json');

// DB connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

$conn = new mysqli($servername, $username, $password, $database, $port);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Connection failed: " . $conn->connect_error]);
    exit;
}

// Read JSON input
$data = json_decode(file_get_contents("php://input"), true);
if (!$data) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid JSON input"]);
    exit;
}

// Required fields
$required_fields = ['first_name', 'last_name', 'email', 'phone_number', 'account_type', 'image', 'date_of_birth', 'password', 'is_active', 'gender', 'address', 'city'];
foreach ($required_fields as $field) {
    if (empty($data[$field])) {
        http_response_code(400);
        echo json_encode(["error" => "Missing required field: $field"]);
        exit;
    }
}

// Sanitize input
$first_name = $conn->real_escape_string($data['first_name']);
$last_name = $conn->real_escape_string($data['last_name']);
$email = $conn->real_escape_string($data['email']);
$phone_number = $conn->real_escape_string($data['phone_number']);
$account_type = strtolower($conn->real_escape_string($data['account_type']));
$image = $conn->real_escape_string($data['image']);
$date_of_birth = $conn->real_escape_string($data['date_of_birth']);
$password = $data['password'];
$is_active = $conn->real_escape_string($data['is_active']);
$gender = $conn->real_escape_string($data['gender']);
$address = $conn->real_escape_string($data['address']);
$city = $conn->real_escape_string($data['city']);

// Validation checks
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid email format"]);
    exit;
}

if (!preg_match('/^[0-9]{1,10}$/', $phone_number)) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid phone number"]);
    exit;
}

if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/', $password)) {
    http_response_code(400);
    echo json_encode([
        "error" => "Password must be at least 8 characters and include uppercase, lowercase, a number, and a symbol."
    ]);
    exit;
}

// Check for existing email
$email_check_sql = "SELECT account_id FROM Account_Table WHERE email = '$email'";
$email_check_result = $conn->query($email_check_sql);

if ($email_check_result && $email_check_result->num_rows > 0) {
    http_response_code(409);
    echo json_encode(["error" => "Email_exists"]);
    exit;
}

// Hash password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Begin transaction
$conn->begin_transaction();

try {
    // Insert into Account_Table
    $sql = "INSERT INTO Account_Table (
        first_name, last_name, email, phone_number, account_type, image, date_of_birth,
        password_hash, is_active, gender, address, city, created_at
    ) VALUES (
        '$first_name', '$last_name', '$email', '$phone_number', '$account_type', '$image',
        '$date_of_birth', '$hashed_password', '$is_active', '$gender', '$address', '$city', NOW()
    )";

    if (!$conn->query($sql)) {
        throw new Exception("Account insert failed: " . $conn->error);
    }

    $account_id = $conn->insert_id;

    // If account_type is customer, insert into Customer
    if ($account_type === 'customer') {
        $customer_sql = "INSERT INTO Customer (account_id) VALUES ('$account_id')";
        if (!$conn->query($customer_sql)) {
            throw new Exception("Customer insert failed: " . $conn->error);
        }
    }

    $conn->commit();
    echo json_encode(["message" => "User created successfully!"]);

} catch (Exception $e) {
    $conn->rollback();
    http_response_code(500);
    echo json_encode(["error" => "Transaction failed: " . $e->getMessage()]);
}

$conn->close();
?>
