<?php
session_start();
header('Content-Type: application/json');

// DB connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

$conn = new mysqli($servername, $username, $password, $database, $port);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database_connection_failed"]);
    exit();
}

// Get and decode JSON input
$input = json_decode(file_get_contents("php://input"), true);

// Validate required fields
if (
    !isset($input['branch_id']) ||
    !isset($input['name']) ||
    !isset($input['address']) ||
    !isset($input['city']) ||
    !isset($input['street']) ||
    !isset($input['phone_number'])
) {
    http_response_code(400);
    echo json_encode(["error" => "Missing_fields"]);
    exit();
}

// Extract and sanitize input
$id = intval($input['branch_id']);
$name = $input['name'];
$address = $input['address'];
$city = $input['city'];
$street = $input['street'];
$phone_number = $input['phone_number'];

// Prepare SQL update
$stmt = $conn->prepare("UPDATE Branch SET name = ?, address = ?, city = ?, street = ?, phone_number = ? WHERE branch_id = ?");
$stmt->bind_param("sssssi", $name, $address, $city, $street, $phone_number, $id);

if ($stmt->execute()) {
    echo json_encode(["success" => true]);
} else {
    http_response_code(500);
    echo json_encode(["error" => "Update_failed"]);
}

$stmt->close();
$conn->close();
?>
