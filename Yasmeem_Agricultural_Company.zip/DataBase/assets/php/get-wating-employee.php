<?php
header('Content-Type: application/json');
session_start();
// Connection settings
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

// Create connection
$conn = new mysqli($servername, $username, $password, $database, $port);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Connection failed: " . $conn->connect_error]);
    exit;
}

// Get data: accounts not in employee table
$sql = "
    SELECT 
        a.account_id,
        a.first_name,
        a.last_name,
        a.email,
        a.phone_number,
        a.account_type,
        a.image,
        a.date_of_birth,
        a.created_at,
        a.address,
        a.city,
        a.is_active,
        a.gender
    FROM account_table a
    WHERE a.account_type='Employee' And a.account_id NOT IN (SELECT e.account_id FROM employee e)
";

$result = $conn->query($sql);

$Accounts = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $Accounts[] = [
            "account_id" => $row["account_id"],
            "avatar" => $row["image"],
            "first_name" => $row["first_name"],
            "last_name" => $row["last_name"],
            "email" => $row["email"],
            "phone_number" => $row["phone_number"],
            "account_type" => $row["account_type"],
            "Date_of_birth" => $row["date_of_birth"],
            "create_at" => $row["created_at"],
            "active_state" => $row["is_active"],
            "address" => $row["address"],
            "city" => $row["city"],
            "gender" => $row["gender"]
        ];
    }
}

$conn->close();

echo json_encode($Accounts);
?>
