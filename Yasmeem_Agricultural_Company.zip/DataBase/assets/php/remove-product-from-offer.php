<?php
session_start();
header('Content-Type: application/json');

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

$conn = new mysqli($servername, $username, $password, $database, $port);

// Get the raw POST data
$data = json_decode(file_get_contents('php://input'), true);

$data = json_decode(file_get_contents('php://input'), true);
$offer_id = filter_var($data['offer_id'], FILTER_VALIDATE_INT);
$product_id = filter_var($data['product_id'], FILTER_VALIDATE_INT);

if (!$offer_id || !$product_id) {
    echo json_encode(['success' => false, 'error' => 'Invalid data']);
    exit;
}

$query = $conn->prepare("DELETE FROM Product_Offers WHERE offers_id = ? AND product_id = ?");
$query->bind_param("ii", $offer_id, $product_id);

if ($query->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => $conn->error]);
}

$conn->close();
?>