<?php
header('Content-Type: application/json');

// Connection settings
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;
session_start();

$conn = new mysqli($servername, $username, $password, $database, $port);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Connection failed: " . $conn->connect_error]);
    exit;
}

$offer_id = $_GET['offer_id'];

// Get offer details
$offer_query = $conn->prepare("SELECT * FROM Offers WHERE offers_id = ?");
$offer_query->bind_param("i", $offer_id);
$offer_query->execute();
$offer_result = $offer_query->get_result();
$offer = $offer_result->fetch_assoc();

// Get products in this offer
$products_query = $conn->prepare("
    SELECT p.* FROM Product p
    JOIN Product_Offers po ON p.product_id = po.product_id
    WHERE po.offers_id = ?
");
$products_query->bind_param("i", $offer_id);
$products_query->execute();
$products_result = $products_query->get_result();
$products = $products_result->fetch_all(MYSQLI_ASSOC);

// Get all categories for dropdown
$categories_query = $conn->query("SELECT * FROM Category");
$categories = $categories_query->fetch_all(MYSQLI_ASSOC);

echo json_encode([
    'offer' => $offer,
    'products' => $products,
    'categories' => $categories
]);

$conn->close();
?>