<?php
header('Content-Type: application/json');
session_start();
// connection stting
$servername = "localhost";
$username = "root";
$password = "";      
$database = "Yasmeem_Agricultural_Company";
$port = 3307;             

// create connection
$conn = new mysqli($servername, $username, $password, $database, $port);

// Check the connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Connection failed: " . $conn->connect_error]);
    exit;
}

// Get the data from data base
$sql = "SELECT account_id,first_name,last_name,email,phone_number,account_type,image,date_of_birth,created_at,address,city, is_active,gender FROM account_table";
$result = $conn->query($sql);

$Accounts = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // change the name to be as js
        $Accounts[] = [
            "account_id" => $row["account_id"],
            "avatar" => $row["image"],
            "first_name" => $row["first_name"],
            "last_name" => $row["last_name"],
            "email" => $row["email"],
            "phone_number" => $row["phone_number"],
            "account_type" => $row["account_type"],
            "Date_of_birth" => $row["date_of_birth"],
            "create_at" => $row["created_at"],
            "active_state" => $row["is_active"],
            "address" => $row["address"],
            "city" => $row["city"],
            "gender" => $row["gender"]
        ];
    }
} else {
    $Accounts = [];
}

// close the connection
$conn->close();

// return the data as json
echo json_encode($Accounts);
?>
