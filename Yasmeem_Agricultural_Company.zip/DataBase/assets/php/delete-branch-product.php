<?php
header('Content-Type: application/json');
session_start();

// DB connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

if (!isset($_POST['branch_product_id'])) {
    echo json_encode([
        "status" => "error",
        "message" => "Missing branch_product_id"
    ]);
    exit();
}

$branch_product_id = intval($_POST['branch_product_id']);
$warehouse_id = 1;

$conn = new mysqli($servername, $username, $password, $database, $port);
if ($conn->connect_error) {
    echo json_encode([
        "status" => "error",
        "message" => "Connection failed: " . $conn->connect_error
    ]);
    exit();
}

$sql = "SELECT product_id, total_stock_quantity, product_condition FROM Branch_Product WHERE branch_product_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $branch_product_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode([
        "status" => "error",
        "message" => "Branch product not found"
    ]);
    $stmt->close();
    $conn->close();
    exit();
}

$row = $result->fetch_assoc();
$product_id = $row['product_id'];
$quantity = $row['total_stock_quantity'];
$product_condition = $row['product_condition'];
$stmt->close();

// Return quantity to warehouse if available
if ($product_condition === 'Available in branch') {
    $sql = "
        INSERT INTO Warehouse_Product (product_id, warehouse_id, total_stock_quantity)
        VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE total_stock_quantity = total_stock_quantity + VALUES(total_stock_quantity)
    ";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iii", $product_id, $warehouse_id, $quantity);
    if (!$stmt->execute()) {
        echo json_encode([
            "status" => "error",
            "message" => "Failed to update warehouse stock"
        ]);
        $stmt->close();
        $conn->close();
        exit();
    }
    $stmt->close();
}

// Delete from Branch_Product
$sql = "DELETE FROM Branch_Product WHERE branch_product_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $branch_product_id);
if ($stmt->execute()) {
    echo json_encode(["status" => "success"]);
} else {
    echo json_encode([
        "status" => "error",
        "message" => "Failed to delete product from branch"
    ]);
}

$stmt->close();
$conn->close();
?>
