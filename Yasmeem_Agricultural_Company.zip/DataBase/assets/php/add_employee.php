<?php
header('Content-Type: application/json');

// Connection settings
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;
session_start();
// Create connection
$conn = new mysqli($servername, $username, $password, $database, $port);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Connection failed: " . $conn->connect_error]);
    exit;
}

// Get input
$data = json_decode(file_get_contents("php://input"), true);

// Required fields check
if (!isset($data['account_id'])) {
    http_response_code(400);
    echo json_encode(["error" => "Missing required field: account_id"]);
    exit;
}
if (!isset($data['salary'])) {
    http_response_code(400);
    echo json_encode(["error" => "Missing required field: salary"]);
    exit;
}
if (!isset($data['branch_id'])) {
    http_response_code(400);
    echo json_encode(["error" => "Missing required field: branch_id"]);
    exit;
}

$account_id = $data['account_id'];
$branch_id = $data['branch_id'];
$salary = $data['salary'];
$manager_id = isset($data['manager_id']) ? $data['manager_id'] : null;
$position = isset($data['position']) ? $data['position'] : 'Employee';
$hire_date = isset($data['hire_date']) ? $data['hire_date'] : null;

// Validate numeric fields
if (!is_numeric($account_id) || $account_id <= 0) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid account_id. Must be a positive number."]);
    exit;
}

if (!is_numeric($branch_id) || $branch_id <= 0) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid branch_id. Must be a positive number."]);
    exit;
}

if (!is_numeric($salary) || $salary < 0) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid salary. Must be a non-negative number."]);
    exit;
}

if ($manager_id !== null && (!is_numeric($manager_id) || $manager_id <= 0)) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid manager_id. Must be a positive number or null."]);
    exit;
}

// Validate allowed positions
$allowed_positions = [
    'Employee',
    'Human Resources',
    'Branch Manager',
    'Warehouse Manager',
    'Accountant',
    'Head of Product',
    'Product Manager',
    'Customer Service',
    'IT'
];

if (!in_array($position, $allowed_positions)) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid position. Allowed values: " . implode(", ", $allowed_positions)]);
    exit;
}

// Validate hire_date if provided
if ($hire_date !== null && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $hire_date)) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid hire_date format. Expected YYYY-MM-DD."]);
    exit;
}

// Prepare and execute SQL
if ($hire_date !== null) {
    $sql = "INSERT INTO employee (account_id, branch_id, manager_id, position, salary, hire_date)
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iiisds", $account_id, $branch_id, $manager_id, $position, $salary, $hire_date);
} else {
    $sql = "INSERT INTO employee (account_id, branch_id, manager_id, position, salary, hire_date)
            VALUES (?, ?, ?, ?, ?, CURRENT_DATE)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iiisd", $account_id, $branch_id, $manager_id, $position, $salary);
}

if ($stmt->execute()) {
    echo json_encode(["message" => "Employee added successfully."]);
} else {
    http_response_code(500);
    echo json_encode(["error" => "Error adding employee: " . $stmt->error]);
}

$stmt->close();
$conn->close();
?>
