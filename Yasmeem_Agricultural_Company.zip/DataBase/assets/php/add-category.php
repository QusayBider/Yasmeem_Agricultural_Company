<?php
session_start();
header('Content-Type: application/json');

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

$conn = new mysqli($servername, $username, $password, $database, $port);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed"]);
    exit();
}

// Read and decode JSON input
$data = json_decode(file_get_contents("php://input"), true);

$category_name = trim($data['category_name'] ?? '');
$image = trim($data['image'] ?? '');

// Validate inputs
if (empty($category_name) || empty($image)) {
    http_response_code(400);
    echo json_encode(["error" => "Both category name and image are required"]);
    exit();
}

// Insert into database
$stmt = $conn->prepare("INSERT INTO Category (category_name, image) VALUES (?, ?)");
$stmt->bind_param("ss", $category_name, $image);

if ($stmt->execute()) {
    echo json_encode(["success" => "Category added successfully"]);
} else {
    http_response_code(500);
    echo json_encode(["error" => "Failed to add category"]);
}

$stmt->close();
$conn->close();
?>
