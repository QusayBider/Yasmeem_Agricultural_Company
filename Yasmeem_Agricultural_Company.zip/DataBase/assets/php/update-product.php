<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

header('Content-Type: application/json');

// Get the raw POST data
$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
$required_fields = ['product_id', 'name', 'supplier_id', 'category_id', 'price', 'wholesale_price', 'description_product', 'quantity'];

foreach ($required_fields as $field) {
    if (!isset($data[$field])) {
        http_response_code(400);
        echo json_encode(["error" => "Missing field: $field"]);
        exit;
    }
}

$product_id = intval($data['product_id']);
$name = $data['name'];
$supplier_id = intval($data['supplier_id']);
$category_id = intval($data['category_id']);
$price = floatval($data['price']);
$wholesale_price = floatval($data['wholesale_price']);
$description = $data['description_product'];
$quantity = intval($data['quantity']);
$image = isset($data['image']) && !empty(trim($data['image'])) ? $data['image'] : null;

$warehouse_id = 1; // Static warehouse for this use case

// Create connection
$conn = new mysqli($servername, $username, $password, $database, $port);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Connection failed: " . $conn->connect_error]);
    exit;
}

// Update Product table
if ($image === null) {
    $stmt = $conn->prepare("
        UPDATE Product 
        SET name = ?, supplier_id = ?, category_id = ?, price = ?, wholesale_price = ?, description_product = ?
        WHERE product_id = ?
    ");
    $stmt->bind_param("siiddsi", $name, $supplier_id, $category_id, $price, $wholesale_price, $description, $product_id);
} else {
    $stmt = $conn->prepare("
        UPDATE Product 
        SET name = ?, supplier_id = ?, category_id = ?, price = ?, wholesale_price = ?, image = ?, description_product = ?
        WHERE product_id = ?
    ");
    $stmt->bind_param("siiddssi", $name, $supplier_id, $category_id, $price, $wholesale_price, $image, $description, $product_id);
}

if (!$stmt->execute()) {
    http_response_code(500);
    echo json_encode(["error" => "Product update failed: " . $stmt->error]);
    $stmt->close();
    $conn->close();
    exit;
}
$stmt->close();

// Check if entry exists in Warehouse_Product
$checkStmt = $conn->prepare("
    SELECT total_stock_quantity 
    FROM Warehouse_Product 
    WHERE product_id = ? AND warehouse_id = ?
");
$checkStmt->bind_param("ii", $product_id, $warehouse_id);
$checkStmt->execute();
$checkResult = $checkStmt->get_result();

if ($checkResult->num_rows > 0) {
    // Update existing quantity
    $updateStmt = $conn->prepare("
        UPDATE Warehouse_Product 
        SET total_stock_quantity = ? 
        WHERE product_id = ? AND warehouse_id = ?
    ");
    $updateStmt->bind_param("iii", $quantity, $product_id, $warehouse_id);
} else {
    // Insert new warehouse-product relation
    $updateStmt = $conn->prepare("
        INSERT INTO Warehouse_Product (product_id, warehouse_id, total_stock_quantity)
        VALUES (?, ?, ?)
    ");
    $updateStmt->bind_param("iii", $product_id, $warehouse_id, $quantity);
}

if ($updateStmt->execute()) {
    echo json_encode(["success" => "Product and warehouse quantity updated successfully."]);
} else {
    http_response_code(500);
    echo json_encode(["error" => "Warehouse quantity update/insert failed: " . $updateStmt->error]);
}

$checkStmt->close();
$updateStmt->close();
$conn->close();
?>
