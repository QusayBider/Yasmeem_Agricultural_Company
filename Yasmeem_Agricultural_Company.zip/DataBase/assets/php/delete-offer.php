<?php
session_start();
header('Content-Type: application/json');

// Optional: Check session
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'success' => false,
        'error' => 'Unauthorized access'
    ]);
    exit;
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

$conn = new mysqli($servername, $username, $password, $database, $port);

// Check DB connection
if ($conn->connect_error) {
    echo json_encode([
        'success' => false,
        'error' => 'Database connection failed'
    ]);
    exit;
}

// Read JSON input
$input = json_decode(file_get_contents("php://input"), true);
$offer_id = isset($input['offer_id']) ? filter_var($input['offer_id'], FILTER_VALIDATE_INT) : null;

if (!$offer_id || $offer_id <= 0) {
    echo json_encode([
        'success' => false,
        'error' => 'Invalid offer ID provided'
    ]);
    exit;
}

// Start transaction
$conn->begin_transaction();

try {
    // Delete from Product_Offers
    $delete_product_offers = $conn->prepare("DELETE FROM Product_Offers WHERE offers_id = ?");
    $delete_product_offers->bind_param("i", $offer_id);
    $delete_product_offers->execute();

    // Delete from Offers
    $delete_offer = $conn->prepare("DELETE FROM Offers WHERE offers_id = ?");
    $delete_offer->bind_param("i", $offer_id);
    $delete_offer->execute();

    if ($delete_offer->affected_rows === 0) {
        throw new Exception("No offer found with ID: $offer_id");
    }

    // Commit transaction
    $conn->commit();

    echo json_encode([
        'success' => true,
        'message' => 'Offer and associated products successfully deleted'
    ]);

} catch (Exception $e) {
    $conn->rollback();
    error_log("Error deleting offer: " . $e->getMessage());

    echo json_encode([
        'success' => false,
        'error' => 'Failed to delete offer: ' . $e->getMessage()
    ]);
} finally {
    if (isset($delete_product_offers)) $delete_product_offers->close();
    if (isset($delete_offer)) $delete_offer->close();
    $conn->close();
}
?>
