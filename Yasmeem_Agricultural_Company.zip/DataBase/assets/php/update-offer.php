<?php
session_start();
header('Content-Type: application/json');

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

$conn = new mysqli($servername, $username, $password, $database, $port);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

$data = json_decode(file_get_contents('php://input'), true);

$offer_id = filter_var($data['offer_id'], FILTER_VALIDATE_INT);
$title = filter_var($data['title'], FILTER_SANITIZE_STRING);
$start_date = filter_var($data['start_date'], FILTER_SANITIZE_STRING);
$end_date = filter_var($data['end_date'], FILTER_SANITIZE_STRING);
$status_offer = filter_var($data['status_offer'], FILTER_SANITIZE_STRING);
$discount = filter_var($data['discount_percentage'], FILTER_VALIDATE_FLOAT);

if (!$offer_id || !$title || !$start_date || !$end_date || !$status_offer || $discount === false) {
    echo json_encode(['success' => false, 'error' => 'Invalid data']);
    exit;
}

$query = $conn->prepare("
    UPDATE Offers SET 
    title = ?,
    start_date = ?,
    end_date = ?,
    status_offer = ?,
    discount_percentage = ?
    WHERE offers_id = ?
");
$query->bind_param("ssssdi", $title, $start_date, $end_date, $status_offer, $discount, $offer_id);

if ($query->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => $conn->error]);
}

$conn->close();
?>