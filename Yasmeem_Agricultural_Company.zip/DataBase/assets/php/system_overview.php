<?php
session_start();
header('Content-Type: application/json');
error_reporting(0); // Turn off error reporting to prevent HTML in JSON output

// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

try {
    // Create PDO connection
    $pdo = new PDO("mysql:host=$servername;port=$port;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

    // Define all queries for dashboard statistics
    $queries = [
        // User statistics
        'active_users' => "SELECT COUNT(*) as count FROM Account_Table WHERE is_active = 'Active'",
        'inactive_users' => "SELECT COUNT(*) as count FROM Account_Table WHERE is_active = 'Not-Active'",
        'total_females' => "SELECT COUNT(*) as count FROM Account_Table WHERE gender = 'Female'",
        'total_males' => "SELECT COUNT(*) as count FROM Account_Table WHERE gender = 'Male'",
        'total_accounts' => "SELECT COUNT(*) as count FROM Account_Table",
        
        // Employee statistics
        'total_employees' => "SELECT COUNT(*) as count FROM Employee",
        'total_managers' => "SELECT COUNT(*) as count FROM Employee WHERE manager_id = employee_id",
        'employees_by_position' => "SELECT position, COUNT(*) as count FROM Employee GROUP BY position ORDER BY count DESC",
        
        // Customer statistics
        'total_customers' => "SELECT COUNT(*) as count FROM Customer",
        'customers_with_visa' => "SELECT COUNT(DISTINCT customer_id) as count FROM Visa_Table WHERE status = 'Active'",
        
        // Branch statistics
        'total_branches' => "SELECT COUNT(*) as count FROM Branch",
        'avg_employees_per_branch' => "SELECT AVG(emp_count) as avg FROM (SELECT branch_id, COUNT(*) as emp_count FROM Employee GROUP BY branch_id) as branch_emps",
        
        // Product statistics
        'total_products' => "SELECT COUNT(*) as count FROM Product",
        'products_in_warehouse' => "SELECT SUM(total_stock_quantity) as total FROM Warehouse_Product",
        'product_max_views' => "SELECT name, views_count FROM Product ORDER BY views_count DESC LIMIT 1",
        'product_max_rating' => "SELECT name, rate FROM Product ORDER BY rate DESC LIMIT 1",
        'category_distribution' => "SELECT c.category_name, COUNT(p.product_id) as product_count FROM Product p JOIN Category c ON p.category_id = c.category_id GROUP BY c.category_name ORDER BY product_count DESC",
        'max_category' => "SELECT c.category_name, COUNT(p.product_id) as product_count FROM Product p JOIN Category c ON p.category_id = c.category_id GROUP BY c.category_name ORDER BY product_count DESC LIMIT 1",
        
        // Branch product statistics
        'branch_product_stats' => "SELECT 
                                 MAX(total_stock_quantity) as max_products,
                                 MIN(total_stock_quantity) as min_products,
                                 AVG(total_stock_quantity) as avg_products
                                 FROM Branch_Product",
        
        // Order statistics
        'total_orders' => "SELECT COUNT(*) as count FROM Order_Table",
        'avg_order_amount' => "SELECT AVG(total_amount) as avg FROM Order_Table WHERE status_of_order != 'Cancelled'",
        'payment_method_distribution' => "SELECT payment_method, COUNT(*) as count FROM Order_Table GROUP BY payment_method",
        
        // Supplier statistics
        'total_suppliers' => "SELECT COUNT(*) as count FROM Supplier",
        'supplier_max_products' => "SELECT s.first_name, s.last_name, COUNT(p.product_id) as product_count 
                                   FROM Supplier s 
                                   JOIN Product p ON s.supplier_id = p.supplier_id 
                                   GROUP BY s.supplier_id 
                                   ORDER BY product_count DESC LIMIT 1",
        
        // Offer statistics
        'total_offers' => "SELECT COUNT(*) as count FROM Offers",
        'active_offers' => "SELECT COUNT(*) as count FROM Offers WHERE status_offer = 'Active'",
        'max_offer_discount' => "SELECT title, discount_percentage FROM Offers ORDER BY discount_percentage DESC LIMIT 1",
        
        // Sales analysis
        'wholesale_vs_retail' => "SELECT 
                                  SUM(od.quantity * p.wholesale_price) as wholesale_total,
                                  SUM(od.quantity * p.price) as retail_total,
                                  SUM(od.quantity * p.price) - SUM(od.quantity * p.wholesale_price) as difference
                                  FROM Order_Details od
                                  JOIN Product p ON od.product_id = p.product_id
                                  JOIN Order_Table o ON od.order_id = o.order_id
                                  WHERE o.status_of_order = 'Accepted' OR o.status_of_order = 'In_transit'",
        
        'order_amount_expexted' => "SELECT 
                                  SUM(od.quantity * p.wholesale_price) as wholesale_total_expexted,
                                  SUM(od.quantity * p.price) as retail_total_expexted,
                                  SUM(od.quantity * p.price) - SUM(od.quantity * p.wholesale_price) as difference_expexted
                                  FROM Order_Details od
                                  JOIN Product p ON od.product_id = p.product_id
                                  JOIN Order_Table o ON od.order_id = o.order_id
                                  WHERE o.status_of_order != 'Cancelled'",

        // Warehouse statistics
        'warehouse_inventory_value' => "SELECT SUM(wp.total_stock_quantity * p.wholesale_price) as total_value
                                       FROM Warehouse_Product wp
                                       JOIN Product p ON wp.product_id = p.product_id"
    ];

    // Execute all queries and collect results
    $results = [];
    foreach ($queries as $key => $query) {
        $stmt = $pdo->prepare($query);
        $stmt->execute();
        $results[$key] = $stmt->fetchAll();
    }

    // Return successful JSON response
    echo json_encode([
        'success' => true,
        'data' => $results,
        'last_updated' => date('Y-m-d H:i:s')
    ]);

} catch (PDOException $e) {
    // Return database error
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage(),
        'error_code' => $e->getCode()
    ]);
} catch (Exception $e) {
    // Return general error
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Application error: ' . $e->getMessage()
    ]);
}
?>