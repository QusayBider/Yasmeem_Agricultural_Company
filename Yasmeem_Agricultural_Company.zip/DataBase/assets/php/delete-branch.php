<?php
session_start();
header('Content-Type: application/json');

// DB connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

$conn = new mysqli($servername, $username, $password, $database, $port);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database_connection_failed"]);
    exit();
}

// Read JSON input
$input = json_decode(file_get_contents("php://input"), true);

// Check if ID is set
if (!isset($input['id'])) {
    http_response_code(400);
    echo json_encode(["error" => "Missing_branch_id"]);
    exit();
}

$branch_id = intval($input['id']); // Sanitize ID

// Prepare and execute DELETE statement
$stmt = $conn->prepare("DELETE FROM Branch WHERE branch_id = ?");
$stmt->bind_param("i", $branch_id);

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        echo json_encode(["success" => true, "message" => "Branch deleted successfully"]);
    } else {
        http_response_code(404);
        echo json_encode(["error" => "Branch_not_found"]);
    }
} else {
    http_response_code(500);
    echo json_encode(["error" => "Delete_failed"]);
}

$stmt->close();
$conn->close();
?>
