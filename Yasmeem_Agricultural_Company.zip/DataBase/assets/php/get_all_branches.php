<?php
// Database configuration
// DB connection
$servername = "localhost";
$username = "root";
$password = "";      
$database = "Yasmeem_Agricultural_Company";
$port = 3307;             

$conn = new mysqli($servername, $username, $password, $database, $port);

session_start();

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

// Query to get all branches
$sql = "SELECT * FROM Branch";
$result = $conn->query($sql);

// Initialize array to store branch objects
$branches = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $branches[] = $row; // Each row is already an associative array
    }
    echo json_encode($branches, JSON_PRETTY_PRINT);
} else {
    echo json_encode(["message" => "No branches found."]);
}

// Close connection
$conn->close();
?>
