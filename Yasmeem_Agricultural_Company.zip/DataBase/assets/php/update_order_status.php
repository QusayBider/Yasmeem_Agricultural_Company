<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

header('Content-Type: application/json');
session_start();

$conn = new mysqli($servername, $username, $password, $database, $port);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Connection failed: " . $conn->connect_error]);
    exit();
}

$data = json_decode(file_get_contents("php://input"), true);
$order_id = isset($data['order_id']) ? intval($data['order_id']) : null;
$new_status = isset($data['status_of_order']) ? $conn->real_escape_string($data['status_of_order']) : null;

if (!$order_id || !$new_status) {
    http_response_code(400);
    echo json_encode(["error" => "Missing order_id or status_of_order"]);
    exit();
}

// Get old status
$result = $conn->query("SELECT status_of_order FROM Order_Table WHERE order_id = $order_id");
if (!$result || $result->num_rows === 0) {
    http_response_code(404);
    echo json_encode(["error" => "Order not found."]);
    exit();
}
$old_status = $result->fetch_assoc()['status_of_order'];

// Begin transaction
$conn->begin_transaction();

try {
    if ($new_status === 'Accepted' && $old_status !== 'Accepted') {
        // Insert missing rows in Warehouse_Product with 0 quantity
        $ensureStockRowsSql = "
            INSERT INTO Warehouse_Product (product_id, warehouse_id, total_stock_quantity)
            SELECT od.product_id, 1, 0
            FROM Order_Details od
            WHERE od.order_id = $order_id
              AND NOT EXISTS (
                  SELECT 1 FROM Warehouse_Product wp 
                  WHERE wp.product_id = od.product_id AND wp.warehouse_id = 1
              )
        ";
        $conn->query($ensureStockRowsSql);

        // Check stock with product name
        $checkStockSql = "
            SELECT od.product_id, od.quantity, wp.total_stock_quantity, p.name AS product_name
            FROM Order_Details od
            JOIN Warehouse_Product wp ON od.product_id = wp.product_id
            JOIN Product p ON p.product_id = od.product_id
            WHERE od.order_id = $order_id AND wp.warehouse_id = 1
        ";
        $res = $conn->query($checkStockSql);
        $insufficient = [];

        while ($row = $res->fetch_assoc()) {
            if ($row['quantity'] > $row['total_stock_quantity']) {
                $insufficient[] = [
                    "product_id" => $row['product_id'],
                    "product_name" => $row['product_name'],
                    "available" => $row['total_stock_quantity'],
                    "required" => $row['quantity']
                ];
            }
        }

        if (!empty($insufficient)) {
            $conn->rollback();
            http_response_code(400);
            echo json_encode([
                "error" => "Insufficient stock for some products.",
                "details" => $insufficient
            ]);
            exit();
        }

        // Decrement stock
        $decrementSql = "
            UPDATE Warehouse_Product wp
            JOIN Order_Details od ON wp.product_id = od.product_id
            SET wp.total_stock_quantity = wp.total_stock_quantity - od.quantity
            WHERE od.order_id = $order_id AND wp.warehouse_id = 1
        ";
        $conn->query($decrementSql);

    } elseif ($new_status === 'Cancelled' && $old_status !== 'Cancelled') {
        // Return stock
        $incrementSql = "
            UPDATE Warehouse_Product wp
            JOIN Order_Details od ON wp.product_id = od.product_id
            SET wp.total_stock_quantity = wp.total_stock_quantity + od.quantity
            WHERE od.order_id = $order_id AND wp.warehouse_id = 1
        ";
        $conn->query($incrementSql);
    }

    // Update order status
    $updateSql = "UPDATE Order_Table SET status_of_order = '$new_status' WHERE order_id = $order_id";
    if (!$conn->query($updateSql)) {
        throw new Exception("Failed to update order status.");
    }

    $conn->commit();
    echo json_encode(["success" => "Order status updated successfully."]);

} catch (Exception $e) {
    $conn->rollback();
    http_response_code(500);
    echo json_encode(["error" => "Transaction failed: " . $e->getMessage()]);
}

$conn->close();
?>
