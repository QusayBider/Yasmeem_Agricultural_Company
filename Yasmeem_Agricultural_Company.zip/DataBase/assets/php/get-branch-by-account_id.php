<?php
// DB connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

$conn = new mysqli($servername, $username, $password, $database, $port);

session_start();

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

// Get account_id from request (GET or POST)
$account_id = isset($_GET['account_id']) ? intval($_GET['account_id']) : 0;

if ($account_id <= 0) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid or missing account_id."]);
    exit();
}

// SQL query to fetch branch name and id
$sql = "
    SELECT 
        b.branch_id,
        b.name AS branch_name
    FROM 
        Employee e
    INNER JOIN 
        Branch b ON e.branch_id = b.branch_id
    WHERE 
        e.account_id = ?
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $account_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $branch = $result->fetch_assoc();
    echo json_encode($branch);
} else {
    http_response_code(404);
    echo json_encode(["message" => "No branch found for this account ID."]);
}

$stmt->close();
$conn->close();
?>
