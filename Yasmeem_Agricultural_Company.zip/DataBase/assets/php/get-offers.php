<?php
session_start();
header('Content-Type: application/json');

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

$conn = new mysqli($servername, $username, $password, $database, $port);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
    exit();
}
try {
    // Get query parameters
    $start_date = $_GET['start_date'] ?? null;
    $end_date = $_GET['end_date'] ?? null;
    $employee_name = $_GET['employee_name'] ?? null;

    // Validate dates if provided
    if ($start_date && !strtotime($start_date)) {
        throw new Exception("Invalid start date format");
    }
    if ($end_date && !strtotime($end_date)) {
        throw new Exception("Invalid end date format");
    }

    // Build the base query
    $query = "SELECT 
                o.offers_id, 
                o.start_date, 
                o.end_date, 
                o.created_by, 
                o.status_offer, 
                o.discount_percentage, 
                o.title,
                CONCAT(a.first_name, ' ', a.last_name) AS employee_name,
                GROUP_CONCAT(p.name SEPARATOR ', ') AS products
              FROM Offers o
              JOIN Employee e ON o.employee_id = e.employee_id
              JOIN account_Table a ON e.account_id = a.account_id
              LEFT JOIN Product_Offers po ON o.offers_id = po.offers_id
              LEFT JOIN Product p ON po.product_id = p.product_id";

    // Add conditions based on input parameters
    $conditions = [];
    $params = [];
    $types = '';

    if ($start_date) {
        $conditions[] = "o.start_date >= ?";
        $params[] = $start_date;
        $types .= 's';
    }

    if ($end_date) {
        $conditions[] = "o.end_date <= ?";
        $params[] = $end_date;
        $types .= 's';
    }

    if ($employee_name) {
        $conditions[] = "(a.first_name LIKE ? OR a.last_name LIKE ?)";
        $params[] = "%$employee_name%";
        $params[] = "%$employee_name%";
        $types .= 'ss';
    }

    if (!empty($conditions)) {
        $query .= " WHERE " . implode(" AND ", $conditions);
    }

    // Group by offer
    $query .= " GROUP BY o.offers_id
                ORDER BY o.start_date DESC";

    // Prepare and execute the query
    $stmt = $conn->prepare($query);

    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }

    $stmt->execute();
    $result = $stmt->get_result();

    // Format the results
    $offers = [];
    while ($row = $result->fetch_assoc()) {
        $offers[] = [
            'id' => $row['offers_id'],
            'title' => $row['title'],
            'start_date' => $row['start_date'],
            'end_date' => $row['end_date'],
            'status' => $row['status_offer'],
            'discount' => $row['discount_percentage'],
            'created_by' => $row['created_by'],
            'employee_name' => $row['employee_name'],
            'products' => $row['products'] ? explode(', ', $row['products']) : []
        ];
    }

    // Return the response
    echo json_encode([
        'success' => true,
        'data' => $offers,
        'count' => count($offers)
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}

$conn->close();
?>