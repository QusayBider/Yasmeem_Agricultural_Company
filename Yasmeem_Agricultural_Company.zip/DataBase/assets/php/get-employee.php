<?php
// assets/php/get_employee.php

header("Content-Type: application/json");

// Connection settings
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;
session_start();
// Create connection
$conn = new mysqli($servername, $username, $password, $database, $port);
// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

// Get employee_id from GET or POST request
$employee_id = null;
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['employee_id'])) {
    $employee_id = intval($_GET['employee_id']);
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);
    if (isset($data['employee_id'])) {
        $employee_id = intval($data['employee_id']);
    }
}

if ($employee_id === null) {
    http_response_code(400);
    echo json_encode(["error" => "Missing employee_id parameter."]);
    exit();
}

// Prepare the SELECT statement
$sql = "SELECT * FROM Employee WHERE employee_id = ?";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    http_response_code(500);
    echo json_encode(["error" => "Failed to prepare statement: " . $conn->error]);
    exit();
}

$stmt->bind_param("i", $employee_id);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows === 0) {
    http_response_code(404);
    echo json_encode(["error" => "Employee not found."]);
} else {
    $employee = $result->fetch_assoc();
    echo json_encode($employee);
}

$stmt->close();
$conn->close();
?>
