<?php
session_start(); // Start the session at the top

// Database connection settings
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

// Create MySQLi connection
$conn = new mysqli($servername, $username, $password, $database, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form submitted via POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Invalid email format";
        exit;
    }

    // Prepare query to fetch user by email (include is_active)
    $stmt = $conn->prepare("SELECT account_id, first_name, email, password_hash, account_type, is_active FROM Account_Table WHERE email = ? LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    // Verify user and password
    if ($user && password_verify($password, $user['password_hash'])) {
        // Check if account is already active
        if ($user['is_active'] === 'Active') {
            echo "This account is already open on another site.";
            exit;
        }

        // Set session data
        $_SESSION['user_id'] = $user['account_id'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['user_name'] = $user['first_name'];
        $_SESSION['account_type'] = $user['account_type'];

        // If account is employee, get position
        if (strtolower($user['account_type']) === 'employee') {
            $empStmt = $conn->prepare("SELECT position FROM employee WHERE account_id = ?");
            $empStmt->bind_param("i", $user['account_id']);
            $empStmt->execute();
            $empResult = $empStmt->get_result();

            if ($empRow = $empResult->fetch_assoc()) {
                $_SESSION['position'] = $empRow['position'];
            } else {
                $_SESSION['position'] = null;
            }

            $empStmt->close();
        }

        // Mark user as active
        $updateStmt = $conn->prepare("UPDATE Account_Table SET is_active = 'Active' WHERE account_id = ?");
        $updateStmt->bind_param("i", $user['account_id']);
        $updateStmt->execute();
        $updateStmt->close();

        // Login successful
        echo "success";
    } else {
        // Invalid credentials
        echo "Invalid email or password";
    }

    $stmt->close();
}

$conn->close();
?>
