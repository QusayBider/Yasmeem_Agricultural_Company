<?php
// assets/php/delete_employee.php

header("Content-Type: application/json");

session_start();


// DB connection
$servername = "localhost";
$username = "root";
$password = "";      
$database = "Yasmeem_Agricultural_Company";
$port = 3307;             

$conn = new mysqli($servername, $username, $password, $database, $port);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

// Read JSON input
$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['account_id'])) {
    http_response_code(400);
    echo json_encode(["error" => "Missing account_id"]);
    exit();
}

$account_id = intval($data['account_id']);

// Prepare and execute DELETE statement
$sql = "DELETE FROM Employee WHERE account_id = ?";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    http_response_code(500);
    echo json_encode(["error" => "Failed to prepare statement: " . $conn->error]);
    exit();
}

$stmt->bind_param("i", $account_id);

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        echo json_encode(["message" => "Employee deleted successfully by account_id."]);
    } else {
        http_response_code(404);
        echo json_encode(["error" => "No employee found with the given account_id."]);
    }
} else {
    http_response_code(500);
    echo json_encode(["error" => "Failed to delete employee: " . $stmt->error]);
}

$stmt->close();
$conn->close();
?>

