<?php
// Connection settings
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

session_start();

$conn = new mysqli($servername, $username, $password, $database, $port);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Connection failed: " . $conn->connect_error]);
    exit;
}

// Get JSON data
$productData = json_decode(file_get_contents("php://input"), true);

// Required fields including quantity
$required = ['supplier_id', 'category_id', 'name', 'price', 'wholesale_price', 'image', 'description_product', 'quantity'];
foreach ($required as $field) {
    if (!isset($productData[$field])) {
        http_response_code(400);
        echo json_encode(["error" => "Missing field: $field"]);
        exit;
    }
}

// Assign values
$supplier_id = $productData['supplier_id'];
$category_id = $productData['category_id'];
$name = $productData['name'];
$price = $productData['price'];
$wholesale_price = $productData['wholesale_price'];
$image = $productData['image'];
$description = $productData['description_product'];
$quantity = $productData['quantity'];
$warehouse_id = 1; // Default warehouse

// Insert into Product table
$stmt = $conn->prepare("
    INSERT INTO Product (
        supplier_id, category_id,
        name, price, wholesale_price, image,
        description_product
    ) VALUES (?, ?, ?, ?, ?, ?, ?)
");

if (!$stmt) {
    http_response_code(500);
    echo json_encode(["error" => "Prepare failed: " . $conn->error]);
    exit;
}

$stmt->bind_param(
    "iisssss",
    $supplier_id, $category_id,
    $name, $price, $wholesale_price, $image,
    $description
);

if ($stmt->execute()) {
    $product_id = $conn->insert_id;

    // Insert into Warehouse_Product table
    $warehouseStmt = $conn->prepare("
        INSERT INTO Warehouse_Product (
            product_id, warehouse_id, total_stock_quantity
        ) VALUES (?, ?, ?)
    ");

    if (!$warehouseStmt) {
        http_response_code(500);
        echo json_encode(["error" => "Prepare warehouse insert failed: " . $conn->error]);
        exit;
    }

    $warehouseStmt->bind_param("iii", $product_id, $warehouse_id, $quantity);

    if ($warehouseStmt->execute()) {
        echo json_encode(["success" => "Product and warehouse stock added successfully."]);
    } else {
        http_response_code(500);
        echo json_encode(["error" => "Warehouse insert failed: " . $warehouseStmt->error]);
    }

    $warehouseStmt->close();
} else {
    http_response_code(500);
    echo json_encode(["error" => "Execution failed: " . $stmt->error]);
}

$stmt->close();
$conn->close();
?>
