<?php
// assets/php/add_employee.php

header("Content-Type: application/json");

session_start();

// DB connection
$servername = "localhost";
$username = "root";
$password = "";      
$database = "Yasmeem_Agricultural_Company";
$port = 3307;             

$conn = new mysqli($servername, $username, $password, $database, $port);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

// Read the JSON data from the request body
$data = json_decode(file_get_contents("php://input"), true);

// Validate required fields
if (
    !isset($data['emplloyee_id']) ||
    !isset($data['branch_id']) ||
    !isset($data['position']) ||
    !isset($data['salary']) ||
    !isset($data['hire_date'])
) {
    http_response_code(400);
    echo json_encode(["error" => "Missing required fields."]);
    exit();
}

$employee_id = intval($data['emplloyee_id']);
$branch_id = intval($data['branch_id']);
$manager_id = isset($data['manager_id']) ? intval($data['manager_id']) : null;
$position = $conn->real_escape_string($data['position']);
$salary = floatval($data['salary']);
$hire_date = $conn->real_escape_string($data['hire_date']);

// Prepare the UPDATE statement
$sql = "UPDATE Employee 
        SET branch_id = ?, manager_id = ?, position = ?, salary = ?, hire_date = ?
        WHERE employee_id = ?";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    http_response_code(500);
    echo json_encode(["error" => "Failed to prepare statement: " . $conn->error]);
    exit();
}

// Bind parameters (i = integer, d = double, s = string)
$stmt->bind_param("iisdsi", $branch_id, $manager_id, $position, $salary, $hire_date, $employee_id);

if ($stmt->execute()) {
    echo json_encode(["message" => "Employee updated successfully."]);
} else {
    http_response_code(500);
    echo json_encode(["error" => "Failed to update employee: " . $stmt->error]);
}

$stmt->close();
$conn->close();
?>
