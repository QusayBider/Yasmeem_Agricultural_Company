<?php
session_start();
header('Content-Type: application/json');

// DB connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

$conn = new mysqli($servername, $username, $password, $database, $port);
// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the raw POST data and decode it
$input = json_decode(file_get_contents("php://input"), true);

// Validate required fields
if (
    !isset($input['name']) ||
    !isset($input['address']) ||
    !isset($input['city']) ||
    !isset($input['street']) ||
    !isset($input['phone_number'])
) {
    http_response_code(400);
    echo json_encode(["error" => "Missing_fields"]);
    exit();
}

// Extract variables
$name = $input['name'];
$address = $input['address'];
$city = $input['city'];
$street = $input['street'];
$phone_number = $input['phone_number'];

// Insert branch
$stmt = $conn->prepare("INSERT INTO Branch (name, address, city, street, phone_number) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $name, $address, $city, $street, $phone_number);

if ($stmt->execute()) {
    echo json_encode(["success" => true]);
} else {
    http_response_code(500);
    echo json_encode(["error" => "Insert_failed"]);
}

// Clean up
$stmt->close();
$conn->close();
?>
