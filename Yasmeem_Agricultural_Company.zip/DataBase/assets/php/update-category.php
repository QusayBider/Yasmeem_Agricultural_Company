<?php
session_start();
header('Content-Type: application/json');

// DB connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

$conn = new mysqli($servername, $username, $password, $database, $port);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed"]);
    exit();
}

// Get input
$data = json_decode(file_get_contents("php://input"), true);

$category_id = intval($data['category_id'] ?? 0);
$category_name = trim($data['category_name'] ?? '');
$image = trim($data['image'] ?? '');

if ($category_id <= 0 || $category_name === '') {
    http_response_code(400);
    echo json_encode(["error" => "Category ID and name are required"]);
    exit();
}

// Get existing values
$stmt = $conn->prepare("SELECT category_name, image FROM Category WHERE category_id = ?");
$stmt->bind_param("i", $category_id);
$stmt->execute();
$result = $stmt->get_result();
$current = $result->fetch_assoc();
$stmt->close();

if (!$current) {
    http_response_code(404);
    echo json_encode(["error" => "Category not found"]);
    exit();
}

// Build update query dynamically
$fields = [];
$params = [];
$types = "";

if ($category_name !== $current['category_name']) {
    $fields[] = "category_name = ?";
    $params[] = $category_name;
    $types .= "s";
}

if (!empty($image) && $image !== $current['image']) {
    $fields[] = "image = ?";
    $params[] = $image;
    $types .= "s";
}

if (empty($fields)) {
    echo json_encode(["success" => "No changes made"]);
    exit();
}

$params[] = $category_id;
$types .= "i";

$sql = "UPDATE Category SET " . implode(", ", $fields) . " WHERE category_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);

if ($stmt->execute()) {
    echo json_encode(["success" => "Category updated successfully"]);
} else {
    http_response_code(500);
    echo json_encode(["error" => "Update failed"]);
}

$stmt->close();
$conn->close();
?>
