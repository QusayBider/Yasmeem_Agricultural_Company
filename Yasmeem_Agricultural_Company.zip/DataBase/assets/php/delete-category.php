<?php
session_start();
header('Content-Type: application/json');

// DB connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

$conn = new mysqli($servername, $username, $password, $database, $port);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed"]);
    exit();
}

// Get and validate category ID from JSON input
$data = json_decode(file_get_contents("php://input"), true);
$category_id = intval($data['category_id'] ?? 0);

if ($category_id <= 0) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid or missing category ID"]);
    exit();
}

// Check if category exists
$checkStmt = $conn->prepare("SELECT category_id FROM Category WHERE category_id = ?");
$checkStmt->bind_param("i", $category_id);
$checkStmt->execute();
$result = $checkStmt->get_result();
if ($result->num_rows === 0) {
    $checkStmt->close();
    http_response_code(404);
    echo json_encode(["error" => "Category not found"]);
    exit();
}
$checkStmt->close();

// Delete the category
$stmt = $conn->prepare("DELETE FROM Category WHERE category_id = ?");
$stmt->bind_param("i", $category_id);

if ($stmt->execute()) {
    echo json_encode(["success" => "Category deleted successfully"]);
} else {
    http_response_code(500);
    echo json_encode(["error" => "Failed to delete category"]);
}

$stmt->close();
$conn->close();
?>
