<?php
// Connection settings
$servername = "localhost";
$username = "root";
$password = "";
$database = "Yasmeem_Agricultural_Company";
$port = 3307;

header('Content-Type: application/json');
$conn = new mysqli($servername, $username, $password, $database, $port);
session_start();

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Connection failed: " . $conn->connect_error]);
    exit;
}

// Check if 'id' is provided in GET request
if (!isset($_GET['id'])) {
    http_response_code(400);
    echo json_encode(["error" => "Missing product ID."]);
    exit;
}

$product_id = $_GET['id'];
$warehouse_id = 1; // Assuming fixed warehouse

// Prepare SQL SELECT statement to get product + quantity
$stmt = $conn->prepare("
    SELECT 
        p.*, 
        wp.total_stock_quantity 
    FROM 
        Product p
    LEFT JOIN 
        Warehouse_Product wp 
        ON p.product_id = wp.product_id AND wp.warehouse_id = ?
    WHERE 
        p.product_id = ?
");

if (!$stmt) {
    http_response_code(500);
    echo json_encode(["error" => "Prepare failed: " . $conn->error]);
    exit;
}

$stmt->bind_param("ii", $warehouse_id, $product_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    http_response_code(404);
    echo json_encode(["error" => "Product not found."]);
} else {
    $product = $result->fetch_assoc();
    echo json_encode($product);
}

$stmt->close();
$conn->close();
?>
