
// Toggle between sign-in and sign-up views
fetch('/DataBase/assets/php/session.php',)
  .then(response => {
    if (response.ok) {
      window.location.href = '/DataBase/index.html';
      throw new Error("Redirecting to index...");
    }
    return response.json();
  })


const container = document.getElementById('container_sing');

function toggle() {

  container.classList.toggle('sign-in');
  container.classList.toggle('sign-up');
}

// Show sign-in form by default after a short delay
setTimeout(() => {
  container.classList.add('sign-in');
}, 200);

// Helper function to calculate age
function calculateAge(birthday) {
  const birthDate = new Date(birthday);
  const today = new Date();
  let age = today.getFullYear() - birthDate.getFullYear();
  const m = today.getMonth() - birthDate.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  return age;
}

// Helper function to validate email format
function isValidEmail(email) {
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return regex.test(email);
}

// Helper function to validate password strength
function isValidPassword(password) {
  const regex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;
  return regex.test(password);
}

function SignIn() {
  let ValidFlag = true;
  const username = document.getElementById("signin-username");
  const password = document.getElementById("signin-password");
  const password_error = document.querySelector(".password_error_singin");
  const username_error = document.querySelector(".username_error_singin");

  const passwordPattern = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[\W_]).{8,}$/;
  const usernamePattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

  // Validate username
  if (!usernamePattern.test(username.value)) {
    username_error.classList.remove("allertview");
    username_error.textContent = "Please enter a valid email.";
    username.classList.add("is-invalid");
    ValidFlag = false;
  } else {
    username_error.textContent = "";
    username.classList.remove("is-invalid");
    username_error.classList.add("allertview");
  }

  // Validate password
  if (!passwordPattern.test(password.value)) {
    password_error.classList.remove("allertview");
    password_error.textContent = "Please enter a valid password.";
    password.classList.add("is-invalid");
    ValidFlag = false;
  } else {
    password_error.textContent = "";
    password.classList.remove("is-invalid");
    password_error.classList.add("allertview");
  }

  // Submit if valid
  if (ValidFlag) {
    const xhttp = new XMLHttpRequest();
    xhttp.open("POST", "./assets/php/signin.php", true);
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

    xhttp.onreadystatechange = function () {
      if (this.readyState === 4 && this.status === 200) {
        if (this.responseText.trim() === "success") {
          window.location.href = "./index.html";
        } else if (this.responseText.trim() === "This account is already open on another site.") {
          Swal.fire({
            position: 'bottom-end',
            title: '⚠️ This account is already open on another site.',
            showConfirmButton: false,
            timer: 2000,
            background: '#dc2626',
            width: '25%' ,
            didOpen: () => {
              const swalTitle = Swal.getTitle();
              if (swalTitle) {
                swalTitle.style.color = '#fff';
                swalTitle.style.fontSize = '15px'; 
              }

            }
          });
        } else if (this.responseText.trim() === "Invalid email or password") {
          username.classList.add("is-invalid");
          password.classList.add("is-invalid");
          password_error.classList.remove("allertview");
          password_error.textContent = "The Username or Password is Incorrect.";
        }
      }

    };

    const params = `email=${encodeURIComponent(username.value)}&password=${encodeURIComponent(password.value)}`;
    xhttp.send(params);
  }
}


// Sign-up form validation
function validateSignup() {


  let ValidFlag = true;
  const firstName = document.getElementById("first_name");
  const lastName = document.getElementById("last_name");
  const email = document.getElementById("email");
  const password = document.getElementById("password");
  const confirmPassword = document.getElementById("confirm_password");
  const phone = document.getElementById("phone");
  const birthday = document.getElementById("birthday");
  const gender = document.getElementById("gender");
  //varible for alert in css 
  const Name_error_singUp = document.querySelector('.First_Name_Error');
  const Email_error_sinUp = document.querySelector('.Email_Error');
  const Password_error_sinUp = document.querySelector('.Password_Error');
  const confirm_Password_error_sinUp = document.querySelector('.Confrim_Password_Error');
  const Phone_error_sinUp = document.querySelector('.Phone_Error');
  const Birthday_error_sinUp = document.querySelector('.Birthday_Error');

  // Validate required fields

  const namePattern = /^[A-Za-z][A-Za-z\s]{0,29}$/;   // Starts with a letter, allows letters and spaces


  const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;  // Standard email format


  const passwordPattern = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[\W_]).{8,}$/;    // At least 8 characters, one uppercase, one lowercase, one digit, one special character


  const phonePattern = /^\d{10}$/;  // Exactly 10 digits





  if (!namePattern.test(firstName.value)) {
    Name_error_singUp.classList.remove("allertview");
    Name_error_singUp.innerHTML = "Name must start with a letter.";
    firstName.classList.add("is-invalid");
    ValidFlag = false;
  } else {
    Name_error_singUp.innerHTML = " ";
    firstName.classList.remove("is-invalid");
    Name_error_singUp.classList.add("allertview");
  }

  if (!namePattern.test(lastName.value)) {
    Name_error_singUp.classList.remove("allertview");
    Name_error_singUp.innerHTML = "Name must start with a letter.";
    lastName.classList.add("is-invalid");
    ValidFlag = false;
  } else {
    Name_error_singUp.innerHTML = " ";
    lastName.classList.remove("is-invalid");
    Name_error_singUp.classList.add("allertview");
  }

  if (!emailPattern.test(email.value)) {
    Email_error_sinUp.classList.remove("allertview");
    Email_error_sinUp.innerHTML = "Please enter a valid email address.";
    email.classList.add("is-invalid");
    ValidFlag = false;
  } else {
    Email_error_sinUp.innerHTML = " ";
    email.classList.remove("is-invalid");
    Email_error_sinUp.classList.add("allertview");
  }

  if (!passwordPattern.test(password.value)) {
    Password_error_sinUp.classList.remove("allertview");
    Password_error_sinUp.innerHTML = "Password must be at least 8 characters long and include uppercase, lowercase, a number, and a special character.";
    password.classList.add("is-invalid");
    ValidFlag = false;
  } else {
    Password_error_sinUp.innerHTML = " ";
    password.classList.remove("is-invalid");
    Password_error_sinUp.classList.add("allertview");
  }


  if (password.value != confirmPassword.value || confirmPassword.value === "") {
    confirm_Password_error_sinUp.classList.remove("allertview");
    confirm_Password_error_sinUp.innerHTML = "Passwords do not match. Please re-enter them.";
    confirmPassword.classList.add("is-invalid");
    ValidFlag = false;
  } else {
    confirm_Password_error_sinUp.innerHTML = " ";
    confirmPassword.classList.remove("is-invalid");
    confirm_Password_error_sinUp.classList.add("allertview");
  }

  if (!phonePattern.test(phone.value)) {
    Phone_error_sinUp.classList.remove("allertview");
    Phone_error_sinUp.innerHTML = "Phone number must be exactly 10 digits.";
    phone.classList.add("is-invalid");
    ValidFlag = false;
  } else {
    Phone_error_sinUp.innerHTML = " ";
    phone.classList.remove("is-invalid");
    Phone_error_sinUp.classList.add("allertview");
  }


  const age = calculateAge(birthday.value);

  if (age < 18 || birthday.value === "") {
    Birthday_error_sinUp.classList.remove("allertview");
    Birthday_error_sinUp.innerHTML = "Your age is under 18. ";
    birthday.classList.add("is-invalid");
    ValidFlag = false;
  }
  else {
    Birthday_error_sinUp.innerHTML = " ";
    birthday.classList.remove("is-invalid");
    Birthday_error_sinUp.classList.add("allertview");
  }
  if (gender.value === "") {
    gender.classList.add("is-invalid");
    ValidFlag = false;
  }
  else {
    gender.classList.remove("is-invalid");
  }
  if (ValidFlag) {
    const xhttp = new XMLHttpRequest();
    xhttp.open("POST", "./assets/php/signup.php", true);
    xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");

    xhttp.send(
      JSON.stringify({
        first_name: firstName.value,
        last_name: lastName.value,
        email: email.value,
        phone_number: phone.value,
        account_type: "Customer",
        date_of_birth: birthday.value,
        is_active: "not-Active",
        password: password.value,
        gender: gender.value,
        image: "https://res.cloudinary.com/dpjwslspm/image/upload/v1746740991/wsl6sxsu5tfonbfhmsga.png",
      }
      ));

    xhttp.onreadystatechange = function () {
      if (this.readyState == 4) {
        const response = JSON.parse(this.responseText);

        if (this.status == 200 && response.status === "success") {
          Swal.fire({
            position: 'bottom-end',
            title: '✅ Create success',
            showConfirmButton: false,
            timer: 1500,
            width: '25%', 
            background: '#047857',
            didOpen: () => {
              const swalTitle = Swal.getTitle();
              if (swalTitle) swalTitle.style.color = '#fff';
              swalTitle.style.fontSize = '15px'; 
            }
          }).then(() => {
            location.reload();
          });
        } else {
          const errorMessage = response.message || 'An unexpected error occurred.';
          Swal.fire({
            position: 'bottom-end',
            title: '❌ ' + errorMessage,
            showConfirmButton: false,
            timer: 2000,
            width: '25%', 
            background: '#dc2626',
            didOpen: () => {
              const swalTitle = Swal.getTitle();
              if (swalTitle) swalTitle.style.color = '#fff';
              swalTitle.style.fontSize = '15px'; 
            }
          });
        }
      }
    };


  }
}

