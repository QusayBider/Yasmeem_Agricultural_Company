fetch('/DataBase/assets/php/session.php',)
    .then(response => {
        if (!response.ok) {
            // Session is expired or not started, redirect to index
            window.location.href = '/DataBase/index.html';
            throw new Error("Redirecting to index...");
        }
        return response.json();
    })
    .then(data => {
        if (data.account_type !== 'Employee') {
            window.location.href = '/DataBase/index.html';
        } else {
            if (data.position === "IT" || data.position === "Human Resources" || data.position === "Customer Service") {
                document.querySelectorAll('[name="orders_process"]').forEach(elem => {
                    elem.classList.remove("hidden");
                });
            }
        }


    })

document.addEventListener("DOMContentLoaded", function (event) {
});

let currentOrdersPage = 1;
const rowsOrdersPerPage = 12;
let OrdersData = [];
let filteredOrdersData = [];

// Load Data
function loadOrdersTable() {
    const xhttp = new XMLHttpRequest();
    xhttp.open("GET", "./assets/php/get-orders.php", true);
    xhttp.send();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            const response = JSON.parse(this.responseText);

            if (response.success) {
                OrdersData = response.orders;
                filteredOrdersData = [...OrdersData];
                renderOrdersTable(currentOrdersPage);
                renderOrdersPagination(filteredOrdersData.length);
            } else {
                renderOrdersTable(currentOrdersPage)
            }
        }
    };
}


// Render Table
function renderOrdersTable(page) {
    currentOrdersPage = page;
    const start = (page - 1) * rowsOrdersPerPage;
    const end = start + rowsOrdersPerPage;
    const paginatedItems = filteredOrdersData.slice(start, end);

    const statusMap = {
        "Accepted": {
            bg: "bg-green-100 dark:bg-green-900",
            text: "text-green-800 dark:text-green-300",
            icon: `<path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 11.917 9.724 16.5 19 7.5" />`
        },
        "Cancelled": {
            bg: "bg-red-100 dark:bg-red-900",
            text: "text-red-800 dark:text-red-300",
            icon: `<path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18 17.94 6M18 18 6.06 6" />`
        },
        "In_transit": {
            bg: "bg-yellow-100 dark:bg-yellow-900",
            text: "text-yellow-800 dark:text-yellow-300",
            icon: `<path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h6l2 4m-8-4v8m0-8V6a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v9h2m8 0H9m4 0h2m4 0h2v-4m0 0h-5m3.5 5.5a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0Zm-10 0a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0Z" />`
        },
        "Waiting": {
            bg: "bg-gray-300 dark:bg-yellow-900",
            text: "text-yellow-800 dark:text-yellow-300",
            icon: `<svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-hourglass" viewBox="0 0 16 16">
                    <path d="M2 1.5a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-1v1a4.5 4.5 0 0 1-2.557 4.06c-.29.139-.443.377-.443.59v.7c0 .213.154.451.443.59A4.5 4.5 0 0 1 12.5 13v1h1a.5.5 0 0 1 0 1h-11a.5.5 0 1 1 0-1h1v-1a4.5 4.5 0 0 1 2.557-4.06c.29-.139.443-.377.443-.59v-.7c0-.213-.154-.451-.443-.59A4.5 4.5 0 0 1 3.5 3V2h-1a.5.5 0 0 1-.5-.5m2.5.5v1a3.5 3.5 0 0 0 1.989 3.158c.533.256 1.011.791 1.011 1.491v.702c0 .7-.478 1.235-1.011 1.491A3.5 3.5 0 0 0 4.5 13v1h7v-1a3.5 3.5 0 0 0-1.989-3.158C8.978 9.586 8.5 9.052 8.5 8.351v-.702c0-.7.478-1.235 1.011-1.491A3.5 3.5 0 0 0 11.5 3V2z"/>
                    </svg>`
        }
    };

    let trHTML = "";

    if (paginatedItems.length === 0) {
        trHTML = `<tr><td colspan="10" class="text-center">No Orders found</td></tr>`;
    } else {
        for (let order of paginatedItems) {
            const status = statusMap[order.status_of_order] || statusMap["Waiting"];

            // Button visibility
            const showCancel = order.status_of_order !== "Cancelled";
            const showAccept = order.status_of_order === "Waiting";
            const showInTransit = order.status_of_order === "Accepted";
            const showWaiting = order.status_of_order === "Cancelled";

            trHTML += `
            <div class="flex flex-wrap items-center gap-y-4 py-6 border-b border-gray-200">
                <dl class="w-1/2 sm:w-1/4 lg:w-auto lg:flex-1">
                    <dt class="text-base font-medium text-gray-500 dark:text-gray-400">Order ID:</dt>
                    <dd class="mt-1.5 text-base font-semibold text-gray-900">
                        <a href="#" class="hover:underline">${order.order_id}</a>
                    </dd>
                </dl>
                <dl class="w-1/2 sm:w-1/4 lg:w-auto lg:flex-1">
                    <dt class="text-base font-medium text-gray-500 dark:text-gray-400">Date:</dt>
                    <dd class="mt-1.5 text-base font-semibold text-gray-900">${order.order_date}</dd>
                </dl>
                <dl class="w-1/2 sm:w-1/4 lg:w-auto lg:flex-1">
                    <dt class="text-base font-medium text-gray-500 dark:text-gray-400">Total amount:</dt>
                    <dd class="mt-1.5 text-base font-semibold text-gray-900">$${order.total_amount}</dd>
                </dl>
                <dl class="w-1/2 sm:w-1/4 lg:w-auto lg:flex-1">
                    <dt class="text-base font-medium text-gray-500 dark:text-gray-400">Status:</dt>
                    <dd class="me-2 mt-1.5 inline-flex items-center rounded ${status.bg} px-2.5 py-0.5 text-xs font-medium ${status.text}">
                        <svg class="me-1 h-3 w-3" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            ${status.icon}
                        </svg>
                        ${order.status_of_order}
                    </dd>
                </dl>

                <div class="grid sm:grid-cols-3 lg:flex lg:w-64 lg:items-center lg:justify-end gap-4">
                    ${showCancel ? `
                        <button type="button" onclick="updateOrderStatus(${order.order_id},'Cancelled')"
                            class="rounded-lg border border-red-900 px-3 py-2 text-center text-xs font-medium text-red-700 hover:bg-red-700 hover:text-white focus:outline-none focus:ring-4 focus:ring-red-300">
                            Cancel
                        </button>
                    ` : showWaiting ? `
                        <button type="button" onclick="updateOrderStatus(${order.order_id},'Waiting')"
                            class="rounded-lg border border-gray-900 px-3 py-2 text-center text-xs font-medium text-gray-700 hover:bg-gray-700 hover:text-white focus:outline-none focus:ring-4 focus:ring-gray-300">
                            Waiting
                        </button>
                    ` : ""}

                    ${showAccept ? `
                        <button type="button" onclick="updateOrderStatus(${order.order_id},'Accepted')"
                            class="rounded-lg border border-green-900 px-3 py-2 text-center text-xs font-medium text-green-700 hover:bg-green-700 hover:text-white focus:outline-none focus:ring-4 focus:ring-green-300">
                            Accepted
                        </button>
                    ` : ""}

                    ${showInTransit ? `
                        <button type="button" onclick="updateOrderStatus(${order.order_id},'In_transit')"
                            class="rounded-lg border border-yellow-900 px-3 py-2 text-center text-xs font-medium text-yellow-700 hover:bg-yellow-700 hover:text-white focus:outline-none focus:ring-4 focus:ring-yellow-300">
                            Transit
                        </button>
                    ` : ""}

                    <button type="button" onclick="veiwOrderDetails(${order.order_id})"
                        class="rounded-lg border border-gray-900 px-3 py-2 text-center text-xs font-medium text-gray-700 hover:bg-gray-700 hover:text-white focus:outline-none focus:ring-4 focus:ring-gray-300">
                        Details
                    </button>
                </div>
            </div>`;
        }
    }

    document.getElementById("orders_table").innerHTML = trHTML;
}

// Render Pagination
function renderOrdersPagination(totalItems) {
    const totalPages = Math.ceil(totalItems / rowsOrdersPerPage);
    let paginationHTML = "";

    paginationHTML += `<li class="page-item ${currentOrdersPage === 1 ? "disabled" : ""}">
      <a class="page-link" href="#" onclick="changeOrdersPage(${currentOrdersPage - 1})">Previous</a>
    </li>`;

    for (let i = 1; i <= totalPages; i++) {
        paginationHTML += `<li class="page-item ${currentOrdersPage === i ? "active" : ""}">
      <a class="page-link" href="#" onclick="changeOrdersPage(${i})">${i}</a>
    </li>`;
    }

    paginationHTML += `<li class="page-item color-greey ${currentOrdersPage === totalPages ? "disabled" : ""}">
      <a class="page-link" href="#" onclick="changeOrdersPage(${currentOrdersPage + 1})">Next</a>
    </li>`;

    document.getElementById("orders_pagination").innerHTML = paginationHTML;
}
// Filter/Search
function filterOrdersTable(query) {
    query = query.toLowerCase();
    filteredOrdersData = OrdersData.filter((user) => {
        return (
            user.order_id.toString().includes(query) ||
            user.order_date.toLowerCase().includes(query) ||
            user.total_amount.toLowerCase().includes(query) ||
            user.status_of_order.toLowerCase().includes(query)
        );
    });

    currentProductPage = 1; // Reset to first page
    renderOrdersTable(currentOrdersPage);
    renderOrdersPagination(filteredOrdersData.length);
}
// Page Change
function changeOrdersPage(page) {
    const totalPages = Math.ceil(filteredOrdersData.length / rowsOrdersPerPage);
    if (page >= 1 && page <= totalPages) {
        renderOrdersTable(page);
        renderOrdersPagination(filteredOrdersData.length);
    }
}

function updateOrderStatus(orderId, newStatus) {
    const xhttp = new XMLHttpRequest();
    xhttp.open("POST", "./assets/php/update_order_status.php", true);
    xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");

    xhttp.send(JSON.stringify({
        order_id: orderId,
        status_of_order: newStatus
    }));

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4) {
            try {
                const response = JSON.parse(this.responseText);

                if (this.status == 200 && !response.error) {
                    Swal.fire({
                        position: 'bottom-end',
                        title: ' &#10004; ' + (response.success || 'Status updated.'),
                        showConfirmButton: false,
                        timer: 1500,
                        width: '25%',
                        background: '#047857',
                        didOpen: () => {
                            const swalTitle = Swal.getTitle();
                            if (swalTitle) {
                                swalTitle.style.color = '#fff';
                                swalTitle.style.fontSize = '15px';
                            }
                        }
                    });

                    overview();
                    loadOrdersTable();

                } else {
                    let errorMsg = response.error || 'Unknown error';
                    if (response.details && Array.isArray(response.details)) {
                        errorMsg += `<br><br><strong>Details:</strong><br>`;
                        response.details.forEach(item => {
                            errorMsg += `Product: <strong>${item.product_name}</strong> (ID: ${item.product_id})<br>`;
                            errorMsg += `Required: ${item.required}, Available: ${item.available}<br><br>`;
                        });
                    }
                    Swal.fire({
                        position: 'bottom-end',
                        html: ' &#10006; ' + errorMsg,
                        showConfirmButton: false,
                        timer: 4000,
                        width: '30%',
                        background: '#dfe8e5',
                        
                    });
                }
            }
            catch (e) {
                Swal.fire({
                    position: 'bottom-end',
                    title: ' &#10006; Server error',
                    showConfirmButton: false,
                    timer: 1500,
                    width: '25%',
                    background: '#800000',
                    didOpen: () => {
                        const swalTitle = Swal.getTitle();
                        if (swalTitle) {
                            swalTitle.style.color = '#fff';
                            swalTitle.style.fontSize = '15px';
                        }
                    }
                });
            }
        }
    };
}

function veiwOrderDetails(id) {

    const xhttp = new XMLHttpRequest();
    xhttp.open("GET", "./assets/php/get-full-orders-by-id.php?order_id=" + id, true); // corrected PHP file name
    xhttp.send();

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            const response = JSON.parse(this.responseText);
            if (!response.success) {
                Swal.fire("Error", "Order not found.", "error");
                return;
            }

            const order = response.order;

            // Build products HTML dynamically
            let productsHTML = "";
            let subtotal = 0;

            order.products.forEach(product => {
                const productTotal = parseFloat(product.product_total_price);
                subtotal += productTotal;

                productsHTML += `
                <tr>
                    <th scope="row">
                        <img src="${product.image}" alt="product-img" title="product-img" class="avatar-lg rounded">
                    </th>
                    <td>
                        <h5 class="font-size-16 text-truncate text-dark">${product.product_name}</h5>
                        <p class="text-muted mb-0 mt-1">$${product.unit_price} × ${product.quantity}</p>
                    </td>
                    <td>$${productTotal.toFixed(2)}</td>
                </tr>
            `;
            });

            const discount = 0; // Add logic if you want discount
            const shippingCharge = 0; // Add logic if applicable
            const total = subtotal - discount + shippingCharge;

            // Order payment method conditionally selected
            const isCash = order.payment_method === "Pay on Delivery";



            Swal.fire({
                title: "Edit and view details",
                showConfirmButton: false,
                width: '90%',
                html: `
                <div class="container">
                    <div class="row">
                        <div class="col-xl">
                            <div class="card">
                                <div class="card-body">
                                    <ol class="activity-checkout mb-0 px-4 mt-3">
                                        <li class="checkout-item">
                                            <div class="feed-item-list">
                                                <div class="p-3 bg-light mb-3">
                                                    <h5 class="font-size-16 mb-0 text-start">
                                                        Order number: <span class="ms-2 text-start">#${order.order_id}</span>
                                                    </h5>
                                                    <h5 class="font-size-16 mb-0 text-start">
                                                        Order date: <span class="ms-2 text-start">${order.order_date}</span>
                                                    </h5>
                                                </div>

                                                <form>
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <label class="form-label">Name</label>
                                                            <input type="text" class="form-control text-black" disabled value="${order.customer_name}">
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label class="form-label">Phone</label>
                                                            <input type="text" class="form-control text-black" disabled value="${order.phone_number}">
                                                        </div>
                                                    </div>
                                                    <div class="row mt-3">
                                                        <div class="col-lg-4">
                                                            <label class="form-label">City</label>
                                                            <input type="text" class="form-control text-black" disabled value="${order.city}">
                                                        </div>
                                                        <div class="col-lg-4">
                                                            <label class="form-label">Street</label>
                                                            <input type="text" class="form-control text-black" disabled value="${order.street}">
                                                        </div>
                                                        <div class="col-lg-4">
                                                            <label class="form-label">Apartment</label>
                                                            <input type="text" class="form-control text-black" disabled value="${order.apt_number}">
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </li>

                                        <li class="checkout-item">
                                            <div class="feed-item-list">
                                            <div class="row">
                                                <h5 class="font-size-14 mb-3 text-start">Payment method :</h5>
                                                    <div class="col-lg-6 col-sm-12" id="payment-methods">
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ol>
                                </div>
                            </div>

                            <div class="card">
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-centered mb-0 table-nowrap">
                                            <thead>
                                                <tr>
                                                    <th style="width: 110px;">Product</th>
                                                    <th>Product Desc</th>
                                                    <th>Price</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                ${productsHTML}
                                                <tr><td colspan="2" class="text-start"><strong>Sub Total:</strong></td><td>$${subtotal.toFixed(2)}</td></tr>
                                                <tr><td colspan="2" class="text-start"><strong>Discount:</strong></td><td>-$${subtotal.toFixed(2) - order.total_amount}</td></tr>
                                                <tr><td colspan="2" class="text-start"><strong>Shipping Charge:</strong></td><td>$${shippingCharge.toFixed(2)}</td></tr>
                                                <tr class="bg-light">
                                                    <td colspan="2" class="text-start"><strong>Total:</strong></td>
                                                    <td><strong>$${order.total_amount}</strong></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            `
            });
            if (isCash) {
                document.getElementById("payment-methods").innerHTML = `
            <label class="card-radio-label">
                <input type="radio" class="card-radio-input ${!isCash ? 'checked' : ''}">
                <span class="card-radio py-3 text-center text-truncate">
                    <i class="bx bx-credit-card d-block h2 mb-3"></i>
            Credit / Debit Card
                </span>
            </label>
                `;
            }
            else {
                document.getElementById("payment-methods").innerHTML = `<label class="card-radio-label">
                <input type="radio" class="card-radio-input"  ${isCash ? 'checked' : ""}>
                <span class="card-radio py-3 text-center text-truncate">
                    <i class="bx bx-money d-block h2 mb-3"></i> Cash on Delivery
                </span>
            </label>`;
            }
        }
    };


}

loadOrdersTable()