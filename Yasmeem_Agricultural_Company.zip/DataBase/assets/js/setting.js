const saveButton_Private_info = document.getElementById("saveChange_Private_info");
const saveChange_change_password = document.getElementById("saveChange_change_password");
const DeleteAccount_btn = document.getElementById("DeleteAccount-btn");
function session_setting_page() {
    const xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {

        if (this.readyState === 4) {
            if (this.status === 200) {
                const data = JSON.parse(this.responseText);
                const user_id = data.user_id;
                setting_page_Public_info(user_id);
                setting_page_Private_info(user_id);

                saveButton_Private_info.addEventListener("click", function (e) {
                    e.preventDefault();
                    Private_info_update(user_id);
                });
                saveChange_change_password.addEventListener("click", function (e) {
                    e.preventDefault(ChangePassword(user_id));

                });

                DeleteAccount_btn.addEventListener("click", function (e) {
                    e.preventDefault();
                    Swal.fire({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#dc2626',
                        cancelButtonColor: '#047857',
                        confirmButtonText: 'Yes, delete it!'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            const xhttp = new XMLHttpRequest();
                            const id = user_id; // Assuming user_id is the ID of the user to be deleted
                            xhttp.open("DELETE", "./assets/php/delete-user.php", true);
                            xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
                            xhttp.send(JSON.stringify({ id: id }));
                            xhttp.onreadystatechange = function () {
                                if (this.readyState == 4 && this.status == 200) {
                                    Swal.fire(
                                        'Deleted!',
                                        'Your account has been deleted.',
                                        'success'
                                    ).then(() => {
                                        window.location.href = "./assets/php/logout.php";
                                    });
                                }
                            };
                        }
                    });
                });
            }
            else {
                window.location.href = "./login_register.html";
            }
        }
    };

    xhttp.open("GET", "/DataBase/assets/php/session.php", true);
    xhttp.send();
}

session_setting_page();
let user;
function setting_page_Public_info(user_id) {
    const AccountSetting = document.getElementById("Setting_Public_info");
    const xhttp = new XMLHttpRequest();
    xhttp.open("GET", "./assets/php/get-user.php?id=" + user_id, true);
    xhttp.send();

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            user = JSON.parse(this.responseText).user;
            AccountSetting.innerHTML = `
            <div class="card-header">
                <h5 class="card-title mb-0">Public info</h5>
            </div>
            <div class="card-body">
                <form>
                    <div class="row">
                        <div class="col-md-8">
                            <div class="form-group">
                                <label for="inputUsername">Username</label>
                                <input type="text" class="form-control" id="inputUsername"
                                    placeholder="Username" disabled value="${user.first_name}_${user.last_name}">
                            </div>
                            <div class="form-group">
                                <label for="inputEmail4">Email</label>
                                <input type="email" class="form-control" id="inputEmail4"
                                    placeholder="Email" disabled value="${user.email}">
                            </div>
                        </div>
                        <div class="col-md-4 text-center">
                            <img alt="Profile" src="${user.image}"
                                class="rounded-circle img-responsive mt-2"
                                width="148" height="148">
                            <div class="flex items-center justify-center w-full mt-2">
                                <label for="dropzone-file"
                                    class="flex flex-col items-center justify-center w-full h-13 border-dashed rounded-lg cursor-pointer">
                                    <div class="flex flex-col items-center justify-center pt-1">
                                        <svg class="w-6 h-6 mb-1" aria-hidden="true"
                                            xmlns="http://www.w3.org/2000/svg"
                                            fill="none" viewBox="0 0 20 16">
                                            <path stroke="currentColor" stroke-linecap="round"
                                                stroke-linejoin="round" stroke-width="2"
                                                d="M13 13h3a3 3 0 0 0 0-6h-.025A5.56 5.56 0 0 0 16 6.5 
                                                5.5 5.5 0 0 0 5.207 5.021C5.137 5.017 5.071 5 5 5a4 4 0 0 0 0 8h2.167M10 
                                                15V6m0 0L8 8m2-2 2 2"/>
                                        </svg>
                                        <p class="mb-2 text-sm"><span class="font-semibold">Upload photo</span></p>
                                    </div>
                                    <input id="dropzone-file" type="file" class="hidden" />
                                </label>
                            </div>
                        </div>
                    </div>
                    <button id="save_change_publicInfo" class="btn btn-primary button_setting">Save changes</button>
                </form>
            </div>
        `;
            const fileInput = document.getElementById('dropzone-file');
            fileInput.addEventListener('change', async (event) => {
                const file = event.target.files[0];
                if (file) {
                    const uploadedUrl = await uploadImage(file);

                    if (uploadedUrl) {
                        update_Photo(
                            user_id,
                            uploadedUrl,
                        );
                        savebutton();
                    }
                }
            });

        }
    };
}

function setting_page_Private_info(user_id) {

    const Private_info = document.getElementById("Setting_Private_info");
    const xhttp = new XMLHttpRequest();
    xhttp.open("GET", "./assets/php/get-user.php?id=" + user_id, true);
    xhttp.send();

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            user = JSON.parse(this.responseText).user;
            show_Private_info(user);

        }
    };

}

function show_Private_info(user) {
    const FirstName = document.getElementById("inputFirstName");
    const LastName = document.getElementById("inputLastName");
    const Phone_number = document.getElementById("inputphone");
    const Address = document.getElementById("inputAddress");
    const City = document.getElementById("inputCity");
    const gender = document.getElementById("inputGender");
    const date_of_birth = document.getElementById("inputData_of_birth");

    FirstName.value = user.first_name;
    LastName.value = user.last_name;
    Phone_number.value = user.phone_number;
    Address.value = user.address;
    City.value = user.city;
    gender.value = user.gender;
    date_of_birth.value = user.date_of_birth;
}


function Private_info_update(user_id) {
    let ValidFlag = true;
    const FirstName = document.getElementById("inputFirstName");
    const LastName = document.getElementById("inputLastName");
    const Phone_number = document.getElementById("inputphone");
    const Address = document.getElementById("inputAddress");
    const City = document.getElementById("inputCity");
    const Gender = document.getElementById("inputGender");
    const Date_of_birth = document.getElementById("inputData_of_birth");


    //varible for alert in css 
    const FirstName_error = document.querySelector('.FirstName_error');
    const Address_error = document.querySelector('.Address_error');
    const LastName_error = document.querySelector('.LastName_error');
    const City_error = document.querySelector('.City_error');
    const Phone_error = document.querySelector('.Phone_Error');
    const Birthday_error = document.querySelector('.Birthday_Error');

    const namePattern = /^[A-Za-z][A-Za-z\s]{0,29}$/;   // Starts with a letter, allows letters and spaces
    const phonePattern = /^\d{10}$/;  // Exactly 10 digits


    if (!namePattern.test(FirstName.value)) {
        FirstName_error.classList.remove("allertview");
        FirstName_error.innerHTML = "First name must start with a letter.";
        FirstName.classList.add("is-invalid");
        ValidFlag = false;
    } else {
        FirstName_error.innerHTML = " ";
        FirstName.classList.remove("is-invalid");
        FirstName_error.classList.add("allertview");
    }

    if (!namePattern.test(LastName.value)) {
        LastName_error.classList.remove("allertview");
        LastName_error.innerHTML = "Last name must start with a letter.";
        LastName.classList.add("is-invalid");
        ValidFlag = false;
    } else {
        LastName_error.innerHTML = " ";
        LastName.classList.remove("is-invalid");
        LastName_error.classList.add("allertview");
    }

    if (!namePattern.test(Address.value)) {
        Address_error.classList.remove("allertview");
        Address_error.innerHTML = "Address must start with a letter.";
        Address.classList.add("is-invalid");
        ValidFlag = false;
    } else {
        Address_error.innerHTML = " ";
        Address.classList.remove("is-invalid");
        Address_error.classList.add("allertview");
    }

    if (!namePattern.test(City.value)) {
        City_error.classList.remove("allertview");
        City_error.innerHTML = "City must start with a letter.";
        City.classList.add("is-invalid");
        ValidFlag = false;
    } else {
        City_error.innerHTML = " ";
        City.classList.remove("is-invalid");
        City_error.classList.add("allertview");
    }


    if (!phonePattern.test(Phone_number.value)) {
        Phone_error.classList.remove("allertview");
        Phone_error.innerHTML = "Phone number must be exactly 10 digits.";
        Phone_number.classList.add("is-invalid");
        ValidFlag = false;
    } else {
        Phone_error.innerHTML = " ";
        Phone_number.classList.remove("is-invalid");
        Phone_error.classList.add("allertview");
    }


    const age = calculateAge(Date_of_birth.value);

    if (age < 18 || Date_of_birth.value === "") {
        Birthday_error.classList.remove("allertview");
        Birthday_error.innerHTML = "Your age is under 18. ";
        Date_of_birth.classList.add("is-invalid");
        ValidFlag = false;
    }
    else {
        Birthday_error.innerHTML = " ";
        Date_of_birth.classList.remove("is-invalid");
        Birthday_error.classList.add("allertview");
    }

    if (ValidFlag) {

        const data = {
            account_id: user_id,
            first_name: FirstName.value,
            last_name: LastName.value,
            phone_number: Phone_number.value,
            date_of_birth: Date_of_birth.value,
            gender: Gender.value,
            address: Address.value,
            city: City.value,
        };


        const xhttp = new XMLHttpRequest();
        xhttp.open("PUT", "./assets/php/update-user.php", true);
        xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
        xhttp.send(JSON.stringify(data));
        console.log(data);
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4) {
                try {
                    const res = JSON.parse(this.responseText);
                    if (this.status == 200 && !res.error) {
                        Swal.fire("Success", res.message, "success");
                        session_setting_page();
                    } else {
                        Swal.fire("Error", res.error || "Update failed", "error");
                    }
                } catch (err) {
                    Swal.fire("Error", "Invalid server response.", "error");

                }
            }
        };
    }
}


function calculateAge(birthday) {
    const birthDate = new Date(birthday);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }
    return age;
}


// Attach this ONCE after DOM is loaded
function savebutton() {
    const saveButton = document.getElementById('save_change_publicInfo');
    saveButton.addEventListener("click", function (e) {
        e.preventDefault();

        if (!window.updatedUserData) {
            Swal.fire("Error", "No user data to update.", "error");
            return;
        }

        const xhttp = new XMLHttpRequest();
        xhttp.open("PUT", "./assets/php/update-user.php", true);
        xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
        xhttp.send(JSON.stringify(window.updatedUserData));

        xhttp.onreadystatechange = function () {
            if (this.readyState === 4) {
                try {
                    const res = JSON.parse(this.responseText);

                    if (this.status === 200 && !res.error) {
                        Swal.fire("Success", res.message, "success");
                        setting_page_Public_info(window.updatedUserData.account_id);
                    } else {
                        Swal.fire("Error", res.error || "Update failed", "error");
                    }
                } catch (err) {
                    Swal.fire("Error", "Invalid server response.", "error");
                }
            }
        };
    });
}


// Call this function when the user info needs to be stored
function update_Photo(id, image_uploaded) {
    // Store data to be used later

    window.updatedUserData = {
        account_id: id,
        image: image_uploaded,
    };
}


async function uploadImage(file) {
    const formData = new FormData();
    formData.append("file", file);
    formData.append("upload_preset", "unsigned_user_uploads");

    try {
        const res = await fetch("https://api.cloudinary.com/v1_1/dpjwslspm/image/upload", {
            method: "POST",
            body: formData
        });

        const data = await res.json();

        if (data.secure_url) {
            document.querySelector("img[alt='Profile']").src = data.secure_url;
            return data.secure_url;
        } else {
            Swal.fire("Upload Error", data.error?.message || "Failed to upload image.", "error");
            return null;
        }
    } catch (err) {
        Swal.fire("Upload Error", "Something went wrong while uploading.", "error");
        return null;
    }
}

function ChangePassword(user_id) {
    const CurrentPassword = document.getElementById("inputPasswordCurrent");
    const password = document.getElementById("inputPasswordNew");
    const confirmPassword = document.getElementById("inputPasswordNew2");

    const Currentpassword_Error = document.querySelector('.Currentpassword_Error');
    const Password_error = document.querySelector('.Password_Error');
    const confirm_Password_error = document.querySelector('.Confrim_Password_Error');

    const passwordPattern = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[\W_]).{8,}$/;    // At least 8 characters, one uppercase, one lowercase, one digit, one special character

    let ValidFlag = true;
    if (!passwordPattern.test(password.value)) {
        Password_error.classList.remove("allertview");
        Password_error.innerHTML = "Password must be at least 8 characters long and include uppercase, lowercase, a number, and a special character.";
        password.classList.add("is-invalid");
        ValidFlag = false;
    } else {
        Password_error.innerHTML = " ";
        password.classList.remove("is-invalid");
        Password_error.classList.add("allertview");
    }

    if (password.value != confirmPassword.value || confirmPassword.value === "") {
        confirm_Password_error.classList.remove("allertview");
        confirm_Password_error.innerHTML = "Passwords do not match. Please re-enter them.";
        confirmPassword.classList.add("is-invalid");
        ValidFlag = false;
    } else {
        confirm_Password_error.innerHTML = " ";
        confirmPassword.classList.remove("is-invalid");
        confirm_Password_error.classList.add("allertview");
    }

    if (ValidFlag) {

        const xhttp = new XMLHttpRequest();
        xhttp.open("POST", "./assets/php/signin.php", true);
        xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

        xhttp.onreadystatechange = function () {
            if (this.readyState === 4 && this.status === 200) {
                if (this.responseText.trim() === "success") {

                    const data = {
                        account_id: user_id,
                        password: password.value,
                    };
                    const xhttp = new XMLHttpRequest();
                    xhttp.open("PUT", "./assets/php/update-user.php", true);
                    xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
                    xhttp.send(JSON.stringify(data));
                    console.log(data);
                    xhttp.onreadystatechange = function () {
                        if (this.readyState == 4) {
                            try {
                                const res = JSON.parse(this.responseText);
                                if (this.status == 200 && !res.error) {
                                    Swal.fire("Success", res.message, "success");
                                    session_setting_page();
                                } else {
                                    Swal.fire("Error", res.error || "Update failed", "error");
                                }
                            } catch (err) {
                                Swal.fire("Error", "Invalid server response.", "error");

                            }
                        }
                    };







                } else {
                    password.classList.add("is-invalid");
                    Currentpassword_Error.classList.remove("allertview");
                    Currentpassword_Error.textContent = "The Password is Incorrect.";
                }
            }
        };

        const params = `email=${encodeURIComponent(user.email)}&password=${encodeURIComponent(CurrentPassword.value)}`;
        xhttp.send(params);
    }


}

