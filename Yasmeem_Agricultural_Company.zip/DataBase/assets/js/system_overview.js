

const fmt = (n) => Number(n || 0).toLocaleString();
const money = (n) => '$' + (Number(n || 0).toFixed(2));

document.addEventListener('DOMContentLoaded', () => {
    fetch('./assets/php/system_overview.php')
        .then(r => r.json())
        .then(res => {
            if (!res.success) throw new Error(res.message || 'Unknown error');
            const s = res.data;
            console.log('System Overview Data:', s);
            const map = {
                'total-products': s.total_products[0].count,
                'products-in-warehouse': s.products_in_warehouse[0].total,
                'active-users': s.active_users[0].count,
                'inactive-users': s.inactive_users[0].count,
                'total-females': s.total_females[0].count,
                'total-males': s.total_males[0].count,
                'total-accounts': s.total_accounts[0].count,
                'total-employees': s.total_employees[0].count,
                'total-managers': s.total_managers[0].count,
                'total-customers': s.total_customers[0].count,
                'customers-with-visa': s.customers_with_visa[0].count,
                'total-branches': s.total_branches[0].count,
                'avg-employees-branch': s.avg_employees_per_branch[0].avg,
                'total-orders': s.total_orders[0].count,
                'total-suppliers': s.total_suppliers[0].count,
                'total-offers': s.total_offers[0].count,
                'active-offers': s.active_offers[0].count,
                'max-products-branch': s.branch_product_stats[0].max_products,
                'min-products-branch': s.branch_product_stats[0].min_products,
                'avg-products-branch': s.branch_product_stats[0].avg_products,
                'product_max_views': s.product_max_views[0].views_count,
                'category_distribution': s.category_distribution[0].product_count,
                'payment_method_distribution': s.payment_method_distribution[0].payment_count,
                
            };
            for (const [id, val] of Object.entries(map)) {
                const el = document.getElementById(id);
                if (el) el.textContent = fmt(val);
            }


            // ===== currency / percentage fields =====
            document.getElementById('inventory-value').textContent = money(s.warehouse_inventory_value[0].total_value);
            document.getElementById('avg-order-amount').textContent = money(s.avg_order_amount[0].avg);
            document.getElementById('total-sales').textContent = money(s.wholesale_vs_retail[0].retail_total);
            document.getElementById('sales-profit').textContent = money(s.wholesale_vs_retail[0].difference);
            document.getElementById('order_amount_expexted').textContent = money(s.order_amount_expexted[0].retail_total_expexted);
            document.getElementById('max-offer-discount').textContent =
                (s.max_offer_discount[0].discount_percentage || 0) + '%';
            order_chart(
                s.warehouse_inventory_value[0].total_value,
                s.wholesale_vs_retail[0].retail_total,
                s.wholesale_vs_retail[0].difference
            );
        })
        .catch(err => console.error('Stats load failed:', err.message));
});

function order_chart(Inventory_Value, Retail_Total, Profit) {
    const colors = ['#33b2df', '#546E7A', '#d4526e'];

    const options = {
        series: [{
            data: [
                Retail_Total,  // Total Amount
                Profit,        // Sales Profit
                Inventory_Value // Inventory Value
            ]
        }],
        chart: {
            height: 350,
            type: 'bar',
            events: {
                click: function (chart, w, e) {
                    // Optional: Add interactivity
                }
            }
        },
        colors: colors,
        plotOptions: {
            bar: {
                columnWidth: '45%',
                distributed: true
            }
        },
        dataLabels: {
            enabled: false
        },
        legend: {
            show: false
        },
        xaxis: {
            categories: [
                'Total Amount',
                'Sales Profit',
                'Inventory Value'
            ],
            labels: {
                style: {
                    colors: colors,
                    fontSize: '12px'
                }
            }
        }
    };

    const chart = new ApexCharts(document.querySelector("#order_chart"), options);
    chart.render();
}