fetch('/DataBase/assets/php/session.php',)
    .then(response => {
        if (!response.ok) {
            // Session is expired or not started, redirect to index
            window.location.href = '/DataBase/index.html';
            throw new Error("Redirecting to index...");
        }
        return response.json();
    })
    .then(data => {
        if (data.account_type !== 'Employee') {
            window.location.href = '/DataBase/index.html';
        } else {
            if (data.position === "IT" || data.position === "Human Resources" || data.position === "Head of Product") {
                document.querySelectorAll('[name="products_process"]').forEach(elem => {
                    elem.classList.remove("hidden");
                    employee_in_sesstion_id = data.user_id;
                });
            }
        }


    })

document.addEventListener("DOMContentLoaded", function (event) {
});
let employee_in_sesstion_id;
let currentProductPage = 1;
const rowsproductPerPage = 12;
let ProductData = [];
let filteredProductData = [];

let currentcategoriesPage = 1;
const rowscategoriesPerPage = 12;
let categoriesData = [];
let filteredcategoriesData = [];

// Load Data
function loadproductTable() {
    const xhttp = new XMLHttpRequest();
    xhttp.open("GET", "./assets/php/get-products.php", true);
    xhttp.send();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            ProductData = JSON.parse(this.responseText);
            filteredProductData = [...ProductData]; // Start with full data
            renderproductTable(currentProductPage);
            renderproductPagination(filteredProductData.length);
        }
    };
}

// Render Table
function renderproductTable(page) {
    currentProductPage = page;
    const start = (page - 1) * rowsproductPerPage;
    const end = start + rowsproductPerPage;
    const paginatedItems = filteredProductData.slice(start, end);

    let trHTML = "";

    if (paginatedItems.length === 0) {
        trHTML += `<tr><td colspan="10" class="text-center">No products found</td></tr>`;
    } else {
        for (let product of paginatedItems) {
            trHTML += "<tr>";
            trHTML += "<td>" + product["product_id"] + "</td>";
            trHTML += '<td><img width="50px" src="' + product["image"] + '" alt="Product Image"></td>';
            trHTML += "<td>" + product["product_name"] + "</td>";
            trHTML += "<td>" + product["price"] + "</td>";
            trHTML += "<td>" + product["wholesale_price"] + "</td>";
            trHTML += "<td>" + product["description_product"] + "</td>";
            trHTML += "<td>" + product["category_name"] + "</td>";
            trHTML += "<td>" + product["supplier_name"] + "</td>";
            trHTML += "<td>" + product["rate"] + "</td>";
            trHTML += "<td>" + product["views_count"] + "</td>";
            trHTML +=
                '<td><button class="btn btn-outline-secondary" onclick="showProductEditBox(' +
                product["product_id"] +
                ')">Edit</button> ';
            trHTML +=
                '<button class="btn btn-outline-danger" onclick="productDelete(' +
                product["product_id"] +
                ')">Del</button></td>';
            trHTML += "</tr>";

        }

    }


    document.getElementById("myproductstable").innerHTML = trHTML;
}


// Render Pagination
function renderproductPagination(totalItems) {
    const totalPages = Math.ceil(totalItems / rowsproductPerPage);
    let paginationHTML = "";

    paginationHTML += `<li class="page-item ${currentProductPage === 1 ? "disabled" : ""}">
      <a class="page-link" href="#" onclick="changeproductPage(${currentProductPage - 1})">Previous</a>
    </li>`;

    for (let i = 1; i <= totalPages; i++) {
        paginationHTML += `<li class="page-item ${currentProductPage === i ? "active" : ""}">
      <a class="page-link" href="#" onclick="changeproductPage(${i})">${i}</a>
    </li>`;
    }

    paginationHTML += `<li class="page-item color-greey ${currentProductPage === totalPages ? "disabled" : ""}">
      <a class="page-link" href="#" onclick="changeproductPage(${currentProductPage + 1})">Next</a>
    </li>`;

    document.getElementById("product_pagination").innerHTML = paginationHTML;
}

// Page Change
function changeproductPage(page) {
    const totalPages = Math.ceil(filteredProductData.length / rowsproductPerPage);
    if (page >= 1 && page <= totalPages) {
        renderproductTable(page);
        renderproductPagination(filteredProductData.length);
    }
}

// Filter/Search
function filterproductTable(query) {
    query = query.toLowerCase();
    filteredProductData = ProductData.filter((user) => {
        return (
            user.product_id.toString().includes(query) ||
            user.product_name.toLowerCase().includes(query) ||
            user.category_name.toLowerCase().includes(query) ||
            user.supplier_name.toLowerCase().includes(query) ||
            user.price.toLowerCase().includes(query) ||
            user.wholesale_price.toLowerCase().includes(query)
        );
    });

    currentProductPage = 1; // Reset to first page
    renderproductTable(currentProductPage);
    renderproductPagination(filteredProductData.length);
}


function showproductCreateBox() {
    Promise.all([
        fetch('./assets/php/get-categories.php').then(res => res.json()),
        fetch('./assets/php/get-suppliers.php').then(res => res.json())
    ]).then(([categories, suppliers]) => {
        const categoryOptions = categories.map(cat =>
            `<option value="${cat.category_id}">${cat.category_name}</option>`
        ).join('');

        const supplierOptions = suppliers.map(sup =>
            `<option value="${sup.supplier_id}">${sup.first_name} ${sup.last_name}</option>`
        ).join('');

        Swal.fire({
            title: "Add Product",
            showConfirmButton: false,
            html:
                `<div class="createUserForm">
                    <input id="product_name" type="text" class="swal2-input input_email" placeholder="Product name">
                    <div class="Name mt-3 mb-3">
                        <input id="price" class="swal2-input input_name" type="number" min="1" placeholder="Price">
                        <input id="Wholesale_price" class="swal2-input input_name" type="number" min="1" placeholder="Wholesale price">
                    </div>
                    <input id="product_description" type="text" class="swal2-input input_email mt-3" placeholder="Product description">
                    <div class="select_with_lable_forimge">
                        <label for="image" class="formbold-form-label">Upload Photo</label>
                        <input type="file" id="create_product_image_Create" class="formbold-form-input formbold-form-file" />
                        <input type="hidden" id="uploaded_product_ImageUrl" name="uploadedImageUrl" />
                    </div>
                    <div class="Name">
                        <div class="select_with_lable">
                            <label class="lable_name" for="category_id">Category</label>
                            <select id="category_id" class="swal2-input select">
                                <option value="" disabled selected>Select category</option>
                                ${categoryOptions}
                            </select>
                        </div>
                        <div class="select_with_lable">
                            <label class="lable_name" for="supplier">Supplier</label>
                            <select id="supplier_id" class="swal2-input select">
                                <option value="" disabled selected>Select supplier</option>
                                ${supplierOptions}
                            </select>
                        </div>
                        <div class="select_with_lable Name mt-3 mb-3">
                        <label class="lable_name" for="Quantityr">Quantity</label>
                        <input id="quantity" class="swal2-input input_name" type="number" min="0" placeholder="Quantity">
                        </div>
                    </div>
                    <p class=" product_error ErrorClear text-danger allertview text-sm text-start"></p>

                    <button type="button" id="add_product_btn" class="btn btn-primary button_setting mt-3 mb-4">Add Product</button>
                </div>`,
            didOpen: () => {
                // Add event listener after modal is rendered
                document.getElementById("add_product_btn").addEventListener("click", function (e) {
                    e.preventDefault();
                    const file = document.getElementById('create_product_image_Create').files[0];
                    if (file) {
                        uploadproductImage(); // should return a promise
                    } else {
                        productCreate(); // implement this function
                    }
                });
            }
        });
    }).catch(error => {
        console.error("Failed to load categories or suppliers:", error);
        Swal.fire("Error", "Could not load category or supplier data.", "error");
    });
}



function productCreate() {
    let is_product_valid = true;

    let image = document.getElementById("uploaded_product_ImageUrl").value.trim();
    const product_name = document.getElementById("product_name").value.trim();
    const price = document.getElementById("price").value;
    const Wholesale_price = document.getElementById("Wholesale_price").value;
    const description = document.getElementById("product_description").value;
    const supplier = document.getElementById("supplier_id").value.trim();
    const category_id = document.getElementById("category_id").value;
    const quantity = document.getElementById("quantity").value;
    const product_error = document.querySelector('.product_error');

    const namePattern = /^[A-Za-z].*/;
    product_error.classList.add("allertview");

    if (!namePattern.test(product_name)) {
        document.getElementById("product_name").classList.add("is-invalid");
        product_error.classList.remove("allertview");
        product_error.innerHTML = "Name must start with a letter.";
        is_product_valid = false;
    }
    else {
        document.getElementById("product_name").classList.remove("is-invalid");
    }
    if (price <= 0) {
        document.getElementById("price").classList.add("is-invalid");
        product_error.classList.remove("allertview");
        product_error.innerHTML = "price must more than zero.";
        is_product_valid = false;
    }
    else {
        document.getElementById("price").classList.remove("is-invalid");
    }
    if (Wholesale_price <= 0) {
        document.getElementById("Wholesale_price").classList.add("is-invalid");
        product_error.classList.remove("allertview");
        product_error.innerHTML = "Wholesale_price must more than zero.";
        is_product_valid = false;
    }
    else {
        document.getElementById("Wholesale_price").classList.remove("is-invalid");
    }
    if (!namePattern.test(description)) {
        document.getElementById("product_description").classList.add("is-invalid");
        product_error.classList.remove("allertview");
        product_error.innerHTML = "product_description must start with a letter.";
        is_product_valid = false;
    }
    else {
        document.getElementById("product_description").classList.remove("is-invalid");
    }
    if (supplier <= 0) {
        document.getElementById("supplier").classList.add("is-invalid");
        product_error.classList.remove("allertview");
        product_error.innerHTML = "select a supplier";
        is_product_valid = false;
    }
    else {
        document.getElementById("supplier").classList.remove("is-invalid");
    }
    if (category_id <= 0) {
        document.getElementById("category").classList.add("is-invalid");
        product_error.classList.remove("allertview");
        product_error.innerHTML = "select category";
        is_product_valid = false;
    }
    else {
        document.getElementById("category").classList.remove("is-invalid");
    }
    if (quantity <= 0) {
        document.getElementById("quantity").classList.add("is-invalid");
        product_error.classList.remove("allertview");
        product_error.innerHTML = "inter quantity of product";
        is_product_valid = false;
    }
    else {
        document.getElementById("quantity").classList.remove("is-invalid");
    }
    if (supplier <= 0 && !namePattern.test(product_name) && category_id <= 0 && !namePattern.test(description) && Wholesale_price <= 0 && (price <= 0)) {
        product_error.classList.remove("allertview");
        product_error.innerHTML = "please fill all boxes";
        is_product_valid = false;
    }

    if (!image) {
        image = "https://cdn3d.iconscout.com/3d/premium/thumb/product-3d-icon-download-in-png-blend-fbx-gltf-file-formats--tag-packages-box-marketing-advertisement-pack-branding-icons-4863042.png?f=webp";
    }

    if (is_product_valid) {
        const xhttp = new XMLHttpRequest();
        xhttp.open("POST", "./assets/php/add-product.php", true);
        xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
        xhttp.send(
            JSON.stringify({
                name: product_name,
                supplier_id: supplier,
                category_id: category_id,
                price: price,
                wholesale_price: Wholesale_price,
                image: image,
                description_product: description,
                quantity: quantity
            }
            ));


        xhttp.onreadystatechange = function () {
            if (this.readyState == 4) {
                try {
                    const objects = JSON.parse(this.responseText);

                    if (this.status == 200 && !objects.error) {

                        Swal.fire({
                            position: 'bottom-end',
                            title: ' &#10004; ' + `${objects.success}`,
                            showConfirmButton: false,
                            timer: 1500,
                            width: '25%',
                            background: '#047857',
                            didOpen: () => {
                                const swalTitle = Swal.getTitle();
                                if (swalTitle) swalTitle.style.color = '#fff';
                                swalTitle.style.fontSize = '15px';
                            }
                        });

                        overview();
                        loadproductTable();
                    }
                    else {
                        Swal.fire({
                            position: 'bottom-end',
                            title: ' &#10006;' + `${objects.error}`,
                            showConfirmButton: false,
                            timer: 1500,
                            width: '25%',
                            background: '#800000',
                            didOpen: () => {
                                const swalTitle = Swal.getTitle();
                                if (swalTitle) swalTitle.style.color = '#fff';
                                swalTitle.style.fontSize = '15px';
                            }
                        });
                    }
                } catch (e) {
                    Swal.fire({
                        position: 'bottom-end',
                        title: ' &#10006;	Server error',
                        showConfirmButton: false,
                        timer: 1500,
                        width: '25%',
                        background: '#800000',
                        didOpen: () => {
                            const swalTitle = Swal.getTitle();
                            if (swalTitle) swalTitle.style.color = '#fff';
                            swalTitle.style.fontSize = '15px';
                        }
                    });
                }
            }
        };
    }
}

let upload_product_flage = 0;
function showProductEditBox(id) {
    upload_product_flage = 1;

    Promise.all([
        fetch('./assets/php/get-categories.php').then(res => res.json()),
        fetch('./assets/php/get-suppliers.php').then(res => res.json())
    ]).then(([categories, suppliers]) => {
        const categoryOptions = categories.map(cat =>
            `<option value="${cat.category_id}">${cat.category_name}</option>`
        ).join('');

        const supplierOptions = suppliers.map(sup =>
            `<option value="${sup.supplier_id}">${sup.first_name} ${sup.last_name}</option>`
        ).join('');

        const xhttp = new XMLHttpRequest();
        xhttp.open("GET", "./assets/php/get-product-by-id.php?id=" + id, true); // corrected PHP file name
        xhttp.send();

        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                const product = JSON.parse(this.responseText);
                Swal.fire({
                    title: "Edit Product",
                    showConfirmButton: false,
                    html: `
                <div class="createUserForm">
                    <input id="edit_product_id" type="text" class=" hidden swal2-input " placeholder="Product id">
                    <input id="edit_product_name" type="text" class="swal2-input input_email" placeholder="Product name">
                    <div class="Name mt-3 mb-3">
                        <div class="select_with_lable">
                            <label class="lable_name" for="edit_price">Price</label>   
                            <input id="edit_price" class="swal2-input  input_name" type="number" min="1" placeholder="Price">
                        </div>
                        <div class="select_with_lable">
                             <label class="lable_name" for="edit_wholesale_price">wholesale price</label>
                            <input id="edit_wholesale_price" class="swal2-input input_name" type="number" min="1" placeholder="Wholesale price">
                        </div>
                    </div>
                    <input id="edit_product_description" type="text" class="swal2-input input_email mt-3" placeholder="Product description">
                    <div class="select_with_lable_forimge">
                        <label for="image" class="formbold-form-label">Upload Photo</label>
                        <input type="file" id="edit_product_image_Create" class="formbold-form-input formbold-form-file" />
                        <input type="hidden" id="edit_product_ImageUrl" name="uploadedImageUrl" />
                    </div>
                    <div class="Name">
                        <div class="select_with_lable">
                            <label class="lable_name" for="category">Category</label>
                            <select id="edit_category" class="swal2-input select">
                                <option value="" disabled>Select category</option>
                                ${categoryOptions}
                            </select>
                        </div>
                        <div class="select_with_lable">
                            <label class="lable_name" for="supplier">Supplier</label>
                            <select id="edit_supplier" class="swal2-input select">
                                <option value="" disabled>Select supplier</option>
                                ${supplierOptions}
                            </select>
                        </div>
                    </div>
                    <div class=" select_with_lable Name mt-3 mb-3">
                        <label class="lable_name" for="Quantityrr">Quantity</label>
                        <input id="edit_quantity" class="swal2-input input_name" type="number" min="0" placeholder="Quantity" >
                        </div>
                    <p class="edit_product_error ErrorClear text-danger allertview text-sm text-start"></p>
                    <button type="button" id="edit_product_btn" class="btn btn-primary button_setting mt-3 mb-4">Save Changes</button>
                </div>`,
                    didOpen: () => {
                        // Fill input fields with product data
                        document.getElementById("edit_product_name").value = product.name || "";
                        document.getElementById("edit_product_id").value = product.product_id || "";
                        document.getElementById("edit_price").value = product.price || "";
                        document.getElementById("edit_wholesale_price").value = product.wholesale_price;
                        document.getElementById("edit_product_description").value = product.description_product || "";
                        document.getElementById("edit_category").value = product.category_id || "";
                        document.getElementById("edit_supplier").value = product.supplier_id || "";
                        document.getElementById("edit_quantity").value = product.total_stock_quantity || "";

                        // Event handler for save
                        document.getElementById("edit_product_btn").addEventListener("click", function (e) {
                            e.preventDefault();
                            const file = document.getElementById('edit_product_image_Create').files[0];
                            if (file) {
                                uploadproductImage(); // Assumes uploadproductImage() uploads and calls productCreate()
                            } else {
                                productEdit(); // Must handle updating product with or without image
                            }
                        });
                    }
                });
            }
        };
    })


}


function productEdit() {

    let is_product_valid = true;

    let edit_image = document.getElementById("edit_product_ImageUrl").value.trim();
    const edit_product_id = document.getElementById("edit_product_id").value;
    const edit_product_name = document.getElementById("edit_product_name").value.trim();
    const edit_price = document.getElementById("edit_price").value;
    const edit_Wholesale_price = document.getElementById("edit_wholesale_price").value;
    const edit_description = document.getElementById("edit_product_description").value.trim();
    const edit_supplier = document.getElementById("edit_supplier").value;
    const edit_category = document.getElementById("edit_category").value;
    const edit_quantity = document.getElementById("edit_quantity").value;
    const edit_product_error = document.querySelector('.edit_product_error');

    const namePattern = /^[A-Za-z].*/;
    edit_product_error.classList.add("allertview");

    if (!namePattern.test(edit_product_name)) {
        document.getElementById("edit_product_name").classList.add("is-invalid");
        edit_product_error.classList.remove("allertview");
        edit_product_error.innerHTML = "Name must start with a letter.";
        is_product_valid = false;
    }
    else {
        document.getElementById("edit_product_name").classList.remove("is-invalid");
    }
    if (edit_price <= 0) {
        document.getElementById("edit_price").classList.add("is-invalid");
        edit_product_error.classList.remove("allertview");
        edit_product_error.innerHTML = "price must more than zero.";
        is_product_valid = false;
    }
    else {
        document.getElementById("edit_price").classList.remove("is-invalid");
    }
    if (edit_quantity <= 0) {
        document.getElementById("edit_quantity").classList.add("is-invalid");
        edit_product_error.classList.remove("allertview");
        edit_product_error.innerHTML = "Quantity must more than zero.";
        is_product_valid = false;
    }
    else {
        document.getElementById("edit_quantity").classList.remove("is-invalid");
    }
    if (edit_Wholesale_price <= 0) {
        document.getElementById("edit_Wholesale_price").classList.add("is-invalid");
        edit_product_error.classList.remove("allertview");
        edit_product_error.innerHTML = "Wholesale_price must more than zero.";
        is_product_valid = false;
    }
    else {
        document.getElementById("edit_wholesale_price").classList.remove("is-invalid");
    }
    if (!namePattern.test(edit_description)) {
        document.getElementById("edit_product_description").classList.add("is-invalid");
        edit_product_error.classList.remove("allertview");
        edit_product_error.innerHTML = "product_description must start with a letter.";
        is_product_valid = false;
    }
    else {
        document.getElementById("edit_product_description").classList.remove("is-invalid");
    }
    if (edit_supplier <= 0) {
        document.getElementById("edit_supplier").classList.add("is-invalid");
        edit_product_error.classList.remove("allertview");
        edit_product_error.innerHTML = "select a supplier";
        is_product_valid = false;
    }
    else {
        document.getElementById("edit_supplier").classList.remove("is-invalid");
    }
    if (edit_category <= 0) {
        document.getElementById("edit_category").classList.add("is-invalid");
        edit_product_error.classList.remove("allertview");
        edit_product_error.innerHTML = "select category";
        is_product_valid = false;
    }
    else {
        document.getElementById("edit_category").classList.remove("is-invalid");
    }
    if (edit_supplier <= 0 && !namePattern.test(edit_product_name) && edit_category <= 0 && !namePattern.test(edit_description) && edit_Wholesale_price <= 0 && (edit_price <= 0)) {
        product_error.classList.remove("allertview");
        product_error.innerHTML = "please fill all boxes";
        is_product_valid = false;
    }

    if (is_product_valid) {
        const xhttp = new XMLHttpRequest();
        xhttp.open("POST", "./assets/php/update-product.php", true);
        xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
        xhttp.send(
            JSON.stringify({
                product_id: edit_product_id,
                name: edit_product_name,
                supplier_id: edit_supplier,
                category_id: edit_category,
                price: edit_price,
                wholesale_price: edit_Wholesale_price,
                image: edit_image,
                description_product: edit_description,
                quantity: edit_quantity
            }
            ));

        xhttp.onreadystatechange = function () {
            if (this.readyState == 4) {
                try {
                    const objects = JSON.parse(this.responseText);
                    if (this.status == 200 && !objects.error) {
                        Swal.fire({
                            position: 'bottom-end',
                            title: ' &#10004; ' + `${objects.success}`,
                            showConfirmButton: false,
                            timer: 1500,
                            width: '25%',
                            background: '#047857',
                            didOpen: () => {
                                const swalTitle = Swal.getTitle();
                                if (swalTitle) swalTitle.style.color = '#fff';
                                swalTitle.style.fontSize = '15px';
                            }
                        });

                        overview();
                        loadproductTable();
                    }
                    else {
                        Swal.fire({
                            position: 'bottom-end',
                            title: ' &#10006;' + `${objects.error}`,
                            showConfirmButton: false,
                            timer: 1500,
                            width: '25%',
                            background: '#800000',
                            didOpen: () => {
                                const swalTitle = Swal.getTitle();
                                if (swalTitle) swalTitle.style.color = '#fff';
                                swalTitle.style.fontSize = '15px';
                            }
                        });
                    }
                } catch (e) {
                    Swal.fire({
                        position: 'bottom-end',
                        title: ' &#10006;	Server error',
                        showConfirmButton: false,
                        timer: 1500,
                        width: '25%',
                        background: '#800000',
                        didOpen: () => {
                            const swalTitle = Swal.getTitle();
                            if (swalTitle) swalTitle.style.color = '#fff';
                            swalTitle.style.fontSize = '15px';
                        }
                    });
                }
            }
        };
    }

}


function uploadproductImage() {
    return new Promise((resolve, reject) => {
        let fileInput;

        if (upload_product_flage == 1) {
            fileInput = Swal.getPopup().querySelector('#edit_product_image_Create');
        } else {
            fileInput = Swal.getPopup().querySelector('#create_product_image_Create');
        }

        const file = fileInput?.files?.[0];

        if (!file) {
            Swal.fire("Validation Error", "Please select an image.", "warning");
            return reject(); // Reject if no file selected
        }

        const formData = new FormData();
        formData.append("file", file);
        formData.append("upload_preset", "unsigned_user_uploads");

        fetch("https://api.cloudinary.com/v1_1/dpjwslspm/image/upload", {
            method: "POST",
            body: formData
        })
            .then(res => res.json())
            .then(data => {
                if (data.secure_url) {
                    if (upload_product_flage == 1) {
                        document.getElementById('edit_product_ImageUrl').value = data.secure_url;
                    } else {
                        document.getElementById('uploaded_product_ImageUrl').value = data.secure_url;
                    }

                    console.log("Uploaded Image URL:", data.secure_url);

                    if (upload_product_flage == 1) {
                        productEdit();
                        upload_product_flage = 0;
                    } else {
                        productCreate();
                    }

                    resolve(data.secure_url); // Resolve promise with URL
                } else {
                    Swal.fire("Upload Error", data.error?.message || "Failed to upload image.", "error");
                    reject();
                }
            })
            .catch(err => {
                console.error("Upload error:", err);
                Swal.fire("Upload Error", "Something went wrong while uploading.", "error");
                reject();
            });
    });
}

function productDelete(id) {
    Swal.fire({
        title: "Are you sure?",
        text: "This action cannot be undone!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Yes, delete it!",
    }).then((result) => {
        if (result.isConfirmed) {
            const xhttp = new XMLHttpRequest();
            xhttp.open("DELETE", "./assets/php/delete-product.php", true);
            xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
            xhttp.send(JSON.stringify({ product_id: id }));
            console.log(id);
            xhttp.onreadystatechange = function () {
                if (this.readyState == 4) {
                    const res = JSON.parse(this.responseText);
                    if (this.status === 200 && !res.error) {
                        Swal.fire({
                            position: 'bottom-end',
                            title: ' &#10004; ' + `${res.success}`,
                            showConfirmButton: false,
                            timer: 1500,
                            width: '25%',
                            background: '#047857',
                            didOpen: () => {
                                const swalTitle = Swal.getTitle();
                                if (swalTitle) swalTitle.style.color = '#fff';
                                swalTitle.style.fontSize = '15px';
                            }
                        });
                        loadproductTable();
                    } else {
                        Swal.fire({
                            position: 'bottom-end',
                            title: ' &#10006;' + `${res.error}`,
                            showConfirmButton: false,
                            timer: 1500,
                            width: '25%',
                            background: '#800000',
                            didOpen: () => {
                                const swalTitle = Swal.getTitle();
                                if (swalTitle) swalTitle.style.color = '#fff';
                                swalTitle.style.fontSize = '15px';
                            }
                        });
                    }
                }
            };
        }
    });
}

loadproductTable();


function loadcategoriesTable() {
    const xhttp = new XMLHttpRequest();
    xhttp.open("GET", "./assets/php/get-categories.php", true);
    xhttp.send();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            categoriesData = JSON.parse(this.responseText);
            filteredcategoriesData = [...categoriesData]; // Start with full data
            rendercategoriesTable(currentcategoriesPage);
            rendercategoriesPagination(filteredcategoriesData.length);
        }
    };
}

// Render Table
function rendercategoriesTable(page) {
    currentcategoriesPage = page;
    const start = (page - 1) * rowscategoriesPerPage;
    const end = start + rowscategoriesPerPage;
    const paginatedItems = filteredcategoriesData.slice(start, end);

    let trHTML = "";

    if (paginatedItems.length === 0) {
        trHTML += `<tr><td colspan="10" class="text-center">No products found</td></tr>`;
    } else {
        for (let product of paginatedItems) {
            trHTML += "<tr>";
            trHTML += "<td>" + product["category_id"] + "</td>";
            trHTML += '<td  style="display: flex; justify-content: center; align-items: center;"><img width="50px" height="50px" class="text-center category_img" src="' + product["image"] + '" alt="category Image"></td>';
            trHTML += "<td>" + product["category_name"] + "</td>";
            trHTML +=
                '<td><button class="btn btn-outline-secondary" onclick="showcategoryEditBox(' +
                product["category_id"] +
                ')">Edit</button> ';
            trHTML +=
                '<button class="btn btn-outline-danger" onclick="categoryDelete(' +
                product["category_id"] +
                ')">Del</button></td>';
            trHTML += "</tr>";
        }
    }

    document.getElementById("mycategoriestable").innerHTML = trHTML;
}


// Render Pagination
function rendercategoriesPagination(totalItems) {
    const totalPages = Math.ceil(totalItems / rowscategoriesPerPage);
    let paginationHTML = "";

    paginationHTML += `<li class="page-item ${currentcategoriesPage === 1 ? "disabled" : ""}">
      <a class="page-link" href="#" onclick="changecategoriesPage(${currentcategoriesPage - 1})">Previous</a>
    </li>`;

    for (let i = 1; i <= totalPages; i++) {
        paginationHTML += `<li class="page-item ${currentcategoriesPage === i ? "active" : ""}">
      <a class="page-link" href="#" onclick="changecategoriesPage(${i})">${i}</a>
    </li>`;
    }

    paginationHTML += `<li class="page-item color-greey ${currentcategoriesPage === totalPages ? "disabled" : ""}">
      <a class="page-link" href="#" onclick="changecategoriesPage(${currentcategoriesPage + 1})">Next</a>
    </li>`;

    document.getElementById("categories_pagination").innerHTML = paginationHTML;
}

// Page Change
function changecategoriesPage(page) {
    const totalPages = Math.ceil(filteredcategoriesData.length / rowscategoriesPerPage);
    if (page >= 1 && page <= totalPages) {
        rendercategoriesTable(page);
        rendercategoriesPagination(filteredcategoriesData.length);
    }
}

// Filter/Search
function filtercategoriesTable(query) {
    query = query.toLowerCase();
    filteredcategoriesData = categoriesData.filter((user) => {
        return (
            user.category_id.toString().includes(query) ||
            user.category_name.toLowerCase().includes(query)
        );
    });

    currentcategoriesPage = 1; // Reset to first page
    rendercategoriesTable(currentProductPage);
    rendercategoriesPagination(filteredProductData.length);
}
function showcategoryCreateBox() {

    Swal.fire({
        title: "Add category",
        showConfirmButton: false,
        html:
            `<div class="createUserForm">
                    <input id="category_name" type="text" class="swal2-input input_email" placeholder="category name">
                    
                    <div class="select_with_lable_forimge">
                        <label for="image" class="formbold-form-label">Upload Photo</label>
                        <input type="file" id="create_category_image_Create" class="formbold-form-input formbold-form-file" />
                        <input type="hidden" id="uploaded_category_ImageUrl" name="categoryImageUrl" />
                    </div>
                    
                    <p class=" category_error ErrorClear text-danger allertview text-sm text-start"></p>

                    <button type="button" id="add_category_btn" class="btn btn-primary button_setting mt-3 mb-4">Add category</button>
                </div>`,
        didOpen: () => {
            // Add event listener after modal is rendered
            document.getElementById("add_category_btn").addEventListener("click", function (e) {
                e.preventDefault();
                const file = document.getElementById('create_category_image_Create').files[0];
                if (file) {
                    uploadcategoryImage(); // should return a promise
                } else {
                    categoryCreate(); // implement this function
                }
            });
        }
    });
}

function categoryCreate() {
    let is_categories_valid = true;

    let image = document.getElementById("uploaded_category_ImageUrl").value.trim();
    const category_name = document.getElementById("category_name").value.trim();

    const category_error = document.querySelector('.category_error');

    const namePattern = /^[A-Za-z].*/;
    if (!namePattern.test(category_name)) {
        document.getElementById("category_name").classList.add("is-invalid");
        category_error.classList.remove("allertview");
        category_error.innerHTML = "Name must start with a letter.";
        is_categories_valid = false;
    }
    else {
        document.getElementById("category_name").classList.remove("is-invalid");
    }

    if (!image) {
        image = "https://icon-library.com/images/product-category-icon/product-category-icon-13.jpg";
    }

    if (is_categories_valid) {
        const xhttp = new XMLHttpRequest();
        xhttp.open("POST", "./assets/php/add-category.php", true);
        xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
        xhttp.send(
            JSON.stringify({
                category_name: category_name,
                image: image,
            }
            ));

        xhttp.onreadystatechange = function () {
            if (this.readyState == 4) {
                try {
                    const objects = JSON.parse(this.responseText);
                    if (this.status == 200 && !objects.error) {
                        Swal.fire({
                            position: 'bottom-end',
                            title: ' &#10004; ' + `${objects.success}`,
                            showConfirmButton: false,
                            timer: 1500,
                            width: '25%',
                            background: '#047857',
                            didOpen: () => {
                                const swalTitle = Swal.getTitle();
                                if (swalTitle) swalTitle.style.color = '#fff';
                                swalTitle.style.fontSize = '15px';
                            }
                        });

                        setTimeout(() => {
                            overview();
                            loadcategoriesTable();
                        }, 300);
                    }
                    else {
                        Swal.fire({
                            position: 'bottom-end',
                            title: ' &#10006;' + `${objects.error}`,
                            showConfirmButton: false,
                            timer: 1500,
                            width: '25%',
                            background: '#800000',
                            didOpen: () => {
                                const swalTitle = Swal.getTitle();
                                if (swalTitle) swalTitle.style.color = '#fff';
                                swalTitle.style.fontSize = '15px';
                            }
                        });
                    }
                } catch (e) {
                    Swal.fire({
                        position: 'bottom-end',
                        title: ' &#10006;	Server error',
                        showConfirmButton: false,
                        timer: 1500,
                        width: '25%',
                        background: '#800000',
                        didOpen: () => {
                            const swalTitle = Swal.getTitle();
                            if (swalTitle) swalTitle.style.color = '#fff';
                            swalTitle.style.fontSize = '15px';
                        }
                    });
                }
            }
        };
    }
}



let upload_category_flage = 0;
function showcategoryEditBox(id) {
    upload_category_flage = 1;

    const xhttp = new XMLHttpRequest();
    xhttp.open("GET", "./assets/php/get-category-by-id.php?category_id=" + id, true); // corrected PHP file name
    xhttp.send();

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            const category = JSON.parse(this.responseText).data;
            Swal.fire({
                title: "Edit Product",
                showConfirmButton: false,
                html:
                    `<div class="createUserForm">
                            <input id="edit_category_id" type="text" class="hidden swal2-input input_email" placeholder="category id">

                            <input id="edit_category_name" type="text" class="swal2-input input_email" placeholder="category name">
                            
                            <div class="select_with_lable_forimge">
                                <label for="image" class="formbold-form-label">Upload Photo</label>
                                <input type="file" id="edit_category_image_Create" class="formbold-form-input formbold-form-file" />
                                <input type="hidden" id="edit_category_ImageUrl" name="categoryImageUrl" />
                            </div>
                            
                            <p class="edit_category_error ErrorClear text-danger allertview text-sm text-start"></p>

                            <button type="button" id="edit_category_btn" class="btn btn-primary button_setting mt-3 mb-4">Edit category</button>
                        </div>`,
                didOpen: () => {
                    // Fill input fields with product data
                    document.getElementById("edit_category_id").value = category.category_id || "";
                    document.getElementById("edit_category_name").value = category.category_name || "";

                    // Event handler for save
                    document.getElementById("edit_category_btn").addEventListener("click", function (e) {
                        e.preventDefault();
                        const file = document.getElementById('edit_category_image_Create').files[0];
                        if (file) {
                            uploadcategoryImage(); // Assumes uploadproductImage() uploads and calls productCreate()
                        } else {
                            categoryEdit(); // Must handle updating product with or without image
                        }
                    });
                }
            });
        }
    };
}


function categoryEdit() {

    let is_edit_category_valid = true;

    let edit_category_image = document.getElementById("edit_category_ImageUrl").value.trim();
    const edit_category_id = document.getElementById("edit_category_id").value;
    const edit_category_name = document.getElementById("edit_category_name").value.trim();

    const edit_category_error = document.querySelector('.edit_category_error');

    const namePattern = /^[A-Za-z].*/;

    if (!namePattern.test(edit_category_name)) {
        document.getElementById("edit_category_name").classList.add("is-invalid");
        edit_category_error.classList.remove("allertview");
        edit_category_error.innerHTML = "Name must start with a letter.";
        is_edit_category_valid = false;
    }
    else {
        document.getElementById("edit_category_name").classList.remove("is-invalid");
    }

    if (is_edit_category_valid) {
        const xhttp = new XMLHttpRequest();
        xhttp.open("POST", "./assets/php/update-category.php", true);
        xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
        xhttp.send(
            JSON.stringify({
                category_id: edit_category_id,
                category_name: edit_category_name,
                image: edit_category_image,
            }
            ));

        xhttp.onreadystatechange = function () {
            if (this.readyState == 4) {
                try {
                    const objects = JSON.parse(this.responseText);
                    if (this.status == 200 && !objects.error) {
                        Swal.fire({
                            position: 'bottom-end',
                            title: ' &#10004; ' + `${objects.success}`,
                            showConfirmButton: false,
                            timer: 1500,
                            width: '25%',
                            background: '#047857',
                            didOpen: () => {
                                const swalTitle = Swal.getTitle();
                                if (swalTitle) swalTitle.style.color = '#fff';
                                swalTitle.style.fontSize = '15px';
                            }
                        });

                        overview();
                        loadcategoriesTable();
                    }
                    else {
                        Swal.fire({
                            position: 'bottom-end',
                            title: ' &#10006;' + `${objects.error}`,
                            showConfirmButton: false,
                            timer: 1500,
                            width: '25%',
                            background: '#800000',
                            didOpen: () => {
                                const swalTitle = Swal.getTitle();
                                if (swalTitle) swalTitle.style.color = '#fff';
                                swalTitle.style.fontSize = '15px';
                            }
                        });
                    }
                } catch (e) {
                    Swal.fire({
                        position: 'bottom-end',
                        title: ' &#10006;	Server error',
                        showConfirmButton: false,
                        timer: 1500,
                        width: '25%',
                        background: '#800000',
                        didOpen: () => {
                            const swalTitle = Swal.getTitle();
                            if (swalTitle) swalTitle.style.color = '#fff';
                            swalTitle.style.fontSize = '15px';
                        }
                    });
                }
            }
        };
    }

}

function uploadcategoryImage() {
    return new Promise((resolve, reject) => {
        let fileInput;

        if (upload_category_flage == 1) {
            fileInput = Swal.getPopup().querySelector('#edit_category_image_Create');
        } else {
            fileInput = Swal.getPopup().querySelector('#create_category_image_Create');
        }

        const file = fileInput?.files?.[0];

        if (!file) {
            Swal.fire("Validation Error", "Please select an image.", "warning");
            return reject(); // Reject if no file selected
        }

        const formData = new FormData();
        formData.append("file", file);
        formData.append("upload_preset", "unsigned_user_uploads");

        fetch("https://api.cloudinary.com/v1_1/dpjwslspm/image/upload", {
            method: "POST",
            body: formData
        })
            .then(res => res.json())
            .then(data => {
                if (data.secure_url) {
                    if (upload_category_flage == 1) {
                        document.getElementById('edit_category_ImageUrl').value = data.secure_url;
                    } else {
                        document.getElementById('uploaded_category_ImageUrl').value = data.secure_url;
                    }

                    console.log("Uploaded Image URL:", data.secure_url);

                    if (upload_category_flage == 1) {
                        categoryEdit();
                        upload_category_flage = 0;
                    } else {
                        categoryCreate();
                    }

                    resolve(data.secure_url); // Resolve promise with URL
                } else {
                    Swal.fire("Upload Error", data.error?.message || "Failed to upload image.", "error");
                    reject();
                }
            })
            .catch(err => {
                console.error("Upload error:", err);
                Swal.fire("Upload Error", "Something went wrong while uploading.", "error");
                reject();
            });
    });
}

function categoryDelete(id) {
    Swal.fire({
        title: "Are you sure?",
        text: "This action cannot be undone!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Yes, delete it!",
    }).then((result) => {
        if (result.isConfirmed) {
            const xhttp = new XMLHttpRequest();
            xhttp.open("DELETE", "./assets/php/delete-category.php", true);
            xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
            xhttp.send(JSON.stringify({ category_id: id }));
            xhttp.onreadystatechange = function () {
                if (this.readyState == 4) {
                    const res = JSON.parse(this.responseText);
                    if (this.status === 200 && !res.error) {
                        Swal.fire({
                            position: 'bottom-end',
                            title: ' &#10004; ' + `${res.success}`,
                            showConfirmButton: false,
                            timer: 1500,
                            width: '25%',
                            background: '#047857',
                            didOpen: () => {
                                const swalTitle = Swal.getTitle();
                                if (swalTitle) swalTitle.style.color = '#fff';
                                swalTitle.style.fontSize = '15px';
                            }
                        });
                        loadcategoriesTable();
                    } else {
                        Swal.fire({
                            position: 'bottom-end',
                            title: ' &#10006;' + `${res.error}`,
                            showConfirmButton: false,
                            timer: 1500,
                            width: '25%',
                            background: '#800000',
                            didOpen: () => {
                                const swalTitle = Swal.getTitle();
                                if (swalTitle) swalTitle.style.color = '#fff';
                                swalTitle.style.fontSize = '15px';
                            }
                        });
                    }
                }
            };
        }
    });
}

loadcategoriesTable();

let currentProduct_in_watingPage = 1;
const rowsProduct_in_watingPerPage = 12;
let Product_in_watingData = [];
let filteredProduct_in_watingData = [];
function loadWatingproductTable() {
    const ProductWating_alert = document.getElementById("Wating_product_in_branch_notification_count");
    const xhttp = new XMLHttpRequest();
    xhttp.open("GET", "./assets/php/get-products-in-wating-list.php", true);
    xhttp.send();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            Product_in_watingData = JSON.parse(this.responseText).products;
            filteredProduct_in_watingData = [...Product_in_watingData]; // Start with full data
            renderProduct_in_watingTable(currentProduct_in_watingPage);
            renderProduct_in_branchPagination(filteredProduct_in_watingData.length);
            if (filteredProduct_in_watingData.length > 0) {
                ProductWating_alert.classList.remove("hidden");
                ProductWating_alert.querySelector("span").innerHTML = filteredProduct_in_watingData.length;
            }
            else {
                ProductWating_alert.classList.add("hidden");
            }
        }
    };
}

// Render Table
function renderProduct_in_watingTable(page) {
    currentProduct_in_watingPage = page;
    const start = (page - 1) * rowsProduct_in_watingPerPage;
    const end = start + rowsProduct_in_watingPerPage;
    const paginatedItems = filteredProduct_in_watingData.slice(start, end);

    let trHTML = "";

    if (paginatedItems.length === 0) {
        trHTML = `<tr><td colspan="10" class="text-center">No Orders found</td></tr>`;
    } else {
        for (let product of paginatedItems) {

            trHTML += `
            <div class="flex flex-wrap items-center gap-y-4 py-6 border-b border-gray-200">
                <dl class="w-1/2 sm:w-1/4 lg:w-auto lg:flex-1">
                    <dt class="text-base font-medium text-gray-500 dark:text-gray-400"> ID:</dt>
                    <dd class="mt-1.5 text-base font-semibold text-gray-900">
                        <span class="hover:underline" >${product.branch_product_id}</span>
                    </dd>
                </dl>
                 <dl class="w-1/2 sm:w-1/4 lg:w-auto lg:flex-1">
                    <dt class="text-base font-medium text-gray-500 dark:text-gray-400"> Image</dt>
                    <dd class="mt-1.5 text-base font-semibold text-gray-900">
                       <img width="50px" src="${product.product_image}" alt="Product Image">
                    </dd>
                </dl>
                <dl class="w-1/2 sm:w-1/4 lg:w-auto lg:flex-1 ">
                    <dt class="text-base font-medium text-gray-500 dark:text-gray-400">Branch name</dt>
                    <dd class="mt-1.5 text-base font-semibold text-gray-900">${product.branch_name}</dd>
                </dl>
                <dl class="w-1/2 sm:w-1/4 ">
                    <dt class="text-base font-medium text-gray-500 dark:text-gray-400">product name:</dt>
                    <dd class="mt-1.5 text-base font-semibold text-gray-900">$${product.product_name}</dd>
                </dl>
                <dl class="w-1/2 sm:w-1/4 lg:w-auto lg:flex-1">
                    <dt class="text-base font-medium text-gray-500 dark:text-gray-400">Quantity</dt>
                    <dd class="mt-1.5 text-base font-semibold text-gray-900">${product.total_stock_quantity}</dd>
                </dl>
                <dl class="w-1/2 sm:w-1/4 lg:w-auto lg:flex-1">
                    <dt class="text-base font-medium text-gray-500 dark:text-gray-400">Status:</dt>
                    <dd class="me-2 mt-1.5 inline-flex items-center rounded bg-gray-300 px-2.5 py-1 text-xs font-medium text-yellow-800 dark:text-yellow-300}">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-hourglass" viewBox="0 0 16 16">
                            <path d="M2 1.5a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-1v1a4.5 4.5 0 0 1-2.557 4.06c-.29.139-.443.377-.443.59v.7c0 .213.154.451.443.59A4.5 4.5 0 0 1 12.5 13v1h1a.5.5 0 0 1 0 1h-11a.5.5 0 1 1 0-1h1v-1a4.5 4.5 0 0 1 2.557-4.06c.29-.139.443-.377.443-.59v-.7c0-.213-.154-.451-.443-.59A4.5 4.5 0 0 1 3.5 3V2h-1a.5.5 0 0 1-.5-.5m2.5.5v1a3.5 3.5 0 0 0 1.989 3.158c.533.256 1.011.791 1.011 1.491v.702c0 .7-.478 1.235-1.011 1.491A3.5 3.5 0 0 0 4.5 13v1h7v-1a3.5 3.5 0 0 0-1.989-3.158C8.978 9.586 8.5 9.052 8.5 8.351v-.702c0-.7.478-1.235 1.011-1.491A3.5 3.5 0 0 0 11.5 3V2z"/>
                        </svg>
                    ${product.product_condition}
                    
                    </dd>
                </dl>

                <div class="grid sm:grid-cols-3 lg:flex lg:w-64 lg:items-center lg:justify-end gap-4">
                        <button type="button" onclick="updateProduct_in_branchStatus(${product.branch_product_id},'Cancelled')"
                            class="rounded-lg border border-red-900 px-3 py-2 text-center text-xs font-medium text-red-700 hover:bg-red-700 hover:text-white focus:outline-none focus:ring-4 focus:ring-red-300">
                            Cancel
                        </button>
                  
                        <button type="button" onclick="updateProduct_in_branchStatus(${product.branch_product_id},'Available in branch')"
                            class="rounded-lg border border-green-900 px-3 py-2 text-center text-xs font-medium text-green-700 hover:bg-green-700 hover:text-white focus:outline-none focus:ring-4 focus:ring-green-300">
                            Accepted
                        </button>
                </div>
            </div>`;
        }
    }

    document.getElementById("Wating_List_productBranches").innerHTML = trHTML;
}
// Render Pagination
function renderProduct_in_branchPagination(totalItems) {
    const totalPages = Math.ceil(totalItems / rowsProduct_in_watingPerPage);
    let paginationHTML = "";

    paginationHTML += `<li class="page-item ${currentProduct_in_watingPage === 1 ? "disabled" : ""}">
      <a class="page-link" href="#" onclick="changeProduct_in_branch_watingPage(${currentProduct_in_watingPage - 1})">Previous</a>
    </li>`;

    for (let i = 1; i <= totalPages; i++) {
        paginationHTML += `<li class="page-item ${currentProduct_in_watingPage === i ? "active" : ""}">
      <a class="page-link" href="#" onclick="changeProduct_in_branch_watingPage(${i})">${i}</a>
    </li>`;
    }

    paginationHTML += `<li class="page-item color-greey ${currentProduct_in_watingPage === totalPages ? "disabled" : ""}">
      <a class="page-link" href="#" onclick="changeProduct_in_branch_watingPage(${currentProduct_in_watingPage + 1})">Next</a>
    </li>`;

    document.getElementById("wating_product_branches_pagination").innerHTML = paginationHTML;
}
// Page Change
function changeProduct_in_branch_watingPage(page) {
    const totalPages = Math.ceil(filteredProduct_in_watingData.length / rowsProduct_in_watingPerPage);
    if (page >= 1 && page <= totalPages) {
        renderProduct_in_watingTable(page);
        renderProduct_in_branchPagination(filteredProduct_in_watingData.length);
    }
}
function updateProduct_in_branchStatus(orderId, newStatus) {
    const xhttp = new XMLHttpRequest();
    xhttp.open("POST", "./assets/php/update-product-in-branch-waiting.php", true);
    xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");

    xhttp.send(JSON.stringify({
        order_id: orderId,
        status_of_order: newStatus
    }));

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4) {
            try {
                const response = JSON.parse(this.responseText);

                if (this.status == 200 && !response.error) {
                    Swal.fire({
                        position: 'bottom-end',
                        title: ' &#10004; ' + (response.success || 'Status updated.'),
                        showConfirmButton: false,
                        timer: 1500,
                        width: '25%',
                        background: '#047857',
                        didOpen: () => {
                            const swalTitle = Swal.getTitle();
                            if (swalTitle) {
                                swalTitle.style.color = '#fff';
                                swalTitle.style.fontSize = '15px';
                            }
                        }
                    });

                    overview();
                    loadWatingproductTable();

                } else {
                    let errorMsg = response.error || 'Unknown error';
                    if (response.details && Array.isArray(response.details)) {
                        errorMsg += `<br><br><strong>Details:</strong><br>`;
                        response.details.forEach(item => {
                            errorMsg += `Product: <strong>${item.product_name}</strong> (ID: ${item.product_id})<br>`;
                            errorMsg += `Required: ${item.required}, Available: ${item.available}<br><br>`;
                        });
                    }
                    Swal.fire({
                        position: 'bottom-end',
                        html: ' &#10006; ' + errorMsg,
                        showConfirmButton: false,
                        timer: 4000,
                        width: '30%',
                        background: '#800000',
                        didOpen: () => {
                            const swalTitle = Swal.getTitle();
                            if (swalTitle) {
                                swalTitle.style.color = '#ffff';
                                swalTitle.style.fontSize = '14px';
                            }
                        }
                    });
                }
            }
            catch (e) {
                Swal.fire({
                    position: 'bottom-end',
                    title: ' &#10006; Server error',
                    showConfirmButton: false,
                    timer: 1500,
                    width: '25%',
                    background: '#800000',
                    didOpen: () => {
                        const swalTitle = Swal.getTitle();
                        if (swalTitle) {
                            swalTitle.style.color = '#fff';
                            swalTitle.style.fontSize = '15px';
                        }
                    }
                });
            }
        }
    };
}
loadWatingproductTable();

let currentSupplierPage = 1;
const rowsSupplierPerPage = 12;
let SupplierData = [];
let filteredSupplierData = [];
// Load Data
function loadsupplierTable() {
    const xhttp = new XMLHttpRequest();
    xhttp.open("GET", "./assets/php/get-suppliers.php", true);
    xhttp.send();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            SupplierData = JSON.parse(this.responseText);
            filteredSupplierData = [...SupplierData]; // Start with full data
            rendersupplierTable(currentSupplierPage);
            rendersupplierPagination(filteredSupplierData.length);
        }
    };
}
// Render Table
function rendersupplierTable(page) {
    currentSupplierPage = page;
    const start = (page - 1) * rowsSupplierPerPage;
    const end = start + rowsSupplierPerPage;
    const paginatedItems = filteredSupplierData.slice(start, end);

    let trHTML = "";

    if (paginatedItems.length === 0) {
        trHTML += `<tr><td colspan="10" class="text-center">No products found</td></tr>`;
    } else {
        for (let supplier of paginatedItems) {
            trHTML += "<tr>";
            trHTML += "<td>" + supplier["supplier_id"] + "</td>";
            trHTML += "<td>" + supplier["first_name"] + "</td>";
            trHTML += "<td>" + supplier["last_name"] + "</td>";
            trHTML += "<td>" + supplier["email"] + "</td>";
            trHTML += "<td>" + supplier["phone_number"] + "</td>";
            trHTML += "<td>" + supplier["address"] + "</td>";
            trHTML +=
                '<td><button class="btn btn-outline-secondary" onclick="showSupplierEditBox(' +
                supplier["supplier_id"] +
                ')">Edit</button> ';
            trHTML +=
                '<button class="btn btn-outline-danger" onclick="supplierDelete(' +
                supplier["supplier_id"] +
                ')">Del</button></td>';
            trHTML += "</tr>";

        }

    }


    document.getElementById("mySuppliertable").innerHTML = trHTML;
}
// Render Pagination
function rendersupplierPagination(totalItems) {
    const totalPages = Math.ceil(totalItems / rowsSupplierPerPage);
    let paginationHTML = "";

    paginationHTML += `<li class="page-item ${currentSupplierPage === 1 ? "disabled" : ""}">
      <a class="page-link" href="#" onclick="changesupplierPage(${currentSupplierPage - 1})">Previous</a>
    </li>`;

    for (let i = 1; i <= totalPages; i++) {
        paginationHTML += `<li class="page-item ${currentSupplierPage === i ? "active" : ""}">
      <a class="page-link" href="#" onclick="changesupplierPage(${i})">${i}</a>
    </li>`;
    }

    paginationHTML += `<li class="page-item color-greey ${currentSupplierPage === totalPages ? "disabled" : ""}">
      <a class="page-link" href="#" onclick="changesupplierPage(${currentSupplierPage + 1})">Next</a>
    </li>`;

    document.getElementById("supplier_pagination").innerHTML = paginationHTML;
}
// Page Change
function changesupplierPage(page) {
    const totalPages = Math.ceil(filteredSupplierData.length / rowsSupplierPerPage);
    if (page >= 1 && page <= totalPages) {
        rendersupplierTable(page);
        rendersupplierPagination(filteredSupplierData.length);
    }
}
// Filter/Search
function filtersupplierTable(query) {
    query = query.toLowerCase();
    filteredSupplierData = SupplierData.filter((user) => {
        return (
            user.supplier_id.toString().includes(query) ||
            user.first_name.toString().includes(query) ||
            user.last_name.toString().includes(query) ||
            user.email.toString().includes(query) ||
            user.phone_number.toLowerCase().includes(query) ||
            user.address.toLowerCase().includes(query)
        );
    });

    currentSupplierPage = 1; // Reset to first page
    rendersupplierTable(currentSupplierPage);
    rendersupplierPagination(filteredSupplierData.length);
}
function showsupplierCreateBox() {
    Swal.fire({
        title: "Add supplier",
        showConfirmButton: false,
        html:
            `<div class="createUserForm">
                     <div class="formbold-input-wrapp formbold-mb-3 ">
                            <label for="firstname " class="formbold-form-label text-start"> Supplier name </label>
                            <div>
                                <input type="text" name="supplier_first_name" id="supplier_first_name" placeholder="First name"
                                    class="formbold-form-input"  />
                                <input type="text" name="last_name" id="supplier_last_name" placeholder="Last name"
                                    class="formbold-form-input" />
                            </div>
                        </div>
                    
                    <div class="formbold-mb-3">
                            <label for="email" class="formbold-form-label text-start"> Email </label>
                            <input type="email" name="email" id="supplier_email" placeholder="example@email.com" class="formbold-form-input"
                                />
                    </div>
                     <div class="formbold-mb-3 formbold-input-wrapp">
                            <label for="phone" class="formbold-form-label text-start"> Phone number </label>
                            <input type="text" name="phone" id="supplier_phone_number" placeholder="Phone number 05...."  class="formbold-form-input" />
                            <p class="supplier_Phone_Error text-sm ErrorClear text-danger allertview"></p>
                         </div>

                     <div class="formbold">
                                <label for="address" class="formbold-form-label text-start"> Address </label>
                                <input type="text" name="address" id="supplier_address" placeholder="Country-City-Street..." class="formbold-form-input formbold-mb-3" />
                    </div>
                    <p class="supplier_Error text-sm ErrorClear text-danger allertview text-start"></p>

                    <button type="button" id="add_supplier_btn" class="btn btn-primary button_setting mt-3 mb-4">Add supplier</button>
                </div>`,
        didOpen: () => {
            // Add event listener after modal is rendered
            document.getElementById("add_supplier_btn").addEventListener("click", function (e) {
                e.preventDefault();
                addSupplier();
            });
        }
    });
}
function addSupplier() {
    let supplier_ValidFlag = true;

    const supplier_first_name = document.getElementById("supplier_first_name");
    const supplier_last_name = document.getElementById("supplier_last_name");
    const supplier_email = document.getElementById("supplier_email");
    const supplier_phone_number = document.getElementById("supplier_phone_number");
    const supplier_address = document.getElementById("supplier_address");

    const supplier_error = document.querySelector('.supplier_Error');

    // Regular expressions for validation
    const namePattern = /^[A-Za-z]/;  // Starts with a letter
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    const phonePattern = /^\d{10}$/;

    // Helper functions
    function showError(input, message) {
        input.classList.add("is-invalid");
        supplier_error.classList.remove("allertview");
        supplier_error.innerHTML = message;
        supplier_ValidFlag = false;
    }

    function clearError(input) {
        input.classList.remove("is-invalid");
    }

    // Validation
    if (!namePattern.test(supplier_first_name.value.trim())) {
        showError(supplier_first_name, "First name must start with a letter.");
    } else {
        clearError(supplier_first_name);
    }

    if (!namePattern.test(supplier_last_name.value.trim())) {
        showError(supplier_last_name, "Last name must start with a letter.");
    } else {
        clearError(supplier_last_name);
    }

    if (!emailPattern.test(supplier_email.value.trim())) {
        showError(supplier_email, "Please enter a valid email address.");
    } else {
        clearError(supplier_email);
    }

    if (!phonePattern.test(supplier_phone_number.value)) {
        showError(supplier_phone_number, "Phone number must be exactly 10 digits.");
    } else {
        clearError(supplier_phone_number);
    }

    if (supplier_address.value.trim() === "") {
        showError(supplier_address, "Please enter address.");
    } else {
        clearError(supplier_address);
    }

    // If valid, send data
    if (supplier_ValidFlag) {
        // Remove duplicate email field
        const supplier_data = {
            first_name: supplier_first_name.value.trim(),
            last_name: supplier_last_name.value.trim(),
            email: supplier_email.value.trim(),
            phone_number: supplier_phone_number.value.trim(),
            address: supplier_address.value.trim(),
        };

        // Show loading indicator
        const swalInstance = Swal.fire({
            position: 'bottom-end',
            title: 'Creating supplier...',
            showConfirmButton: false,
            timer: 1500,
            width: '25%',
            background: '#047857',
            allowOutsideClick: false,
            didOpen: () => {
                const swalTitle = Swal.getTitle();
                if (swalTitle) {
                    swalTitle.style.color = '#fff';
                    swalTitle.style.fontSize = '15px';
                }
            }
        });

        const xhttp = new XMLHttpRequest();
        xhttp.open("POST", "./assets/php/add-supplier.php", true); // Changed to POST
        xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
        xhttp.send(JSON.stringify(supplier_data));

        xhttp.onreadystatechange = function () {
            if (this.readyState === 4) {
                swalInstance.close(); // Close loading indicator

                try {
                    const res = JSON.parse(this.responseText);
                    if (this.status === 200 && res.success) {
                        Swal.fire({
                            position: 'bottom-end',
                            title: '✅ Supplier created successfully',
                            showConfirmButton: false,
                            timer: 1500,
                            width: '25%',
                            background: '#047857',
                            didOpen: () => {
                                const swalTitle = Swal.getTitle();
                                if (swalTitle) {
                                    swalTitle.style.color = '#fff';
                                    swalTitle.style.fontSize = '15px';
                                }
                            }
                        });
                        loadsupplierTable();
                        overview();
                    } else {
                        // Show detailed error message from server
                        const errorMsg = res.error || 'Creation failed';
                        Swal.fire({
                            position: 'bottom-end',
                            title: `❌ ${errorMsg}`,
                            showConfirmButton: false,
                            timer: 2500, // Longer for error messages
                            width: '25%',
                            background: '#800000',
                            didOpen: () => {
                                const swalTitle = Swal.getTitle();
                                if (swalTitle) {
                                    swalTitle.style.color = '#fff';
                                    swalTitle.style.fontSize = '15px';
                                }
                            }
                        });
                        console.error('Creation error:', res.error || 'Unknown error');
                    }
                } catch (err) {
                    Swal.fire({
                        position: 'bottom-end',
                        title: '⚠️ Invalid server response',
                        text: 'Please check console for details',
                        showConfirmButton: false,
                        timer: 2500,
                        width: '25%',
                        background: '#b22222',
                        didOpen: () => {
                            const swalTitle = Swal.getTitle();
                            if (swalTitle) {
                                swalTitle.style.color = '#fff';
                                swalTitle.style.fontSize = '15px';
                            }
                        }
                    });
                    console.error('Parsing error:', err, 'Response:', this.responseText);
                }
            }
        };
    }
}

function supplierDelete(id) {
    // Declare outside to make it accessible globally or in outer scope
    const xxhttp = new XMLHttpRequest();
    xxhttp.onreadystatechange = function () {
        if (this.readyState === 4) {
            if (this.status === 200) {
                const employeedata = JSON.parse(this.responseText);
                Swal.fire({
                    title: "Are you sure?",
                    text: "This action cannot be undone!",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonText: "Yes, delete it!",
                    didOpen: () => {
                        const confirmButton = Swal.getConfirmButton();
                        if (confirmButton) confirmButton.style.backgroundColor = '#047857';
                    }
                }).then((result) => {
                    if (result.isConfirmed) {
                        const xhttp = new XMLHttpRequest();
                        xhttp.open("DELETE", "./assets/php/delete-supplier.php", true);
                        xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
                        xhttp.send(JSON.stringify({ supplier_id: id }));
                        xhttp.onreadystatechange = function () {
                            if (this.readyState == 4) {
                                const res = JSON.parse(this.responseText);
                                if (this.status === 200 && !res.error) {
                                    Swal.fire({
                                        position: 'bottom-end',
                                        title: ' &#10004;Supplier deleted successfully',
                                        showConfirmButton: false,
                                        timer: 1500,
                                        width: '25%',
                                        background: '#047857',
                                        didOpen: () => {
                                            const swalTitle = Swal.getTitle();
                                            if (swalTitle) swalTitle.style.color = '#fff';
                                            swalTitle.style.fontSize = '15px'; // Adjust font size
                                        }
                                    });
                                    loadsupplierTable();
                                    overview();
                                } else {
                                    Swal.fire({
                                        position: 'bottom-end',
                                        title: ' &#10006;Failed to delete supplier',
                                        showConfirmButton: false,
                                        timer: 1500,
                                        width: '25%',
                                        background: '#800000',
                                        didOpen: () => {
                                            const swalTitle = Swal.getTitle();
                                            if (swalTitle) swalTitle.style.color = '#fff';
                                            swalTitle.style.fontSize = '15px'; // Adjust font size
                                        }
                                    });
                                }
                            }
                        };
                    }
                });

            }
            else {
                Swal.fire({
                    position: 'bottom-end',
                    title: ' &#10006;Failed to fetch supplier data',
                    showConfirmButton: false,
                    timer: 1500,
                    background: '#800000',
                    didOpen: () => {
                        const swalTitle = Swal.getTitle();
                        if (swalTitle) swalTitle.style.color = '#fff';
                    }
                });
            }
        }
    };
    xxhttp.open("GET", "/DataBase/assets/php/session.php", true);
    xxhttp.send();


}

function showSupplierEditBox(id) {
    upload_flage = 1;

    const xhttp = new XMLHttpRequest();
    xhttp.open("GET", "./assets/php/get-supplier-by-id.php?supplier_id=" + id, true);
    xhttp.send();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            const supplier = JSON.parse(this.responseText).supplier;
            Swal.fire({
                title: "Edit supplier",
                showConfirmButton: false,
                html:
                    `<div class="createUserForm">
                     <div class="formbold-input-wrapp formbold-mb-3 ">
                      <input type="text" name="edit_supplier_id" id="edit_supplier_id" 
                                    class="hidden formbold-form-input" value="${supplier.supplier_id}" />
                            <label for="firstname " class="formbold-form-label text-start"> Supplier name </label>
                            <div>
                                <input type="text" name="supplier_first_name" id="edit_supplier_first_name" placeholder="First name"
                                    class="formbold-form-input" value="${supplier.first_name}" />
                                <input type="text" name="last_name" id="edit_supplier_last_name" placeholder="Last name"
                                    class="formbold-form-input" value="${supplier.last_name}" />
                            </div>
                        </div>
                    
                    <div class="formbold-mb-3">
                            <label for="email" class="formbold-form-label text-start"> Email </label>
                            <input type="email" name="email" id="edit_supplier_email" placeholder="example@email.com" class="formbold-form-input" value="${supplier.email}"
                                />
                    </div>
                     <div class="formbold-mb-3 formbold-input-wrapp">
                            <label for="phone" class="formbold-form-label text-start"> Phone number </label>
                            <input type="text" name="phone" id="edit_supplier_phone_number" placeholder="Phone number 05...."  class="formbold-form-input" value="${supplier.phone_number}"/>
                         </div>

                     <div class="formbold">
                                <label for="address" class="formbold-form-label text-start"> Address </label>
                                <input type="text" name="address" id="edit_supplier_address" placeholder="Country-City-Street..." class="formbold-form-input formbold-mb-3" value="${supplier.address}" />
                    </div>
                    <p class="edit_supplier_Error text-sm ErrorClear text-danger allertview text-start"></p>

                    <button type="button" id="update_supplier_btn" class="btn btn-primary button_setting mt-3 mb-4">Update Supplier</button>
                </div>
              
      `,
                focusConfirm: false,
                didOpen: () => {
                    document.getElementById("update_supplier_btn").addEventListener("click", function (e) {
                        e.preventDefault();
                        UpdateSupplier();
                    });

                }

            });
        }
    };
}

function UpdateSupplier() {
    let edit_supplier_ValidFlag = true;

    const edit_supplier_first_name = document.getElementById("edit_supplier_first_name");
    const edit_supplier_last_name = document.getElementById("edit_supplier_last_name");
    const edit_supplier_email = document.getElementById("edit_supplier_email");
    const edit_supplier_phone_number = document.getElementById("edit_supplier_phone_number");
    const edit_supplier_address = document.getElementById("edit_supplier_address");

    const edit_supplier_error = document.querySelector('.edit_supplier_Error');

    // Regular expressions for validation
    const namePattern = /^[A-Za-z]/;  // Starts with a letter
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    const phonePattern = /^\d{10}$/;

    // Helper functions
    function showError(input, message) {
        input.classList.add("is-invalid");
        edit_supplier_error.classList.remove("allertview");
        edit_supplier_error.innerHTML = message;
        edit_supplier_ValidFlag = false;
    }

    function clearError(input) {
        input.classList.remove("is-invalid");
    }

    // Validation
    if (!namePattern.test(edit_supplier_first_name.value.trim())) {
        showError(edit_supplier_first_name, "First name must start with a letter.");
    } else {
        clearError(edit_supplier_first_name);
    }

    if (!namePattern.test(edit_supplier_last_name.value.trim())) {
        showError(edit_supplier_last_name, "Last name must start with a letter.");
    } else {
        clearError(edit_supplier_last_name);
    }

    if (!emailPattern.test(edit_supplier_email.value.trim())) {
        showError(edit_supplier_email, "Please enter a valid email address.");
    } else {
        clearError(edit_supplier_email);
    }

    if (!phonePattern.test(edit_supplier_phone_number.value)) {
        showError(edit_supplier_phone_number, "Phone number must be exactly 10 digits.");
    } else {
        clearError(edit_supplier_phone_number);
    }

    if (edit_supplier_address.value.trim() === "") {
        showError(edit_supplier_address, "Please enter address.");
    } else {
        clearError(edit_supplier_address);
    }

    // If valid, send data
    if (edit_supplier_ValidFlag) {
        const supplier_data = {
            supplier_id: document.getElementById("edit_supplier_id").value.trim(),
            first_name: edit_supplier_first_name.value.trim(),
            last_name: edit_supplier_last_name.value.trim(),
            email: edit_supplier_email.value.trim(),
            phone_number: edit_supplier_phone_number.value.trim(),
            email: edit_supplier_email.value.trim(),
            address: edit_supplier_address.value.trim(),
        };

        const xhttp = new XMLHttpRequest();
        xhttp.open("PUT", "./assets/php/update-supplier.php", true);
        xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
        xhttp.send(JSON.stringify(supplier_data));

        xhttp.onreadystatechange = function () {
            if (this.readyState === 4) {
                try {
                    const res = JSON.parse(this.responseText);
                    if (this.status === 200 && !res.error) {
                        Swal.fire({
                            position: 'bottom-end',
                            title: '✅ Update supplier success',
                            showConfirmButton: false,
                            timer: 1500,
                            width: '25%',
                            background: '#047857',
                            didOpen: () => {
                                const swalTitle = Swal.getTitle();
                                if (swalTitle) {
                                    swalTitle.style.color = '#fff';
                                    swalTitle.style.fontSize = '15px';
                                }
                            }
                        });
                        loadsupplierTable();
                        overview();

                    } else {
                        Swal.fire({
                            position: 'bottom-end',
                            title: '❌ Update failed',
                            showConfirmButton: false,
                            timer: 1500,
                            width: '25%',
                            background: '#800000',
                            didOpen: () => {
                                const swalTitle = Swal.getTitle();
                                if (swalTitle) {
                                    swalTitle.style.color = '#fff';
                                    swalTitle.style.fontSize = '15px';
                                }
                            }
                        });
                    }
                } catch (err) {
                    Swal.fire({
                        position: 'bottom-end',
                        title: '⚠️ Invalid server response.',
                        showConfirmButton: false,
                        timer: 1500,
                        width: '25%',
                        background: '#b22222',
                        didOpen: () => {
                            const swalTitle = Swal.getTitle();
                            if (swalTitle) {
                                swalTitle.style.color = '#fff';
                                swalTitle.style.fontSize = '15px';
                            }
                        }
                    });
                }
            }
        };
    }
}

loadsupplierTable();



let currentOffersPage = 1;
const rowsOffersPerPage = 12;
let OffersData = [];
let filteredOffersData = [];
// Load Data
function loadOffersTable() {
    const xhttp = new XMLHttpRequest();
    xhttp.open("GET", "./assets/php/get-offers.php", true);
    xhttp.send();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            OffersData = JSON.parse(this.responseText).data;
            filteredOffersData = [...OffersData]; // Start with full data
            renderOffersTable(currentOffersPage);
            renderOffersPagination(filteredOffersData.length);
        }
    };
}
// Render Table
function renderOffersTable(page) {
    currentOffersPage = page;
    const start = (page - 1) * rowsOffersPerPage;
    const end = start + rowsOffersPerPage;
    const paginatedItems = filteredOffersData.slice(start, end);

    let trHTML = "";

    if (paginatedItems.length === 0) {
        trHTML += `<tr><td colspan="10" class="text-center">No products found</td></tr>`;
    } else {
        for (let offer of paginatedItems) {
            trHTML += "<tr>";
            trHTML += "<td>" + offer["id"] + "</td>";
            trHTML += "<td>" + offer["title"] + "</td>";
            trHTML += "<td>" + offer["created_by"] + "</td>";
            trHTML += "<td>" + offer["start_date"] + "</td>";
            trHTML += "<td>" + offer["end_date"] + "</td>";
            trHTML += "<td>" + offer["discount"] + "</td>";
            trHTML += "<td>" + offer["status"] + "</td>";
            trHTML +=
                '<td><button class="btn btn-outline-secondary" onclick="showOffersEditBox(' +
                offer["id"] +
                ')">Edit</button> ';
            trHTML +=
                '<button class="btn btn-outline-danger" onclick="OfferDelete(' +
                offer["id"] +
                ')">Del</button></td>';
            trHTML += "</tr>";

        }

    }


    document.getElementById("myOfferstable").innerHTML = trHTML;
}
// Render Pagination
function renderOffersPagination(totalItems) {
    const totalPages = Math.ceil(totalItems / rowsOffersPerPage);
    let paginationHTML = "";

    paginationHTML += `<li class="page-item ${currentOffersPage === 1 ? "disabled" : ""}">
      <a class="page-link" href="#" onclick="changeOffersPage(${currentOffersPage - 1})">Previous</a>
    </li>`;

    for (let i = 1; i <= totalPages; i++) {
        paginationHTML += `<li class="page-item ${currentOffersPage === i ? "active" : ""}">
      <a class="page-link" href="#" onclick="changeOffersPage(${i})">${i}</a>
    </li>`;
    }

    paginationHTML += `<li class="page-item color-greey ${currentOffersPage === totalPages ? "disabled" : ""}">
      <a class="page-link" href="#" onclick="changeOffersPage(${currentOffersPage + 1})">Next</a>
    </li>`;

    document.getElementById("offers_pagination").innerHTML = paginationHTML;
}
// Page Change
function changeOffersPage(page) {
    const totalPages = Math.ceil(filteredOffersData.length / rowsOffersPerPage);
    if (page >= 1 && page <= totalPages) {
        renderOffersTable(page);
        renderOffersPagination(filteredOffersData.length);
    }
}
// Filter/Search
function filterOffersTable(query) {
    query = query.toLowerCase();
    filteredOffersData = OffersData.filter((offer) => {

        // Safely handle null/undefined values by converting to empty string
        const id = offer.id?.toString() || '';
        const title = offer.title?.toString().toLowerCase() || '';
        const discount = offer.discount?.toString() || '';
        const createdBy = offer.created_by?.toString().toLowerCase() || '';
        const startDate = offer.start_date?.toString().toLowerCase() || '';
        const endDate = offer.end_date?.toString().toLowerCase() || '';
        const status = offer.status?.toString().toLowerCase() || '';

        return (
            id.includes(query) ||
            title.includes(query) ||
            discount.includes(query) ||
            createdBy.includes(query) ||
            startDate.includes(query) ||
            endDate.includes(query) ||
            status.includes(query)
        );
    });

    currentOffersPage = 1; // Reset to first page
    renderOffersTable(currentOffersPage);
    renderOffersPagination(filteredOffersData.length);
}

function showsOffersCreateBox() {
    Swal.fire({
        title: "Add offer",
        showConfirmButton: false,
        html:
            `<div class="createUserForm">
                     
                        <div class="formbold-mb-3 ">
                            <input type="text" name="offers_name" id="offers_name" placeholder="Title"
                                class="formbold-form-input"  />
                        </div>
                        
                         <div class="formbold-input-wrapp formbold-mb-3 ">
                            <div>
                                <input type="date" name="offers_start_date" id="offers_start_date" 
                                    class="formbold-form-input"  />
                                <input type="date" name="offers_end_date" id="offers_end_date" 
                                    class="formbold-form-input" />
                            </div>
                        </div>

                       <div class="formbold-input-wrapp formbold-mb-3 ">
                        <div formbold-input-wrapp formbold-mb-3 >
                            <select name="status_offer" id="status_offer" class="formbold-form-input">
                                <option value="Select status" selected>Select status</option>
                                <option value="Active" >Active</option>
                                <option value="Not-Active">Not-Active</option>
                            </select>
                            <input type="number" name="discount_percentage" id="discount_percentage" 
                                class="formbold-form-input" step="0.1" min="0" max="100" placeholder="Discount percentage" />
                        </div>
                        </div>

                    <p class="Offer_Error text-sm ErrorClear text-danger allertview text-start"></p>

                    <button type="button" id="add_offer_btn" class="btn btn-primary button_setting mt-3 mb-4">Add offer</button>
                 </div>`,
        didOpen: () => {
            // Add event listener after modal is rendered
            document.getElementById("add_offer_btn").addEventListener("click", function (e) {
                e.preventDefault();
                addOffers();
            });
        }
    });
}
function addOffers() {
    let offerValidFlag = true;

    const offers_name = document.getElementById("offers_name");
    const offers_start_date = document.getElementById("offers_start_date");
    const offers_end_date = document.getElementById("offers_end_date");
    const status_offer = document.getElementById("status_offer");
    const discount_percentage = document.getElementById("discount_percentage");

    const offer_error = document.querySelector('.Offer_Error');

    // Helper functions
    function showError(input, message) {
        input.classList.add("is-invalid");
        offer_error.classList.remove("allertview");
        offer_error.innerHTML = message;
        offerValidFlag = false;
    }

    function clearError(input) {
        input.classList.remove("is-invalid");
        offer_error.classList.add("allertview");
        offer_error.innerHTML = "";
    }

    // Validation
    if (offers_name.value.trim() === "") {
        showError(offers_name, "Offer title is required.");
    } else if (offers_name.value.trim().length > 50) {
        showError(offers_name, "Title must be 50 characters or less.");
    } else {
        clearError(offers_name);
    }

    if (offers_start_date.value === "") {
        showError(offers_start_date, "Start date is required.");
    } else {
        clearError(offers_start_date);
    }

    if (offers_end_date.value === "") {
        showError(offers_end_date, "End date is required.");
    } else if (new Date(offers_end_date.value) <= new Date(offers_start_date.value)) {
        showError(offers_end_date, "End date must be after start date.");
    } else {
        clearError(offers_end_date);
    }

    if (status_offer.value === "Select status") {
        showError(status_offer, "Please select a status.");
    } else {
        clearError(status_offer);
    }

    if (discount_percentage.value === "") {
        showError(discount_percentage, "Discount percentage is required.");
    } else if (parseFloat(discount_percentage.value) <= 0 || parseFloat(discount_percentage.value) > 100) {
        showError(discount_percentage, "Discount must be between 0.1 and 100.");
    } else {
        clearError(discount_percentage);
    }

    // If valid, send data
    if (offerValidFlag) {
        const offer_data = {
            account_id: employee_in_sesstion_id, // Matches your table column
            title: offers_name.value.trim(),     // Matches your table column
            start_date: offers_start_date.value,
            end_date: offers_end_date.value,
            status_offer: status_offer.value.trim(),   // Matches your table column
            discount_percentage: discount_percentage.value // Matches your table column
        };

        const xhttp = new XMLHttpRequest();
        xhttp.open("POST", "./assets/php/add-offer.php", true);
        xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
        xhttp.send(JSON.stringify(offer_data));

        xhttp.onreadystatechange = function () {
            if (this.readyState === 4) {
                if (this.status === 404) {
                    Swal.fire({
                        position: 'bottom-end',
                        title: '⚠️ Server Error',
                        text: 'Offer creation endpoint not found (404)',
                        showConfirmButton: false,
                        timer: 2500,
                        width: '25%',
                        background: '#b22222',
                        didOpen: () => {
                            const swalTitle = Swal.getTitle();
                            if (swalTitle) {
                                swalTitle.style.color = '#fff';
                                swalTitle.style.fontSize = '15px';
                            }
                        }
                    });
                    console.error('Endpoint not found. Verify add-offer.php exists at:', './assets/php/add-offer.php');
                }

                try {
                    const res = JSON.parse(this.responseText);
                    if (this.status === 200 && res.success) {
                        Swal.fire({
                            position: 'bottom-end',
                            title: '✅ Offer created successfully',
                            showConfirmButton: false,
                            timer: 2500,
                            width: '25%',
                            background: '#047857',

                        });
                    }
                    overview();
                    loadOffersTable();
                } catch (err) {
                    Swal.fire({
                        position: 'bottom-end',
                        title: '⚠️ Invalid server response',
                        text: 'Please check console for details',
                        showConfirmButton: false,
                        timer: 2500,
                        width: '25%',
                        background: '#b22222',
                        didOpen: () => {
                            const swalTitle = Swal.getTitle();
                            if (swalTitle) {
                                swalTitle.style.color = '#fff';
                                swalTitle.style.fontSize = '15px';
                            }
                        }
                    });
                }
            }
        };
    }
}

function OffersDelete(id) {
    // Declare outside to make it accessible globally or in outer scope
    const xxhttp = new XMLHttpRequest();
    xxhttp.onreadystatechange = function () {
        if (this.readyState === 4) {
            if (this.status === 200) {
                const employeedata = JSON.parse(this.responseText);
                Swal.fire({
                    title: "Are you sure?",
                    text: "This action cannot be undone!",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonText: "Yes, delete it!",
                    didOpen: () => {
                        const confirmButton = Swal.getConfirmButton();
                        if (confirmButton) confirmButton.style.backgroundColor = '#047857';
                    }
                }).then((result) => {
                    if (result.isConfirmed) {
                        const xhttp = new XMLHttpRequest();
                        xhttp.open("DELETE", "./assets/php/delete-supplier.php", true);
                        xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
                        xhttp.send(JSON.stringify({ supplier_id: id }));
                        xhttp.onreadystatechange = function () {
                            if (this.readyState == 4) {
                                const res = JSON.parse(this.responseText);
                                if (this.status === 200 && !res.error) {
                                    Swal.fire({
                                        position: 'bottom-end',
                                        title: ' &#10004;Supplier deleted successfully',
                                        showConfirmButton: false,
                                        timer: 1500,
                                        width: '25%',
                                        background: '#047857',
                                        didOpen: () => {
                                            const swalTitle = Swal.getTitle();
                                            if (swalTitle) swalTitle.style.color = '#fff';
                                            swalTitle.style.fontSize = '15px'; // Adjust font size
                                        }
                                    });
                                    loadsupplierTable();
                                    overview();
                                } else {
                                    Swal.fire({
                                        position: 'bottom-end',
                                        title: ' &#10006;Failed to delete supplier',
                                        showConfirmButton: false,
                                        timer: 1500,
                                        width: '25%',
                                        background: '#800000',
                                        didOpen: () => {
                                            const swalTitle = Swal.getTitle();
                                            if (swalTitle) swalTitle.style.color = '#fff';
                                            swalTitle.style.fontSize = '15px'; // Adjust font size
                                        }
                                    });
                                }
                            }
                        };
                    }
                });

            }
            else {
                Swal.fire({
                    position: 'bottom-end',
                    title: ' &#10006;Failed to fetch supplier data',
                    showConfirmButton: false,
                    timer: 1500,
                    background: '#800000',
                    didOpen: () => {
                        const swalTitle = Swal.getTitle();
                        if (swalTitle) swalTitle.style.color = '#fff';
                    }
                });
            }
        }
    };
    xxhttp.open("GET", "/DataBase/assets/php/session.php", true);
    xxhttp.send();


}

function showOffersEditBox(offer_id) {
    const xhttp = new XMLHttpRequest();
    xhttp.open("GET", `./assets/php/get-offer-by-id.php?offer_id=${offer_id}`, true);
    xhttp.send();

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            const response = JSON.parse(this.responseText);
            const offer = response.offer;
            const products = response.products || [];
            const categories = response.categories || [];
            // Create a modal with tabs for offer details and products
            Swal.fire({
                title: "Edit Offer",
                width: '800px',
                showConfirmButton: false,
                html: `
                    <div class="offer-edit-container">
                        <ul class="nav nav-tabs" id="offerTabs" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active text-green-800 hove:text-green-800"" id="details-tab" data-toggle="tab" href="#details" role="tab">Offer Details</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-green-800 hove:text-green-800" id="products-tab" data-toggle="tab" href="#products_offer" role="tab">Products</a>
                            </li>
                        </ul>
                        
                        <div class="tab-content p-3 ">
                            <!-- Offer Details Tab -->
                            <div class="tab-pane fade show active" id="details" role="tabpanel">
                                <div class="createUserForm bg-white">
                                    <input type="hidden" id="edit_offer_id" value="${offer.offers_id}">
                                    
                                    <div class="formbold-mb-3">
                                        <input type="text" name="offers_name" id="edit_offers_name" placeholder="Title"
                                            class="formbold-form-input" value="${offer.title}" />
                                    </div>
                                    
                                    <div class="formbold-input-wrapp formbold-mb-3">
                                        <div>
                                            <input type="date" name="offers_start_date" id="edit_offers_start_date" 
                                                class="formbold-form-input" value="${offer.start_date}" />
                                            <input type="date" name="offers_end_date" id="edit_offers_end_date" 
                                                class="formbold-form-input" value="${offer.end_date}" />
                                        </div>
                                    </div>

                                    <div class="formbold-input-wrapp formbold-mb-3">
                                        <div>
                                            <select name="status_offer" id="edit_status_offer" class="formbold-form-input">
                                                <option value="Active" ${offer.status_offer === 'Active' ? 'selected' : ''}>Active</option>
                                                <option value="Not-Active" ${offer.status_offer === 'Not-Active' ? 'selected' : ''}>Not-Active</option>
                                            </select>
                                            <input type="number" name="discount_percentage" id="edit_discount_percentage" 
                                                class="formbold-form-input" step="0.1" min="0" max="100" 
                                                value="${offer.discount_percentage}" placeholder="Discount percentage" />
                                        </div>
                                    </div>
                                    
                                    <p class="edit_offer_Error text-sm ErrorClear text-danger allertview text-start"></p>
                                    <button type="button" id="update_offer_btn" class="btn btn-primary button_setting mt-3 mb-4">Update Offer</button>
                                </div>
                            </div>
                            
                            <!-- Products Tab -->
                            <div class="tab-pane fade bg-white" id="products_offer" role="tabpanel">
                                <div class="row bg-white">
                                    <div class="mb-4 bg-white text-start text-black ">
                                        <h5 class="text-sm mb-2">Add Products </h5>
                                        <div class="form-group mb-2">
                                            <select id="offer_category_select" class="form-control">
                                                <option value="">Select Category</option>
                                                ${categories.map(cat =>
                    `<option value="${cat.category_id}">${cat.category_name}</option>`
                ).join('')}
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="text-sm mb-2">Select Products</label>
                                            <select id="offer_product_select" class="form-control" multiple style="height: 200px;">
                                                <option value="">Select a category first</option>
                                            </select>
                                        </div>
                                        <button id="add_products_to_offer" class="btn btn-success mt-2">Add Selected Products</button>
                                    </div>
                                    
                                    <div class="">
                                        <h5>Current Offer Products</h5>
                                        <div id="offer_products_list" class="list-group">
                                            ${products.length > 0 ?
                        products.map(product => `
                                                    <div class="list-group-item d-flex justify-content-between align-items-center">
                                                        ${product.name} (${product.price})
                                                        <button class="btn btn-sm btn-danger remove-product" data-product-id="${product.product_id}">
                                                            Remove
                                                        </button>
                                                    </div>
                                                `).join('')
                        : '<p>No products in this offer</p>'}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `,
                didOpen: () => {
                    // Initialize tab functionality
                    $('#offerTabs a').on('click', function (e) {
                        e.preventDefault();
                        $(this).tab('show');
                    });

                    // Update offer details
                    document.getElementById("update_offer_btn").addEventListener("click", function (e) {
                        e.preventDefault();
                        updateOffer();
                    });

                    // Load products when category changes
                    document.getElementById("offer_category_select").addEventListener("change", function () {
                        const categoryId = this.value;
                        if (categoryId) {
                            loadProductsForCategory(categoryId, offer_id);
                        }
                    });

                    // Add products to offer
                    document.getElementById("add_products_to_offer").addEventListener("click", function () {
                        const selectedProducts = Array.from(document.getElementById("offer_product_select").selectedOptions)
                            .map(option => option.value);

                        if (selectedProducts.length > 0) {
                            addProductsToOffer(offer_id, selectedProducts);
                        }
                    });

                    // Remove product from offer
                    document.querySelectorAll(".remove-product").forEach(btn => {
                        btn.addEventListener("click", function () {
                            const productId = this.getAttribute("data-product-id");
                            removeProductFromOffer(offer_id, productId);
                        });
                    });
                }
            });
        }
    };
}

// Helper function to load products for a category
function loadProductsForCategory(categoryId, offerId) {
    const xhttp = new XMLHttpRequest();
    xhttp.open("GET", `./assets/php/get-products-by-category.php?category_id=${categoryId}&offer_id=${offerId}`, true);
    xhttp.send();

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            const products = JSON.parse(this.responseText).products;
            const productSelect = document.getElementById("offer_product_select");
            productSelect.innerHTML = products.map(product =>
                `<option value="${product.product_id}">${product.name} ($${product.price})</option>`
            ).join('');
        }
    };
}

// Function to add products to an offer
function addProductsToOffer(offerId, productIds) {
    const xhttp = new XMLHttpRequest();
    xhttp.open("POST", "./assets/php/add-products-to-offer.php", true);
    xhttp.setRequestHeader("Content-Type", "application/json");
    xhttp.send(JSON.stringify({
        offer_id: offerId,
        product_ids: productIds
    }));

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            const response = JSON.parse(this.responseText);
            if (response.success) {
                showOffersEditBox(offerId); // Refresh the modal
                Swal.fire({
                    position: 'bottom-end',
                    title: '✅ Products added to offer',
                    showConfirmButton: false,
                    timer: 1500
                });
            } else {
                Swal.fire({
                    position: 'bottom-end',
                    title: '❌ Error adding products',
                    text: response.error || 'Unknown error',
                    showConfirmButton: false,
                    timer: 2500
                });
            }
        }
    };
}

// Function to remove a product from an offer
function removeProductFromOffer(offerId, productId) {

    const xhttp = new XMLHttpRequest();
    xhttp.open("POST", "./assets/php/remove-product-from-offer.php", true);
    xhttp.setRequestHeader("Content-Type", "application/json");
    xhttp.send(JSON.stringify({
        offer_id: offerId,
        product_id: productId
    }));
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            const response = JSON.parse(this.responseText);
            if (response.success) {
                showOffersEditBox(offerId); // Refresh the modal
                Swal.fire({
                    position: 'bottom-end',
                    title: '✅ Product removed from offer',
                    showConfirmButton: false,
                    timer: 1500
                });
            } else {
                Swal.fire({
                    position: 'bottom-end',
                    title: '❌ Error removing product',
                    text: response.error || 'Unknown error',
                    showConfirmButton: false,
                    timer: 2500
                });
            }
        }
    };
}

// Function to update offer details
function updateOffer() {
    const offerId = document.getElementById("edit_offer_id").value;
    const title = document.getElementById("edit_offers_name").value;
    const startDate = document.getElementById("edit_offers_start_date").value;
    const endDate = document.getElementById("edit_offers_end_date").value;
    const status = document.getElementById("edit_status_offer").value;
    const discount = document.getElementById("edit_discount_percentage").value;

    const errorElement = document.querySelector('.edit_offer_Error');
    let isValid = true;

    // Validation
    if (!title) {
        errorElement.textContent = "Title is required";
        isValid = false;
    } else if (new Date(endDate) <= new Date(startDate)) {
        errorElement.textContent = "End date must be after start date";
        isValid = false;
    } else if (!discount || discount <= 0 || discount > 100) {
        errorElement.textContent = "Discount must be between 0.1 and 100";
        isValid = false;
    }

    if (isValid) {
        const xhttp = new XMLHttpRequest();
        xhttp.open("POST", "./assets/php/update-offer.php", true);
        xhttp.setRequestHeader("Content-Type", "application/json");
        xhttp.send(JSON.stringify({
            offer_id: offerId,
            title: title,
            start_date: startDate,
            end_date: endDate,
            status_offer: status,
            discount_percentage: discount
        }));

        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                const response = JSON.parse(this.responseText);
                if (response.success) {
                    Swal.fire({
                        position: 'bottom-end',
                        title: '✅ Offer updated successfully',
                        showConfirmButton: false,
                        timer: 1500
                    });

                    overview();
                    loadOffersTable();

                } else {
                    Swal.fire({
                        position: 'bottom-end',
                        title: '❌ Error updating offer',
                        text: response.error || 'Unknown error',
                        showConfirmButton: false,
                        timer: 2500
                    });
                }
            }
        };
    }
}
async function OfferDelete(id) {
    try {
        const result = await Swal.fire({
            title: "Are you sure?",
            text: "This action cannot be undone!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonText: "Yes, delete it!",
            didOpen: () => {
                const confirmButton = Swal.getConfirmButton();
                if (confirmButton) confirmButton.style.backgroundColor = '#047857';
            }
        });

        if (!result.isConfirmed) return;

        // Send DELETE request with JSON body
        const deleteResponse = await fetch("./assets/php/delete-offer.php", {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ offer_id: id })
        });

        const res = await deleteResponse.json();

        if (deleteResponse.ok && res.success) {
            Swal.fire({
                position: 'bottom-end',
                title: '✔ Offer deleted successfully',
                showConfirmButton: false,
                timer: 1500,
                width: '25%',
                background: '#047857',
                didOpen: () => {
                    const swalTitle = Swal.getTitle();
                    if (swalTitle) {
                        swalTitle.style.color = '#fff';
                        swalTitle.style.fontSize = '15px';
                    }
                }
            });
            loadOffersTable();
            overview();
        } else {
            throw new Error(res.error || "Deletion failed");
        }

    } catch (error) {
        Swal.fire({
            position: 'bottom-end',
            title: '✘ ' + error.message,
            showConfirmButton: false,
            timer: 1500,
            width: '25%',
            background: '#800000',
            didOpen: () => {
                const swalTitle = Swal.getTitle();
                if (swalTitle) {
                    swalTitle.style.color = '#fff';
                    swalTitle.style.fontSize = '15px';
                }
            }
        });
    }
}


loadOffersTable();