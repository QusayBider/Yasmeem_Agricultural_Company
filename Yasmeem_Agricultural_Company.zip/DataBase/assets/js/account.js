fetch('/DataBase/assets/php/session.php',)
  .then(response => {
    if (!response.ok) {
      // Session is expired or not started, redirect to index
      window.location.href = '/DataBase/index.html';
      throw new Error("Redirecting to index...");
    }
    return response.json();
  })
  .then(data => {
    if (data.account_type !== 'Employee') {
      window.location.href = '/DataBase/index.html';
    }
    else if (data.account_type === 'Employee' && ((data.position === 'IT' || data.position === 'Human Resources'))) {

      const Account_procees_remove_hidden = document.querySelectorAll('[name="Account_process"]');

      Account_procees_remove_hidden.forEach(element => {
        element.classList.remove("hidden");
      });

    }
  })


let currentPage = 1;
const rowsPerPage = 12; // Number of rows per page
let usersData = [];
let EmloyeeWatingData = [];
let Employees_tableData = [];
let filtered_employees_tableData = [];
let filteredData = [];
let filteredWatingData = [];
let upload_flage = 0;

const Add_Account_Dashboard_btn = document.getElementById("Add_Account_Dashboard");
let userInSession = {
  user_id: null,
  position: null,
  email: null,
  user_name: null,
  account_type: null,
};
// Load Data
function loadTable() {
  loadWatingEmployeeTable();
  const xhttp = new XMLHttpRequest();
  xhttp.open("GET", "./assets/php/get-users.php", true);
  xhttp.send();
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      usersData = JSON.parse(this.responseText);
      filteredData = [...usersData]; // Start with full data
      renderTable(currentPage);
      renderPagination(filteredData.length);
    }
  };
}
Add_Account_Dashboard_btn.addEventListener("click", (e) => {
  e.preventDefault();
  createUser_Uploadimage();
});
// Render Table
function renderTable(page) {
  currentPage = page;
  const start = (page - 1) * rowsPerPage;
  const end = start + rowsPerPage;
  const paginatedItems = filteredData.slice(start, end);

  let trHTML = "";

  if (paginatedItems.length === 0) {
    trHTML += `<tr><td colspan="12" class="text-center">No accounts found</td></tr>`;
  } else {

    for (let object of paginatedItems) {
      trHTML += `
     <div  class=" col-12 col-sm-6 col-md-4 col-lg-3 account_card">
       <div class="our-team">
       <div class="picture">
        <img class="img-fluid" src="${object["avatar"]}" alt="Avatar">
       </div>
       <div class="team-content ">
        <h3 class="name">${object["first_name"]} ${object["last_name"]}</h3>
        <h5 class="accountType">${object["account_type"]}</h5>
        <span class="account_id_card"><i class="fa-solid fa-thumbtack" style="color: #016f54;"></i> ${object["account_id"]}</span>

       </div>
       <ul class="buttonEditDelete">
        <button onclick="showUserEditBox(${object["account_id"]})" title="Edit Account">
          <i class="fa-solid fa-user-pen"></i>
        </button>
        <button onclick="userDelete(${object["account_id"]})" title="Delete Account" >
          <i class="fa-solid fa-user-xmark"></i>
        </button>
       </ul>
      </div>                          
    </div>  
    `;
    }

  }


  document.getElementById("Dashboard_Accounts").innerHTML = trHTML;
}

// Render Pagination
function renderPagination(totalItems) {
  const totalPages = Math.ceil(totalItems / rowsPerPage);
  let paginationHTML = "";

  paginationHTML += `<li class="page-item ${currentPage === 1 ? "disabled" : ""}">
      <a class="page-link" href="#" onclick="changePage(${currentPage - 1})">Previous</a>
    </li>`;

  for (let i = 1; i <= totalPages; i++) {
    paginationHTML += `<li class="page-item ${currentPage === i ? "active" : ""}">
      <a class="page-link" href="#" onclick="changePage(${i})">${i}</a>
    </li>`;
  }

  paginationHTML += `<li class="page-item color-greey ${currentPage === totalPages ? "disabled" : ""}">
      <a class="page-link" href="#" onclick="changePage(${currentPage + 1})">Next</a>
    </li>`;

  document.getElementById("pagination").innerHTML = paginationHTML;
}

// Page Change
function changePage(page) {
  const totalPages = Math.ceil(filteredData.length / rowsPerPage);
  if (page >= 1 && page <= totalPages) {
    renderTable(page);
    renderPagination(filteredData.length);
  }
}

// Filter/Search
function filterTable(query) {
  query = query.toLowerCase();
  filteredData = usersData.filter((user) => {
    return (
      user.account_id.toString().includes(query) ||
      user.first_name.toLowerCase().includes(query) ||
      user.last_name.toLowerCase().includes(query) ||
      user.email.toLowerCase().includes(query) ||
      user.phone_number.toLowerCase().includes(query) ||
      user.account_type.toLowerCase().includes(query)
    );
  });

  currentPage = 1; // Reset to first page
  renderTable(currentPage);
  renderPagination(filteredData.length);
}

function changePage(page) {
  const totalPages = Math.ceil(usersData.length / rowsPerPage);
  if (page >= 1 && page <= totalPages) {
    currentPage = page;
    renderTable(currentPage);
    renderPagination(usersData.length);
  }
}

function createUser_Uploadimage() {
  const file = document.getElementById('createimage_Create').files[0];
  if (file) {
    return uploadImage(file);
  } else {
    document.getElementById("uploadedImageUrl").value = "https://res.cloudinary.com/dpjwslspm/image/upload/v1746740991/wsl6sxsu5tfonbfhmsga.png";
    userCreate();
  }
}

function userCreate() {

  let ValidFlag = true;

  const first_name = document.getElementById("first_name_Create");
  const last_name = document.getElementById("last_name_Create");
  const email = document.getElementById("Email_Create");
  const password = document.getElementById("password_Create");
  const phone_number = document.getElementById("phone_number_Create");
  const date_of_birth = document.getElementById("date_of_birth_Create");
  const gender = document.getElementById("gender_Create");
  const account_type = document.getElementById("account_type_Create");
  const address = document.getElementById("Address_Create");
  const city = document.getElementById("City_Create");
  const is_active = document.getElementById("is_active_Create");
  const data = {
    first_name: first_name.value.trim(),
    last_name: last_name.value.trim(),
    email: email.value.trim(),
    phone_number: phone_number.value.trim(),
    account_type: account_type.value,
    date_of_birth: date_of_birth.value,
    image: document.getElementById("uploadedImageUrl").value.trim(),
    is_active: is_active.value,
    gender: gender.value,
    address: address.value.trim(),
    city: city.value.trim(),
    password: password.value.trim()
  };

  //varible for alert in css 
  const Name_error_singUp = document.querySelector('.First_Name_Error');
  const Email_error_sinUp = document.querySelector('.Email_Error');
  const Password_error_sinUp = document.querySelector('.Password_Error');
  const Phone_error_sinUp = document.querySelector('.Phone_Error');
  const Birthday_error_sinUp = document.querySelector('.Birthday_Error');

  // Validate required fields

  const namePattern = /^[A-Za-z]/;   // Starts with a letter, allows letters and spaces
  const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;  // Standard email format
  const passwordPattern = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[\W_]).{8,}$/;    // At least 8 characters, one uppercase, one lowercase, one digit, one special character
  const phonePattern = /^\d{10}$/;  // Exactly 10 digits


  if (!namePattern.test(first_name.value)) {
    Name_error_singUp.classList.remove("allertview");
    Name_error_singUp.innerHTML = "Name must start with a letter.";
    first_name.classList.add("is-invalid");
    ValidFlag = false;
  } else {
    Name_error_singUp.innerHTML = " ";
    first_name.classList.remove("is-invalid");
    Name_error_singUp.classList.add("allertview");
  }

  if (!namePattern.test(last_name.value)) {
    Name_error_singUp.classList.remove("allertview");
    Name_error_singUp.innerHTML = "Name must start with a letter.";
    last_name.classList.add("is-invalid");
    ValidFlag = false;
  } else {
    Name_error_singUp.innerHTML = " ";
    last_name.classList.remove("is-invalid");
    Name_error_singUp.classList.add("allertview");
  }

  if (!emailPattern.test(email.value)) {
    Email_error_sinUp.classList.remove("allertview");
    Email_error_sinUp.innerHTML = "Please enter a valid email address.";
    email.classList.add("is-invalid");
    ValidFlag = false;
  } else {
    Email_error_sinUp.innerHTML = " ";
    email.classList.remove("is-invalid");
    Email_error_sinUp.classList.add("allertview");
  }

  if (!passwordPattern.test(password.value)) {
    Password_error_sinUp.classList.remove("allertview");
    Password_error_sinUp.innerHTML = "Password must be at least 8 characters long and include uppercase, lowercase, a number, and a special character.";
    password.classList.add("is-invalid");
    ValidFlag = false;
  } else {
    Password_error_sinUp.innerHTML = " ";
    password.classList.remove("is-invalid");
    Password_error_sinUp.classList.add("allertview");
  }

  if (!phonePattern.test(phone_number.value)) {
    Phone_error_sinUp.classList.remove("allertview");
    Phone_error_sinUp.innerHTML = "Phone number must be exactly 10 digits.";
    phone_number.classList.add("is-invalid");
    ValidFlag = false;
  } else {
    Phone_error_sinUp.innerHTML = " ";
    phone_number.classList.remove("is-invalid");
    Phone_error_sinUp.classList.add("allertview");
  }

  const age = calculateAge(date_of_birth.value);

  if (age < 18 || date_of_birth.value === "") {
    Birthday_error_sinUp.classList.remove("allertview");
    Birthday_error_sinUp.innerHTML = "Your age is under 18. ";
    date_of_birth.classList.add("is-invalid");
    ValidFlag = false;
  }
  else {
    Birthday_error_sinUp.innerHTML = " ";
    date_of_birth.classList.remove("is-invalid");
    Birthday_error_sinUp.classList.add("allertview");
  }
  if (gender.value === "") {
    gender.classList.add("is-invalid");
    ValidFlag = false;
  }
  else {
    gender.classList.remove("is-invalid");
  }
  if (account_type.value === "") {
    account_type.classList.add("is-invalid");
    ValidFlag = false;
  }
  else {
    account_type.classList.remove("is-invalid");
  }
  if (address.value === "") {
    address.classList.add("is-invalid");
    ValidFlag = false;
  }
  else {
    address.classList.remove("is-invalid");
  }
  if (city.value === "") {
    city.classList.add("is-invalid");
    ValidFlag = false;
  }
  else {
    city.classList.remove("is-invalid");
  }
  if (is_active.value === "") {
    is_active.classList.add("is-invalid");
    ValidFlag = false;
  }
  else {
    is_active.classList.remove("is-invalid");
  }


  if (ValidFlag) {
    const xhttp = new XMLHttpRequest();
    xhttp.open("POST", "./assets/php/create-user.php", true);
    xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    xhttp.send(JSON.stringify(data));
    xhttp.onreadystatechange = function () {
      if (this.readyState == 4) {
        try {
          const objects = JSON.parse(this.responseText);
          if (this.status == 200 && !objects.error) {
            Swal.fire({
              position: 'bottom-end',
              title: ' &#10004;	Create user success',
              showConfirmButton: false,
              timer: 1500,
              width: '25%',
              background: '#047857',
              didOpen: () => {
                const swalTitle = Swal.getTitle();
                if (swalTitle) swalTitle.style.color = '#fff';
                swalTitle.style.fontSize = '15px';
              }
            });
            loadTable();
            overview();
            document.getElementById("userForm_Create").reset();
          }
          else if (objects.error === "Email_exists") {
            Swal.fire({
              position: 'bottom-end',
              title: ' &#10006; Email already exists.',
              showConfirmButton: false,
              timer: 1500,
              width: '25%',
              background: '#800000',
              didOpen: () => {
                const swalTitle = Swal.getTitle();
                if (swalTitle) swalTitle.style.color = '#fff';
                swalTitle.style.fontSize = '15px';
              }
            });
          }
          else {
            Swal.fire({
              position: 'bottom-end',
              title: ' &#10006;	Create failed',
              showConfirmButton: false,
              timer: 1500,
              width: '25%',
              background: '#800000',
              didOpen: () => {
                const swalTitle = Swal.getTitle();
                if (swalTitle) swalTitle.style.color = '#fff';
                swalTitle.style.fontSize = '15px';
              }
            });
          }
        } catch (e) {
          console.error("Invalid JSON response:", this.responseText);
          Swal.fire({
            position: 'bottom-end',
            title: ' &#10006;	Server error',
            showConfirmButton: false,
            timer: 1500,
            width: '25%',
            background: '#800000',
            didOpen: () => {
              const swalTitle = Swal.getTitle();
              if (swalTitle) swalTitle.style.color = '#fff';
              swalTitle.style.fontSize = '15px';
            }
          });
        }
      }
    };

  }
}


function showUserEditBox(id) {
  upload_flage = 1;

  const xhttp = new XMLHttpRequest();
  xhttp.open("GET", "./assets/php/get-user.php?id=" + id, true);
  xhttp.send();
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      const user = JSON.parse(this.responseText).user;

      Swal.fire({
        title: "Edit Account",
        confirmButtonText: 'Update User',
        confirmButtonColor: '#047857',
        html: `
                <div class="formbold-form-wrapper">
                    <form action="https://formbold.com/s/FORM_ID" method="POST" class="text-start">
                        <input type="hidden" id="account_id" value="${user.account_id}" />
                        <div class="formbold-input-wrapp formbold-mb-3 ">
                            <label for="firstname " class="formbold-form-label"> Name </label>
                            <div>
                                <input type="text" name="first_name" id="first_name" placeholder="First name"
                                    class="formbold-form-input" value="${user.first_name || ''}" />
                                <input type="text" name="last_name" id="last_name" placeholder="Last name"
                                    class="formbold-form-input" value="${user.last_name || ''}" />
                            </div>
                            <p class="First_Name_Error text-sm ErrorClear text-danger allertview"></p>
                        </div>

                        <div class="formbold-mb-3">
                            <label for="email" class="formbold-form-label"> Email </label>
                            <input type="email" name="email" id="Email" placeholder="example@email.com" class="formbold-form-input"
                                value="${user.email || ''}" />
                            <p class="Email_Error text-sm ErrorClear text-danger allertview"></p>
                        </div>

                        <div class="formbold-mb-3">
                            <label for="password" class="formbold-form-label"> Password </label>
                            <input type="password" name="password" id="password" placeholder="New Password (leave blank to keep)" class="formbold-form-input" />
                             <p class="Password_Error text-sm ErrorClear text-danger allertview "></p>

                        </div>

                        <div class="formbold-mb-3 formbold-input-wrapp">
                            <label for="phone" class="formbold-form-label"> Phone </label>
                            <input type="text" name="phone" id="phone_number" placeholder="Phone number 05...." value="${user.phone_number || ''}" class="formbold-form-input" />
                            <p class="Phone_Error text-sm ErrorClear text-danger allertview"></p>
                         </div>

                        <div class="formbold-mb-3">
                            <label for="date_of_birth" class="formbold-form-label"> Date of Birth </label>
                            <input type="date" name="dob" id="date_of_birth" class="formbold-form-input" value="${user.date_of_birth || ''}" />
                            <p class="Birthday_Error text-sm ErrorClear text-danger allertview"></p>
                        </div>

                        <div class="formbold-mb-3">
                            <label class="formbold-form-label" for="gender">Gender</label>

                            <select class="formbold-form-input" name="gender" id="gender">
                                <option value="Male" ${user.gender === 'Male' ? 'selected' : ''}>Male</option>
                                <option value="Female" ${user.gender === 'Female' ? 'selected' : ''}>Female</option>
                            </select>
                        </div>

                        <div class="formbold-input-flex">
                            <div class="formbold">
                                <label for="address" class="formbold-form-label"> Address </label>
                                <input type="text" name="address" id="Address" placeholder="Street address" value="${user.address}" class="formbold-form-input formbold-mb-3" />
                            </div>

                            <div>
                                <label for="City" class="formbold-form-label"> City </label>
                                <input type="text" name="city" id="City" placeholder="ex: Ramallah" class="formbold-form-input"
                                    value="${user.city || ''}" />
                            </div>
                        </div>

                        <div class="formbold-mb-3">
                            <label for="image" class="formbold-form-label"> Upload Photo </label>
                            <input type="file" name="upload" id="image" class="formbold-form-input formbold-form-file" />
                            <input type="hidden" id="uploadedImageUrl" name="uploadedImageUrl" value="${user.image}" />
                        </div>

                      <div class="formbold-input-flex">
                        <div class="formbold-mb-3">
                          <label for="account_type" class="formbold-form-label">Account Type</label>
                          <select class="formbold-form-input" name="account_type" id="account_type">
                            <option value="Employee" ${user.account_type === 'Employee' ? 'selected' : ''}>Employee</option>
                            <option value="Customer" ${user.account_type === 'Customer' ? 'selected' : ''}>Customer</option>
                          </select>
                        </div>

                        <div class="formbold-mb-3">
                          <label for="is_active" class="formbold-form-label">Account state</label>
                          <select class="formbold-form-input" name="is_active" id="is_active">
                            <option value="Active" ${user.is_active === 'Active' ? 'selected' : ''}>Active</option>
                            <option value="Not-Active" ${user.is_active === 'Not-Active' ? 'selected' : ''}>Not Active</option>
                          </select>
                        </div>
                      </div>

                      <div class="formbold-input-flex">
                        <div class="formbold-mb-3">
                            <label for="create_at" class="formbold-form-label"> Create at </label>
                            <input type="text" name="post" id="post" disabled class="formbold-form-input "
                                value="${user.created_at || ''}" />
                        </div>
                      </div>
                    </form>
                </div>
            </div>
      `,
        focusConfirm: false,
        preConfirm: () => {
          let file = document.getElementById('image').files[0];

          if (file == undefined) {
            document.getElementById("uploadedImageUrl").value = user.image;
            return userEdit();
          } else {
            upload_flage = 1; // Set flag to indicate image upload
            return uploadImage(file);
          }
        }

      });
    }
  };
}

function userEdit() {
  let ValidFlag = true;

  const first_name = document.getElementById("first_name");
  const last_name = document.getElementById("last_name");
  const email = document.getElementById("Email");
  const password = document.getElementById("password");
  const phone_number = document.getElementById("phone_number");
  const date_of_birth = document.getElementById("date_of_birth");
  const gender = document.getElementById("gender");
  const account_type = document.getElementById("account_type");
  const address = document.getElementById("Address");
  const city = document.getElementById("City");
  const is_active = document.getElementById("is_active");

  const data = {
    account_id: document.getElementById("account_id").value.trim(),
    first_name: first_name.value.trim(),
    last_name: last_name.value.trim(),
    email: email.value.trim(),
    phone_number: phone_number.value.trim(),
    account_type: account_type.value,
    date_of_birth: date_of_birth.value,
    image: document.getElementById("uploadedImageUrl").value.trim(),
    is_active: is_active.value,
    gender: gender.value,
    address: address.value,
    city: city.value
  };
  if (password.value.trim() !== "") {
    data.password = password.value.trim();
  }


  //varible for alert in css 
  const Name_error_singUp = document.querySelector('.First_Name_Error');
  const Email_error_sinUp = document.querySelector('.Email_Error');
  const Password_error_sinUp = document.querySelector('.Password_Error');
  const Phone_error_sinUp = document.querySelector('.Phone_Error');
  const Birthday_error_sinUp = document.querySelector('.Birthday_Error');

  // Validate required fields

  const namePattern = /^[A-Za-z]/;   // Starts with a letter, allows letters and spaces
  const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;  // Standard email format
  const passwordPattern = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[\W_]).{8,}$/;    // At least 8 characters, one uppercase, one lowercase, one digit, one special character
  const phonePattern = /^\d{10}$/;  // Exactly 10 digits


  if (!namePattern.test(first_name.value)) {
    Name_error_singUp.classList.remove("allertview");
    Name_error_singUp.innerHTML = "Name must start with a letter.";
    first_name.classList.add("is-invalid");
    ValidFlag = false;
  } else {
    Name_error_singUp.innerHTML = " ";
    first_name.classList.remove("is-invalid");
    Name_error_singUp.classList.add("allertview");
  }

  if (!namePattern.test(last_name.value)) {
    Name_error_singUp.classList.remove("allertview");
    Name_error_singUp.innerHTML = "Name must start with a letter.";
    last_name.classList.add("is-invalid");
    ValidFlag = false;
  } else {
    Name_error_singUp.innerHTML = " ";
    last_name.classList.remove("is-invalid");
    Name_error_singUp.classList.add("allertview");
  }

  if (!emailPattern.test(email.value)) {
    Email_error_sinUp.classList.remove("allertview");
    Email_error_sinUp.innerHTML = "Please enter a valid email address.";
    email.classList.add("is-invalid");
    ValidFlag = false;
  } else {
    Email_error_sinUp.innerHTML = " ";
    email.classList.remove("is-invalid");
    Email_error_sinUp.classList.add("allertview");
  }

  if (!passwordPattern.test(password.value) && password.value.trim() !== "") {
    Password_error_sinUp.classList.remove("allertview");
    Password_error_sinUp.innerHTML = "Password must be at least 8 characters long and include uppercase, lowercase, a number, and a special character.";
    password.classList.add("is-invalid");
    ValidFlag = false;
  } else {
    Password_error_sinUp.innerHTML = " ";
    password.classList.remove("is-invalid");
    Password_error_sinUp.classList.add("allertview");
  }

  if (!phonePattern.test(phone_number.value)) {
    Phone_error_sinUp.classList.remove("allertview");
    Phone_error_sinUp.innerHTML = "Phone number must be exactly 10 digits.";
    phone_number.classList.add("is-invalid");
    ValidFlag = false;
  } else {
    Phone_error_sinUp.innerHTML = " ";
    phone_number.classList.remove("is-invalid");
    Phone_error_sinUp.classList.add("allertview");
  }

  const age = calculateAge(date_of_birth.value);

  if (age < 18 || date_of_birth.value === "") {
    Birthday_error_sinUp.classList.remove("allertview");
    Birthday_error_sinUp.innerHTML = "Your age is under 18. ";
    date_of_birth.classList.add("is-invalid");
    ValidFlag = false;
  }
  else {
    Birthday_error_sinUp.innerHTML = " ";
    date_of_birth.classList.remove("is-invalid");
    Birthday_error_sinUp.classList.add("allertview");
  }
  if (gender.value === "") {
    gender.classList.add("is-invalid");
    ValidFlag = false;
  }
  else {
    gender.classList.remove("is-invalid");
  }
  if (account_type.value === "") {
    account_type.classList.add("is-invalid");
    ValidFlag = false;
  }
  else {
    account_type.classList.remove("is-invalid");
  }
  if (address.value === "") {
    address.classList.add("is-invalid");
    ValidFlag = false;
  }
  else {
    address.classList.remove("is-invalid");
  }
  if (city.value === "") {
    city.classList.add("is-invalid");
    ValidFlag = false;
  }
  else {
    city.classList.remove("is-invalid");
  }
  if (is_active.value === "") {
    is_active.classList.add("is-invalid");
    ValidFlag = false;
  }
  else {
    is_active.classList.remove("is-invalid");
  }


  if (ValidFlag) {
    //  Send data if valid
    const xhttp = new XMLHttpRequest();
    xhttp.open("PUT", "./assets/php/update-user.php", true);
    xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    xhttp.send(JSON.stringify(data));
    xhttp.onreadystatechange = function () {
      if (this.readyState == 4) {
        try {
          const res = JSON.parse(this.responseText);
          if (this.status == 200 && !res.error) {

            Swal.fire({
              position: 'bottom-end',
              title: ' &#10004;		Update user success',
              showConfirmButton: false,
              timer: 1500,
              width: '25%',
              background: '#047857',
              didOpen: () => {
                // Change text color directly
                const swalTitle = Swal.getTitle();
                if (swalTitle) swalTitle.style.color = '#fff';
                swalTitle.style.fontSize = '15px'; // Adjust font size
              }
            });

            setTimeout(() => {
              overview();
              loadWatingEmployeeTable();
              loadTable();
            }, 300);
          } else if (res.error === "Email already in use by another account") {
            Swal.fire({
              position: 'bottom-end',
              title: ' &#10006; Email already in use by another account.',
              showConfirmButton: false,
              timer: 1500,
              width: '25%',
              background: '#800000',
              didOpen: () => {
                const swalTitle = Swal.getTitle();
                if (swalTitle) swalTitle.style.color = '#fff';
                swalTitle.style.fontSize = '15px'; // Adjust font size
              }
            });
          } else {
            Swal.fire({
              position: 'bottom-end',
              title: ' &#10006;	 Update failed',
              showConfirmButton: false,
              timer: 1500,
              width: '25%',
              background: '#800000',
              didOpen: () => {
                // Change text color directly
                const swalTitle = Swal.getTitle();
                if (swalTitle) swalTitle.style.color = '#fff';
                swalTitle.style.fontSize = '15px'; // Adjust font size
              }
            });
          }
        } catch (err) {
          Swal.fire({
            position: 'bottom-end',
            title: ' &#10069;Invalid server response.',
            showConfirmButton: false,
            timer: 1500,
            width: '25%',
            background: '#b22222	',
            didOpen: () => {
              // Change text color directly
              const swalTitle = Swal.getTitle();
              if (swalTitle) swalTitle.style.color = '#fff';
              swalTitle.style.fontSize = '15px'; // Adjust font size
            }
          });

        }
      }
    };
  }
}

function uploadImage(fileInput) {
  return new Promise((resolve, reject) => {

    const file = fileInput; // Get the file from the input];

    if (!file) {
      Swal.fire("Validation Error", "Please select an image.", "warning");
      return reject(); // Reject if no file selected
    }

    const formData = new FormData();
    formData.append("file", file);
    formData.append("upload_preset", "unsigned_user_uploads");

    fetch("https://api.cloudinary.com/v1_1/dpjwslspm/image/upload", {
      method: "POST",
      body: formData
    })
      .then(res => res.json())
      .then(data => {
        if (data.secure_url) {
          document.getElementById('uploadedImageUrl').value = data.secure_url;
          console.log("Uploaded Image URL:", data.secure_url);

          if (upload_flage == 1) {
            userEdit();
            upload_flage = 0;
          }
          else {
            userCreate();
          }

          resolve(data.secure_url); // Resolve promise with URL
        } else {
          Swal.fire("Upload Error", data.error?.message || "Failed to upload image.", "error");
          reject();
        }
      })
      .catch(err => {
        console.error("Upload error:", err);
        Swal.fire("Upload Error", "Something went wrong while uploading.", "error");
        reject();
      });
  });
}


function userDelete(id) {
  // Declare outside to make it accessible globally or in outer scope
  const xxhttp = new XMLHttpRequest();
  xxhttp.onreadystatechange = function () {
    if (this.readyState === 4) {
      if (this.status === 200) {
        const employeedata = JSON.parse(this.responseText);
        console.log(employeedata.position);
        if (employeedata.user_id == id && employeedata.position != "IT") {
          Swal.fire({
            position: 'bottom-end',
            title: ' &#10006; You cannot delete your own account.',
            showConfirmButton: false,
            timer: 1500,
            width: '25%',
            background: '#800000',
            didOpen: () => {
              const swalTitle = Swal.getTitle();
              if (swalTitle) swalTitle.style.color = '#fff';
              swalTitle.style.fontSize = '15px'; // Adjust font size
            }
          });
        }
        else {
          Swal.fire({
            title: "Are you sure?",
            text: "This action cannot be undone!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonText: "Yes, delete it!",
            didOpen: () => {
              const confirmButton = Swal.getConfirmButton();
              if (confirmButton) confirmButton.style.backgroundColor = '#047857';
            }
          }).then((result) => {
            if (result.isConfirmed) {
              const xhttp = new XMLHttpRequest();
              xhttp.open("DELETE", "./assets/php/delete-user.php", true);
              xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
              xhttp.send(JSON.stringify({ id: id }));
              xhttp.onreadystatechange = function () {
                if (this.readyState == 4) {
                  const res = JSON.parse(this.responseText);
                  if (this.status === 200 && !res.error) {
                    Swal.fire({
                      position: 'bottom-end',
                      title: ' &#10004;User deleted successfully',
                      showConfirmButton: false,
                      timer: 1500,
                      width: '25%',
                      background: '#047857',
                      didOpen: () => {
                        const swalTitle = Swal.getTitle();
                        if (swalTitle) swalTitle.style.color = '#fff';
                        swalTitle.style.fontSize = '15px'; // Adjust font size
                      }
                    });
                    loadTable();
                    overview();
                  } else {
                    Swal.fire({
                      position: 'bottom-end',
                      title: ' &#10006;Failed to delete user',
                      showConfirmButton: false,
                      timer: 1500,
                      width: '25%',
                      background: '#800000',
                      didOpen: () => {
                        const swalTitle = Swal.getTitle();
                        if (swalTitle) swalTitle.style.color = '#fff';
                        swalTitle.style.fontSize = '15px'; // Adjust font size
                      }
                    });
                  }
                }
              };
            }
          });
        }
      }
      else {
        Swal.fire({
          position: 'bottom-end',
          title: ' &#10006;Failed to fetch user data',
          showConfirmButton: false,
          timer: 1500,
          background: '#800000',
          didOpen: () => {
            const swalTitle = Swal.getTitle();
            if (swalTitle) swalTitle.style.color = '#fff';
          }
        });
      }
    }
  };
  xxhttp.open("GET", "/DataBase/assets/php/session.php", true);
  xxhttp.send();


}

function calculateAge(birthday) {
  const birthDate = new Date(birthday);
  const today = new Date();
  let age = today.getFullYear() - birthDate.getFullYear();
  const m = today.getMonth() - birthDate.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  return age;
}


// LoadwatingEmployee

function loadWatingEmployeeTable() {
  const EmployeeonWating = document.getElementById("Wating_Employee_notification_count");
  const xhttp = new XMLHttpRequest();
  xhttp.open("GET", "./assets/php/get-wating-employee.php", true);
  xhttp.send();
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      EmloyeeWatingData = JSON.parse(this.responseText);
      filteredWatingData = [...EmloyeeWatingData]; // Start with full data
      renderWatingTable_Employee(currentPage);
      renderWatingPagination(filteredWatingData.length);
      if (filteredWatingData.length > 0) {
        EmployeeonWating.classList.remove("hidden");
        EmployeeonWating.querySelector("span").innerHTML = filteredWatingData.length;
      }
      else {
        EmployeeonWating.classList.add("hidden");
      }
    }
  };
}


function renderWatingTable_Employee(page) {
  currentPage = page;
  const start = (page - 1) * rowsPerPage;
  const end = start + rowsPerPage;
  const paginatedItems = filteredWatingData.slice(start, end);

  let trHTML = "";

  if (paginatedItems.length === 0) {
    trHTML += `<tr><td colspan="12" class="text-center m-8">No Employee on wating</td></tr>`;
  } else {

    for (let object of paginatedItems) {
      trHTML += `
     <div  class=" col-12 col-sm-6 col-md-4 col-lg-3 account_card">
       <div class="our-team">
       <div class="picture">
        <img class="img-fluid" src="${object["avatar"]}" alt="Avatar">
       </div>
       <div class="team-content ">
        <h3 class="name">${object["first_name"]} ${object["last_name"]}</h3>
        <h5 class="accountType">${object["account_type"]}</h5>
        <span class="account_id_card"><i class="fa-solid fa-thumbtack" style="color: #016f54;"></i> ${object["account_id"]}</span>

       </div>
       <ul class="buttonEditDelete">
        <button onclick="showEmpolyeeAddBox(${object["account_id"]})" title="Add Employee">
          <i class="fa-solid fa-user-plus"></i>
        </button>
       </ul>
      </div>                          
    </div>  
    `;
    }

  }

  document.getElementById("Wating_List_Employee").innerHTML = trHTML;
}

function changeWatingPage(page) {
  const totalPages = Math.ceil(EmloyeeWatingData.length / rowsPerPage);
  if (page >= 1 && page <= totalPages) {
    currentPage = page;
    renderWatingTable_Employee(currentPage);
    renderWatingPagination(EmloyeeWatingData.length);
  }
}

// Render Pagination
function renderWatingPagination(totalItems) {
  const totalPages = Math.ceil(totalItems / rowsPerPage);
  let paginationHTML = "";

  paginationHTML += `<li class="page-item ${currentPage === 1 ? "disabled" : ""}">
      <a class="page-link" href="#" onclick="changeWatingPage(${currentPage - 1})">Previous</a>
    </li>`;

  for (let i = 1; i <= totalPages; i++) {
    paginationHTML += `<li class="page-item ${currentPage === i ? "active" : ""}">
      <a class="page-link" href="#" onclick="changeWatingPage(${i})">${i}</a>
    </li>`;
  }

  paginationHTML += `<li class="page-item color-greey ${currentPage === totalPages ? "disabled" : ""}">
      <a class="page-link" href="#" onclick="changeWatingPage(${currentPage + 1})">Next</a>
    </li>`;

  document.getElementById("wating_employee_pagination").innerHTML = paginationHTML;
}

function showEmpolyeeAddBox(id) {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function () {
    if (this.readyState === 4 && this.status === 200) {
      try {
        var data = JSON.parse(this.responseText);
        var select = document.getElementById("Employee_branch");

        if (Array.isArray(data)) {
          data.forEach(function (branch) {
            var option = document.createElement("option");
            option.value = branch.branch_id;
            option.text = branch.name;
            select.appendChild(option);
          });
        } else {
          console.error("Unexpected response format:", data);
        }
      } catch (e) {
        console.error("Failed to parse JSON:", e);
      }
    }
  };

  xhttp.open("GET", "./assets/php/get_all_branches.php", true);
  xhttp.send();
  Swal.fire({
    title: "Add Employee",
    confirmButtonText: 'Add Employee',
    confirmButtonColor: '#047857',
    html: `
        <div class="formbold-main-wrapper mt-4 ">
                      <div class="formbold-form-wrapper">
                          <form action="https://formbold.com/s/FORM_ID" method="POST" class="  text-start"
                              id="UserForm_Employee">
                              <div class="formbold-input-flex">
                                 <div class="formbold-mb-3">
                                  <label for="branch" class="formbold-form-label">Branch</label>
                                  <select class="formbold-form-input" name="Branch" id="Employee_branch">
                                    <option value="">Select branch</option>
                                  </select>
                                </div>

                                  <div class="formbold-mb-3">
                                      <label for="Employee_positions"
                                          class="formbold-form-label">positions</label>
                                      <select class="formbold-form-input" name="positions"
                                          id="Employee_positions">
                                          <option value="">select positions </option>
                                          <option value="Employee">Employee</option>
                                          <option value="Human Resources">Human Resources</option>
                                          <option value="Branch Manager">Branch Manager</option>
                                          <option value="Warehouse Manager">Warehouse Manager</option>
                                          <option value="Accountant">Accountant</option>
                                          <option value="Head of Product">Head of Product</option>
                                          <option value="Product Manager">Product Manager</option>
                                          <option value="Customer Service">Customer Service</option>
                                          <option value="IT">IT</option>
                                          
                                      </select>
                                  </div>
                              </div>

                              <div class="formbold-input-flex">
                                  <div class="formbold-mb-3">
                                      <label for="Employee_salary" class="formbold-form-label">Salary</label>
                                      <input type="number" name="salary" id="Employee_salary"
                                          placeholder="Enter salary" class="formbold-form-input" />
                                      <p class="Salary_Error text-sm ErrorClear text-danger allertview"></p>
                                  </div>
                                  <div class="formbold-mb-3">
                                      <label for="Employee_hire_date" class="formbold-form-label">Hire
                                          Date</label>
                                      <input type="date" name="hire_date" id="Employee_hire_date"
                                          class="formbold-form-input" value="${new Date().toISOString().split('T')[0]}"/>
                                  </div>

                              </div>
                          </form>
                      </div>
                  </div>
      `,
    focusConfirm: false,
    preConfirm: () => {
      const branch_id = document.getElementById("Employee_branch").value;
      const position = document.getElementById("Employee_positions").value;
      const salary = document.getElementById("Employee_salary").value;

      let isValid = true;

      const salaryPattern = /^\d+(\.\d{1,2})?$/;  // e.g., 50000 or 50000.50
      const Salary_error = document.querySelector('.Salary_Error');
      if (!salaryPattern.test(salary) || salary <= 0) {
        Salary_error.classList.remove("allertview");
        Salary_error.innerHTML = "Please enter a valid salary.";
        document.getElementById("Employee_salary").classList.add("is-invalid");
        isValid = false;
        return false
      } else {
        Salary_error.innerHTML = " ";
        document.getElementById("Employee_salary").classList.remove("is-invalid");
        Salary_error.classList.add("allertview");
      }

      if (branch_id === "") {
        document.getElementById("Employee_branch").classList.add("is-invalid");
        isValid = false;
        return false
      } else {
        document.getElementById("Employee_branch").classList.remove("is-invalid");
      }
      if (position === "") {
        document.getElementById("Employee_positions").classList.add("is-invalid");
        isValid = false;
        return false
      }
      else {
        document.getElementById("Employee_positions").classList.remove("is-invalid");
      }
      if (isValid) {
        return addEmployee(id);
      } else {
        Swal.fire({
          position: 'bottom-end',
          title: ' &#10006; Please fill in all required fields correctly.',
          showConfirmButton: false,
          timer: 1500,
          width: '25%',
          background: '#800000',
          didOpen: () => {
            const swalTitle = Swal.getTitle();
            if (swalTitle) swalTitle.style.color = '#fff';
            swalTitle.style.fontSize = '15px'; // Adjust font size
          }
        });
        return false; // Prevent form submission
      }

    }

  });
}


function addEmployee(account_id) {
  const employeeData = {
    account_id: account_id,
    branch_id: document.getElementById("Employee_branch").value,
    manager_id: null, // Assuming manager_id is not needed for this request
    hire_date: document.getElementById("Employee_hire_date").value,
    position: document.getElementById("Employee_positions").value,
    salary: parseFloat(document.getElementById("Employee_salary").value)

  };

  const xhttp = new XMLHttpRequest();
  xhttp.open("POST", "./assets/php/add_employee.php", true);
  xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");

  xhttp.onreadystatechange = function () {
    if (this.readyState === 4) {
      try {
        const response = JSON.parse(this.responseText);
        if (this.status === 200 && response.message) {
          // Successfully added employee

          Swal.fire({
            position: 'bottom-end',
            title: '✅Employee added successfully',
            showConfirmButton: false,
            timer: 1500,
            width: '25%',
            background: '#047857',
            didOpen: () => {
              const swalTitle = Swal.getTitle();
              if (swalTitle) swalTitle.style.color = '#fff';
              swalTitle.style.fontSize = '15px'; // Adjust font size

            }

          });
          loadTable();
          loadEmployeeTable();
          loadWatingEmployeeTable();
          overview();
        } else {
          Swal.fire({
            position: 'bottom-end',
            title: `❌Failed to add employee: ${response.error || 'Unknown error'}`,
            showConfirmButton: false,
            timer: 1500,
            width: '25%',
            background: '#800000',
            didOpen: () => {
              const swalTitle = Swal.getTitle();
              if (swalTitle) swalTitle.style.color = '#fff';
              swalTitle.style.fontSize = '15px'; // Adjust font size
            }
          });
        }
      } catch (e) {
        Swal.fire({
          position: 'bottom-end',
          title: '⚠️ Unexpected response from server.',
          showConfirmButton: false,
          timer: 1500,
          width: '25%',
          background: '#b22222',
          didOpen: () => {
            const swalTitle = Swal.getTitle();
            if (swalTitle) swalTitle.style.color = '#fff';
            swalTitle.style.fontSize = '15px'; // Adjust font size
          }
        });
      }
    }
  };

  xhttp.send(JSON.stringify(employeeData));
}

// Employee page
function loadEmployeeTable() {
  const xhttp = new XMLHttpRequest();
  xhttp.open("GET", "./assets/php/get-employees-branch-account.php", true);
  xhttp.send();
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      const parsedResponse = JSON.parse(this.responseText);
      Employees_tableData = parsedResponse.employees;
      filtered_employees_tableData = [...Employees_tableData]; // Start with full data
      render_Employees_Table(currentPage);
      render_Employees_Pagination(filtered_employees_tableData.length);
    }
  };
}

function render_Employees_Table(page) {
  currentPage = page;
  const start = (page - 1) * rowsPerPage;
  const end = start + rowsPerPage;
  const paginatedItems = filtered_employees_tableData.slice(start, end);

  let trHTML = "";

  if (paginatedItems.length === 0) {
    trHTML += `<tr><td colspan="12" class="text-center m-5">   No Employees found   </td></tr>`;
  } else {

    for (let object of paginatedItems) {
      trHTML += `
     <div  class=" col-12 col-sm-6 col-md-4 col-lg-3 account_card">
       <div class="our-team">
       <div class="picture">
        <img class="img-fluid" src="${object["image"]}" alt="Avatar">
       </div>
       <div class="team-content ">
        <h3 class="name">${object["first_name"]} ${object["last_name"]}</h3>
        <h5 class="accountType">${object["position"]}</h5>
        <span class="account_id_card"><i class="fa-solid fa-thumbtack" style="color: #016f54;"></i> ${object["employee_id"]}</span>
        <h4 class="accountType"><i class="fa-solid fa-people-roof fa-xs"></i> ${object["branch_name"]} - <i class="fa-solid fa-phone fa-xs"></i>${object["branch_phone"]}</h5>

       </div>
        <ul class="buttonEditDelete">
         <button onclick="showEmpolyeeEditBox(${object["employee_id"]})" title="Edit Account">
          <i class="fa-solid fa-user-pen"></i>
          </button>
          <button onclick="employeeDelete(${object["account_id"]})" title="Delete Account" >
          <i class="fa-solid fa-user-xmark"></i>
         </button>
       </ul>
      </div>                          
    </div>  
    `;
    }

  }

  document.getElementById("Dashboard_Employee_Edit").innerHTML = trHTML;
}

function render_Employees_Pagination(totalItems) {
  const totalPages = Math.ceil(totalItems / rowsPerPage);
  let paginationHTML = "";

  paginationHTML += `<li class="page-item ${currentPage === 1 ? "disabled" : ""}">
      <a class="page-link" href="#" onclick="change_EmployeePage(${currentPage - 1})">Previous</a>
    </li>`;

  for (let i = 1; i <= totalPages; i++) {
    paginationHTML += `<li class="page-item ${currentPage === i ? "active" : ""}">
      <a class="page-link" href="#" onclick="change_EmployeePage(${i})">${i}</a>
    </li>`;
  }

  paginationHTML += `<li class="page-item color-greey ${currentPage === totalPages ? "disabled" : ""}">
      <a class="page-link" href="#" onclick="change_EmployeePage(${currentPage + 1})">Next</a>
    </li>`;

  document.getElementById("pagination_Edit_Employee").innerHTML = paginationHTML;
}

function change_EmployeePage(page) {
  const totalPages = Math.ceil(Employees_tableData.length / rowsPerPage);
  if (page >= 1 && page <= totalPages) {
    currentPage = page;
    render_Employees_Table(currentPage);
    render_Employees_Pagination(Employees_tableData.length);
  }
}

function showEmpolyeeEditBox(id) {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function () {
    if (this.readyState === 4 && this.status === 200) {
      try {
        var data = JSON.parse(this.responseText);
        var select = document.getElementById("Employee_Edit_branch");

        if (Array.isArray(data)) {
          data.forEach(function (branch) {
            var option = document.createElement("option");
            option.value = branch.branch_id;
            option.text = branch.name;
            select.appendChild(option);
          });
        } else {
          console.error("Unexpected response format:", data);
        }
      } catch (e) {
        console.error("Failed to parse JSON:", e);
      }
    }
  };

  xhttp.open("GET", "./assets/php/get_all_branches.php", true);
  xhttp.send();

  const xxhttp = new XMLHttpRequest();
  xxhttp.open("GET", "./assets/php/get-employee.php?employee_id=" + id, true);
  xxhttp.send();
  xxhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      const employee = JSON.parse(this.responseText);

      Swal.fire({
        title: "Edit Employee",
        confirmButtonText: 'Edit Employee',
        confirmButtonColor: '#047857',
        html: `
        <div class="formbold-main-wrapper mt-4 ">
                      <div class="formbold-form-wrapper">
                          <form action="https://formbold.com/s/FORM_ID" method="POST" class="  text-start"
                              id="UserForm_Employee">
                              <div class="formbold-input-flex">
                                 <div class="formbold-mb-3">
                                  <label for="Employee_Edit_branch" class="formbold-form-label">Branch</label>
                                  <select class="formbold-form-input" name="Branch" id="Employee_Edit_branch">
                                    <option value="${employee.branch_id}">Select branch</option>
                                  </select>
                                </div>

                                  <div class="formbold-mb-3">
                                      <label for="Employee_Edit_positions"
                                          class="formbold-form-label">positions</label>
                                      <select class="formbold-form-input" name="positions"
                                          id="Employee_Edit_positions">
                                          <option value="">select positions </option>
                                          <option value="Employee" ${employee.position === 'Employee' ? 'selected' : ''}>Employee</option>
                                          <option value="Human Resources" ${employee.position === 'Human Resources' ? 'selected' : ''}>Human Resources</option>
                                          <option value="Branch Manager" ${employee.position === 'Branch Manager' ? 'selected' : ''}>Branch Manager</option>
                                          <option value="Warehouse Manager" ${employee.position === 'Warehouse Manager' ? 'selected' : ''}>Warehouse Manager</option>
                                          <option value="Accountant" ${employee.position === 'Accountant' ? 'selected' : ''}>Accountant</option>
                                          <option value="Head of Product" ${employee.position === 'Head of Product' ? 'selected' : ''}>Head of Product</option>
                                          <option value="Product Manager" ${employee.position === 'Product Manager' ? 'selected' : ''}>Product Manager</option>
                                          <option value="Customer Service" ${employee.position === 'Customer Service' ? 'selected' : ''}>Customer Service</option>
                                          <option value="IT" ${employee.position === 'IT' ? 'selected' : ''}>IT</option>
                                      </select>
                                  </div>
                              </div>

                              <div class="formbold-input-flex">
                                  <div class="formbold-mb-3">
                                      <label for="Employee_Edit_salary" class="formbold-form-label">Salary</label>
                                      <input type="number" name="salary" id="Employee_Edit_salary"
                                          placeholder="Enter salary" class="formbold-form-input" value="${employee.salary}" />
                                      <p class="Salary_Error text-sm ErrorClear text-danger allertview"></p>
                                  </div>
                                  <div class="formbold-mb-3">
                                      <label for="Employee_hire_date" class="formbold-form-label">Hire
                                          Date</label>
                                      <input type="date" name="hire_date" id="Employee_Edit_hire_date"
                                          class="formbold-form-input" value="${employee.hire_date}"/>
                                  </div>

                              </div>
                              <div class="formbold-checkbox-wrapper">
                                <label for="Manger" class="formbold-checkbox-label">
                                  <div class="formbold-relative">
                                    <input
                                      type="checkbox"
                                      id="Manger"
                                      class="formbold-input-checkbox" ${employee.manager_id !== null ? 'checked' : ''}
                                    />
                                    <div class="formbold-checkbox-inner">
                                      <span class="formbold-opacity-0">
                                        <svg
                                          width="11"
                                          height="8"
                                          viewBox="0 0 11 8"
                                          fill="none"
                                          class="formbold-stroke-current"
                                        >
                                          <path
                                            d="M10.0915 0.951972L10.0867 0.946075L10.0813 0.940568C9.90076 0.753564 9.61034 0.753146 9.42927 0.939309L4.16201 6.22962L1.58507 3.63469C1.40401 3.44841 1.11351 3.44879 0.932892 3.63584C0.755703 3.81933 0.755703 4.10875 0.932892 4.29224L0.932878 4.29225L0.934851 4.29424L3.58046 6.95832C3.73676 7.11955 3.94983 7.2 4.1473 7.2C4.36196 7.2 4.55963 7.11773 4.71406 6.9584L10.0468 1.60234C10.2436 1.4199 10.2421 1.1339 10.0915 0.951972ZM4.2327 6.30081L4.2317 6.2998C4.23206 6.30015 4.23237 6.30049 4.23269 6.30082L4.2327 6.30081Z"
                                            stroke-width="1"
                                          ></path>
                                        </svg>
                                      </span>
                                    </div>
                                  </div>
                                  Is manager
            
                                </label>
                              </div>
                          </form>
                      </div>
                  </div>
      `,
        focusConfirm: false,
        preConfirm: () => {
          const branch_id = document.getElementById("Employee_Edit_branch").value;
          const position = document.getElementById("Employee_Edit_positions").value;
          const salary = document.getElementById("Employee_Edit_salary").value;
          let isValid = true;

          const salaryPattern = /^\d+(\.\d{1,2})?$/;
          const Salary_error = document.querySelector('.Salary_Error');
          if (!salaryPattern.test(salary) || salary <= 0) {
            Salary_error.classList.remove("allertview");
            Salary_error.innerHTML = "Please enter a valid salary.";
            document.getElementById("Employee_Edit_salary").classList.add("is-invalid");
            isValid = false;
            return false
          } else {
            Salary_error.innerHTML = " ";
            document.getElementById("Employee_Edit_salary").classList.remove("is-invalid");
            Salary_error.classList.add("allertview");
          }

          if (branch_id === "") {
            document.getElementById("Employee_Edit_branch").classList.add("is-invalid");
            isValid = false;
            return false
          } else {
            document.getElementById("Employee_Edit_branch").classList.remove("is-invalid");
          }
          if (position === "") {
            document.getElementById("Employee_Edit_positions").classList.add("is-invalid");
            isValid = false;
            return false
          }
          else {
            document.getElementById("Employee_Edit_positions").classList.remove("is-invalid");
          }
          if (isValid) {
            return EditEmployee(id);
          } else {
            Swal.fire({
              position: 'bottom-end',
              title: ' &#10006; Please fill in all required fields correctly.',
              showConfirmButton: false,
              timer: 1500,
              width: '25%',
              background: '#800000',
              didOpen: () => {
                const swalTitle = Swal.getTitle();
                if (swalTitle) swalTitle.style.color = '#fff';
                swalTitle.style.fontSize = '15px'; // Adjust font size
              }
            });
            return false; // Prevent form submission
          }

        }

      });
    }
  }

}

function EditEmployee(employee_id) {

  const employeeData = {
    emplloyee_id: employee_id,
    branch_id: document.getElementById("Employee_Edit_branch").value,
    manager_id: null,
    hire_date: document.getElementById("Employee_Edit_hire_date").value,
    position: document.getElementById("Employee_Edit_positions").value,
    salary: parseFloat(document.getElementById("Employee_Edit_salary").value)

  };

  const isManager = document.getElementById("Manger").checked;

  if (isManager) {
    employeeData.manager_id = employee_id; // Set manager_id to the employee's own ID if they are a manager
  }

  const xhttp = new XMLHttpRequest();
  xhttp.open("POST", "./assets/php/update-employee.php", true);
  xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");

  xhttp.onreadystatechange = function () {
    if (this.readyState === 4) {
      try {
        const response = JSON.parse(this.responseText);
        if (this.status === 200 && response.message) {
          // Successfully added employee

          Swal.fire({
            position: 'bottom-end',
            title: '✅Employee update successfully',
            showConfirmButton: false,
            timer: 1500,
            width: '25%',
            background: '#047857',
            didOpen: () => {
              const swalTitle = Swal.getTitle();
              if (swalTitle) swalTitle.style.color = '#fff';
              swalTitle.style.fontSize = '15px'; // Adjust font size
            }
          });
          loadEmployeeTable();
          loadWatingEmployeeTable();
          overview();
        } else {
          Swal.fire({
            position: 'bottom-end',
            title: `❌Failed to edit employee: ${response.error || 'Unknown error'}`,
            showConfirmButton: false,
            timer: 1500,
            width: '25%',
            background: '#800000',
            didOpen: () => {
              const swalTitle = Swal.getTitle();
              if (swalTitle) swalTitle.style.color = '#fff';
              swalTitle.style.fontSize = '15px'; // Adjust font size
            }
          });
        }
      } catch (e) {
        Swal.fire({
          position: 'bottom-end',
          title: '⚠️ Unexpected response from server.',
          showConfirmButton: false,
          timer: 1500,
          width: '25%',
          background: '#b22222',
          didOpen: () => {
            const swalTitle = Swal.getTitle();
            if (swalTitle) swalTitle.style.color = '#fff';
            swalTitle.style.fontSize = '15px'; // Adjust font size
          }
        });
      }
    }
  };

  xhttp.send(JSON.stringify(employeeData));
}
function filter_Employee_Table(query) {
  query = query.toLowerCase();
  filtered_employees_tableData = Employees_tableData.filter((user) => {
    return (
      user.employee_id.toString().includes(query) ||
      user.first_name.toLowerCase().includes(query) ||
      user.last_name.toLowerCase().includes(query) ||
      user.position.toLowerCase().includes(query) ||
      user.branch_name.toLowerCase().includes(query) ||
      user.branch_phone.toString().includes(query)
    );
  });

  currentPage = 1; // Reset to first page
  render_Employees_Table(currentPage);
  render_Employees_Pagination(filteredData.length);
}
function employeeDelete(id) {
  // Declare outside to make it accessible globally or in outer scope
  const xxhttp = new XMLHttpRequest();
  xxhttp.onreadystatechange = function () {
    if (this.readyState === 4) {
      if (this.status === 200) {
        const employeedata = JSON.parse(this.responseText);

        if (employeedata.user_id == id && employeedata.position != "IT") {
          Swal.fire({
            position: 'bottom-end',
            title: ' &#10006; You cannot delete your own account.',
            showConfirmButton: false,
            timer: 1500,
            width: '25%',
            background: '#800000',
            didOpen: () => {
              const swalTitle = Swal.getTitle();
              if (swalTitle) swalTitle.style.color = '#fff';
              swalTitle.style.fontSize = '15px'; // Adjust font size
            }
          });
        }
        else {
          Swal.fire({
            title: "Are you sure?",
            text: "This action cannot be undone!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonText: "Yes, delete it!",
            didOpen: () => {
              const confirmButton = Swal.getConfirmButton();
              if (confirmButton) confirmButton.style.backgroundColor = '#047857';
            }
          }).then((result) => {
            if (result.isConfirmed) {
              const xhttp = new XMLHttpRequest();
              xhttp.open("DELETE", "./assets/php/delete-employee.php", true);
              xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
              xhttp.send(JSON.stringify({ account_id: id }));
              xhttp.onreadystatechange = function () {
                if (this.readyState == 4) {
                  const res = JSON.parse(this.responseText);
                  if (this.status === 200 && !res.error) {
                    Swal.fire({
                      position: 'bottom-end',
                      title: ' &#10004;User deleted successfully',
                      showConfirmButton: false,
                      timer: 1500,
                      width: '25%',
                      background: '#047857',
                      didOpen: () => {
                        const swalTitle = Swal.getTitle();
                        if (swalTitle) swalTitle.style.color = '#fff';
                        swalTitle.style.fontSize = '15px'; // Adjust font size
                      }
                    });
                    loadEmployeeTable();
                    loadWatingEmployeeTable();
                    overview();
                  } else {
                    Swal.fire({
                      position: 'bottom-end',
                      title: ' &#10006;Failed to delete employee',
                      showConfirmButton: false,
                      timer: 1500,
                      width: '25%',
                      background: '#800000',
                      didOpen: () => {
                        const swalTitle = Swal.getTitle();
                        if (swalTitle) swalTitle.style.color = '#fff';
                        swalTitle.style.fontSize = '15px'; // Adjust font size
                      }
                    });
                  }
                }
              };
            }
          });
        }
      }
      else {
        Swal.fire({
          position: 'bottom-end',
          title: ' &#10006;Failed to fetch user data',
          showConfirmButton: false,
          timer: 1500,
          background: '#800000',
          didOpen: () => {
            const swalTitle = Swal.getTitle();
            if (swalTitle) swalTitle.style.color = '#fff';
          }
        });
      }
    }
  };
  xxhttp.open("GET", "/DataBase/assets/php/session.php", true);
  xxhttp.send();

}

loadEmployeeTable();

loadWatingEmployeeTable();

loadTable();
