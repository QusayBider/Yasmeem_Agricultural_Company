
let session_flag = false;
function showthepage() {
  const userDropdownButton1 = document.getElementById("userDropdownButton1");
  const myCartDropdownButton1 = document.getElementById("myCartDropdownButton1");
  const card_dropdown = document.getElementById("myCartDropdown1");
  const user_dropdown = document.getElementById("userDropdown1");
  const Dashboard=document.getElementById("Dashboard");
  const Account_Name=document.getElementById("Account_Name");
  const card_account_button = [userDropdownButton1, myCartDropdownButton1];
  const card_user_dropdown = [user_dropdown, card_dropdown];
  const xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function () {
    if (this.readyState === 4) {
      if (this.status === 200) {
        const data = JSON.parse(this.responseText);

        card_user_dropdown.forEach(button => {
          button.classList.remove("Hidden");
        });
        
        Account_Name.textContent=data.user_name;

        session_flag = true;
        if(data.account_type === "Employee" ){
          Dashboard.classList.remove("Hidden");
        }
      }
      else {
        card_account_button.forEach(button => {
          button.addEventListener("click", function () {
            window.location.href = "./login_register.html";
          });
        });

        session_flag = false;
      }
    }
  };

  xhttp.open("GET", "/DataBase/assets/php/session.php", true);
  xhttp.send();
}
showthepage();
