var Employee_position;
fetch('/DataBase/assets/php/session.php',)
  .then(response => {
    if (!response.ok) {
      // Session is expired or not started, redirect to index
      window.location.href = '/DataBase/index.html';
      throw new Error("Redirecting to index...");
    }
    return response.json();
  })
  .then(data => {
    if (data.account_type !== 'Employee') {
      window.location.href = '/DataBase/index.html';
    } else {
      Employee_position = data.position;

      if (data.position === "IT" || data.position === "Human Resources") {
        document.querySelectorAll('[name="General_Overview"]').forEach(elem => {
          elem.classList.remove("hidden");
        });
        document.querySelectorAll('[name="Financial_Accounts"]').forEach(elem => {
          elem.classList.remove("hidden");
        });
      }
      if (
        data.position === "IT" ||
        data.position === "Human Resources" ||
        data.position === "Accountant"
      ) {
        document.querySelectorAll('[name="Financial_Overview"]').forEach(elem => {
          elem.classList.remove("hidden");
        });

      }
      if (data.position === "Employee") {
        document.getElementById("System_OverView").classList.add("hidden");
      }
      if (data.position === "IT" ||
        data.position === "Human Resources" ||
        data.position === "Branch Manager") {

        document.querySelectorAll('[name="branch_process"]').forEach(branch => {
          branch.classList.remove("hidden");
        })
        document.getElementById("products_in_branch_link").addEventListener("click", function (e) {
          e.preventDefault();
          products_in_branch(data.user_id);
        });
        document.getElementById("add_product_Branch_link").addEventListener("click", function (e) {
          e.preventDefault();
          show_product_branch(data.user_id);
        });
      }
      if (data.position === "Product Manager") {
        document.getElementById("add_product_Branch_link").classList.remove("hidden");
        document.getElementById("Branch_text").classList.remove("hidden");
        document.getElementById("product_in_branch").classList.remove("hidden");
        document.getElementById("products_in_branch_link").addEventListener("click", function (e) {
          e.preventDefault();
          products_in_branch(data.user_id);
        });
        document.getElementById("add_product_Branch_link").addEventListener("click", function (e) {
          e.preventDefault();
          show_product_branch(data.user_id);
        });
      }
      overview();

    }
  })

document.addEventListener("DOMContentLoaded", function (event) {
});


let current_branch_Page = 1;
const branch_rows_PerPage = 12;
let BranchData = [];
let Branch_tableData = [];
let filteredBranchData = [];

function overview() {
  const xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function () {
    if (this.readyState === 4 && this.status === 200) {
      try {
        const data = JSON.parse(this.responseText);

        const overview_Data = data.statistics;
        salary_chart(overview_Data.min_salary, overview_Data.avg_salary, overview_Data.max_salary);
      } catch (e) {
        // document.getElementById("output").textContent = "Error parsing data.";
      }
    }
  };

  // Replace 'stats.php' with the actual name/path of your PHP script
  xhttp.open("GET", "./assets/php/overview-data.php", true);
  xhttp.send();
}


function salary_chart(Minimum, Average, Max) {
  var colors = ['#33b2df', '#546E7A', '#d4526e'];
  var options = {
    series: [{
      data: [Minimum, Average, Max]
    }],
    chart: {
      height: 350,
      type: 'bar',
      events: {
        click: function (chart, w, e) {
          // console.log(chart, w, e)
        }
      }
    },
    colors: colors,
    plotOptions: {
      bar: {
        columnWidth: '45%',
        distributed: true,
      }
    },
    dataLabels: {
      enabled: false
    },
    legend: {
      show: false
    },
    xaxis: {
      categories: [
        'Minimum',
        'Average',
        'Max'
      ],
      labels: {
        style: {
          colors: colors,
          fontSize: '12px'
        }
      }
    }
  };

  var chart = new ApexCharts(document.querySelector("#salary_chart"), options);
  chart.render();
}

document.getElementById("Add_branch_btn").addEventListener("click", function (e) {
  e.preventDefault();
  add_branch();
});
document.getElementById("edit_Branch").addEventListener("click", function (e) {
  e.preventDefault();
  load_branch_Table();
});


function add_branch() {
  let ValidFlag = true;
  const branch_name = document.getElementById("branch_name");
  const branch_phone = document.getElementById("branch_phone");
  const branch_address = document.getElementById("branch_address");
  const branch_city = document.getElementById("branch_city");
  const branch_street = document.getElementById("branch_street");

  //varible for alert in css 
  const Name_error_singUp = document.querySelector('.Text_branch_error');
  const Phone_error_sinUp = document.querySelector('.Phone_branch_error');

  // Validate required fields

  const namePattern = /^[A-Za-z][A-Za-z\s]{0,29}$/;   // Starts with a letter, allows letters and spaces
  const phonePattern = /^\d{10}$/;  // Exactly 10 digits

  if (!namePattern.test(branch_name.value)) {
    Name_error_singUp.classList.remove("allertview");
    Name_error_singUp.innerHTML = "Text,Name must start with a letter.";
    branch_name.classList.add("is-invalid");
    ValidFlag = false;
  } else {
    Name_error_singUp.innerHTML = " ";
    branch_name.classList.remove("is-invalid");
    Name_error_singUp.classList.add("allertview");
  }

  if (!namePattern.test(branch_address.value)) {
    Name_error_singUp.classList.remove("allertview");
    Name_error_singUp.innerHTML = "Text,Name must start with a letter.";
    branch_address.classList.add("is-invalid");
    ValidFlag = false;
  } else {
    Name_error_singUp.innerHTML = " ";
    branch_address.classList.remove("is-invalid");
    Name_error_singUp.classList.add("allertview");
  }

  if (!namePattern.test(branch_city.value)) {
    Name_error_singUp.classList.remove("allertview");
    Name_error_singUp.innerHTML = "Text,Name must start with a letter.";
    branch_city.classList.add("is-invalid");
    ValidFlag = false;
  } else {
    Name_error_singUp.innerHTML = " ";
    branch_city.classList.remove("is-invalid");
    Name_error_singUp.classList.add("allertview");
  }

  if (!phonePattern.test(branch_phone.value)) {
    Phone_error_sinUp.classList.remove("allertview");
    Phone_error_sinUp.innerHTML = "Phone number must be exactly 10 digits.";
    branch_phone.classList.add("is-invalid");
    ValidFlag = false;
  } else {
    Phone_error_sinUp.innerHTML = " ";
    branch_phone.classList.remove("is-invalid");
    Phone_error_sinUp.classList.add("allertview");
  }

  if (ValidFlag) {


    const data = {
      name: branch_name.value.trim(),
      phone_number: branch_phone.value.trim(),
      address: branch_address.value.trim(),
      city: branch_city.value.trim(),
      street: branch_street.value.trim(),
    };


    const xhttp = new XMLHttpRequest();
    xhttp.open("POST", "./assets/php/create-branch.php", true);
    xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    xhttp.send(JSON.stringify(data));
    xhttp.onreadystatechange = function () {
      if (this.readyState == 4) {
        try {
          const objects = JSON.parse(this.responseText);
          if (this.status == 200 && !objects.error) {
            Swal.fire({
              position: 'bottom-end',
              title: ' &#10004;	Create branch success',
              showConfirmButton: false,
              timer: 1500,
              width: '25%',
              background: '#047857',
              didOpen: () => {
                const swalTitle = Swal.getTitle();
                if (swalTitle) swalTitle.style.color = '#fff';
                swalTitle.style.fontSize = '15px';
              }
            });

            overview();
            document.getElementById("branchForm_Create").reset();
          }
          else {
            Swal.fire({
              position: 'bottom-end',
              title: ' &#10006;	Create failed',
              showConfirmButton: false,
              timer: 1500,
              width: '25%',
              background: '#800000',
              didOpen: () => {
                const swalTitle = Swal.getTitle();
                if (swalTitle) swalTitle.style.color = '#fff';
                swalTitle.style.fontSize = '15px';
              }
            });
          }
        } catch (e) {
          Swal.fire({
            position: 'bottom-end',
            title: ' &#10006;	Server error',
            showConfirmButton: false,
            timer: 1500,
            width: '25%',
            background: '#800000',
            didOpen: () => {
              const swalTitle = Swal.getTitle();
              if (swalTitle) swalTitle.style.color = '#fff';
              swalTitle.style.fontSize = '15px';
            }
          });
        }
      }
    };

  }

}


function load_branch_Table() {
  const xhttp = new XMLHttpRequest();
  xhttp.open("GET", "./assets/php/get_all_branches.php", true);
  xhttp.send();
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      BranchData = JSON.parse(this.responseText);
      filteredBranchData = [...BranchData]; // Start with full data

      render_branch_Table(current_branch_Page);
      render_branch_Pagination(filteredBranchData.length);
    }
  };
}

// Render Table
function render_branch_Table(page) {
  current_branch_Page = page;
  const start = (page - 1) * branch_rows_PerPage;
  const end = start + branch_rows_PerPage;
  const paginatedItems = filteredBranchData.slice(start, end);

  let trHTML = "";

  if (paginatedItems.length === 0) {
    trHTML += `<tr><td colspan="12" class="text-center">No branches founds</td></tr>`;
  } else {

    for (let object of paginatedItems) {
      trHTML += `
     <div  class=" col-12 col-sm-6 col-md-4 col-lg-3 account_card">
       <div class="our-team">
       <div class="picture">
        <img class="img-fluid" src="./assets/img/branch.png"  alt="branch logo">
       </div>
       <div class="team-content ">
        <h3 class="name">${object["name"]}</h3>
        <h5 class="accountType">${object["address"]} - ${object["city"]} - ${object["street"]} </h5>
        <span class="account_id_card"><i class="fa-solid fa-thumbtack" style="color: #016f54;"></i> ${object["branch_id"]}</span>

       </div>
       <ul class="buttonEditDelete">
        <button onclick="showBranchEditBox(${object["branch_id"]})" title="Edit Branch">
          <i class="fa-solid fa-user-pen"></i>
        </button>
        <button onclick="BranchDelete(${object["branch_id"]})" title="Delete Branch" >
          <i class="fa-solid fa-user-xmark"></i>
        </button>
       </ul>
      </div>                          
    </div>  
    `;
    }

  }

  document.getElementById("Dashboard_Branch").innerHTML = trHTML;
}

function showBranchEditBox(id) {
  const xhttp = new XMLHttpRequest();
  xhttp.open("GET", "./assets/php/get-branch-by-id.php?id=" + id, true);
  xhttp.send();
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      const branch = JSON.parse(this.responseText).branch;

      Swal.fire({
        title: "Edit branch",
        showConfirmButton: false,
        html: `
              <div class="formbold-form-wrapper  ">
                <form action="https://formbold.com/s/FORM_ID" class="mt-4 bg-transparent text-start"  method="POST" id="branchForm_Update">
                    <div class="formbold-input-flex">
                     <input type="text" name="Branch ID" id="edit_branch_id"
                                placeholder="Branch ID" value="${branch.branch_id}"
                                class=" hidden formbold-form-input formbold-mb-3" />

                        <div class="formbold">
                            <label for="branch_name" class="formbold-form-label"> name </label>
                            <input type="text" name="Branch name" id="edit_branch_name"
                                placeholder="Branch name" value="${branch.name}"
                                class="formbold-form-input formbold-mb-3" />
                        </div>

                        <div>
                            <label for="branch_address" class="formbold-form-label"> Address
                            </label>
                            <input type="text" name="Branch address" id="edit_branch_address"
                                placeholder="ex: more information country ....." value="${branch.address}" class="formbold-form-input" />
                        </div>
                    </div>


                    <div class="formbold-input-flex mb-0">
                        <div class="formbold">
                            <label for="branch_city" class="formbold-form-label"> City </label>
                            <input type="text" name="Branch city" id="edit_branch_city"
                                placeholder="ex: Ramallah" value="${branch.city}"
                                class="formbold-form-input formbold-mb-3" />
                        </div>

                        <div>
                            <label for="branch_street" class="formbold-form-label"> Street </label>
                            <input type="text" name="Branch street" id="edit_branch_street" value="${branch.street}"
                                placeholder="ex: Jerusalem Street " class="formbold-form-input" />
                        </div>
                        
                    </div>
                    <p class="edit_Text_branch_error ErrorClear text-danger allertview text-sm "></p>
                    <div class="formbold-mb-3 formbold-input-wrapp mt-2">
                        <label for="branch_phone" class="formbold-form-label"> Phone </label>
                        <input type="text" id="edit_branch_phone" value="${branch.phone_number}"
                            placeholder="Phone number 05...." class="formbold-form-input" />
                        <p class=" edit_Phone_branch_error ErrorClear text-danger allertview text-sm"></p>
                    </div>
                </form>

                <button type="submit" id="edit_branch_btn" onclick="BranchEdit()"
                    class="btn btn-primary button_setting m-2 mb-4" >update branch</button>
             </div>    
      `,
        focusConfirm: false,


      });
    }
  };
}


function BranchEdit() {
  let ValidFlag = true;
  const branch_id = document.getElementById("edit_branch_id");
  const branch_name = document.getElementById("edit_branch_name");
  const branch_phone = document.getElementById("edit_branch_phone");
  const branch_address = document.getElementById("edit_branch_address");
  const branch_city = document.getElementById("edit_branch_city");
  const branch_street = document.getElementById("edit_branch_street");

  //varible for alert in css 
  const Name_error_branch = document.querySelector('.edit_Text_branch_error');
  const Phone_error_branch = document.querySelector('.edit_Phone_branch_error');

  // Validate required fields

  const namePattern = /^[A-Za-z].*/;
  const phonePattern = /^\d{10}$/;  // Exactly 10 digits


  if (!namePattern.test(branch_name.value)) {
    Name_error_branch.classList.remove("allertview");
    Name_error_branch.innerHTML = "Text,Name must start with a letter.";
    branch_name.classList.add("is-invalid");
    ValidFlag = false;
  } else {
    branch_name.classList.remove("is-invalid");
  }

  if (!namePattern.test(branch_address.value)) {
    Name_error_branch.classList.remove("allertview");
    Name_error_branch.innerHTML = "Text,Name must start with a letter.";
    branch_address.classList.add("is-invalid");
    ValidFlag = false;
  } else {

    branch_address.classList.remove("is-invalid");

  }

  if (!namePattern.test(branch_city.value)) {
    Name_error_branch.classList.remove("allertview");
    Name_error_branch.innerHTML = "Text,Name must start with a letter.";
    branch_city.classList.add("is-invalid");
    ValidFlag = false;
  } else {
    branch_city.classList.remove("is-invalid");
  }

  if (!phonePattern.test(branch_phone.value)) {
    Phone_error_branch.classList.remove("allertview");
    Phone_error_branch.innerHTML = "Phone number must be exactly 10 digits.";
    branch_phone.classList.add("is-invalid");
    ValidFlag = false;
  } else {
    Phone_error_branch.innerHTML = " ";
    branch_phone.classList.remove("is-invalid");
    Phone_error_branch.classList.add("allertview");
  }

  if (ValidFlag) {

    Name_error_branch.classList.add("allertview");
    Name_error_branch.innerHTML = " ";

    const data = {
      branch_id: branch_id.value,
      name: branch_name.value.trim(),
      phone_number: branch_phone.value.trim(),
      address: branch_address.value.trim(),
      city: branch_city.value.trim(),
      street: branch_street.value.trim(),
    };


    const xhttp = new XMLHttpRequest();
    xhttp.open("POST", "./assets/php/update-branch.php", true);
    xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    xhttp.send(JSON.stringify(data));
    xhttp.onreadystatechange = function () {
      if (this.readyState == 4) {
        try {
          const objects = JSON.parse(this.responseText);
          if (this.status == 200 && !objects.error) {
            Swal.fire({
              position: 'bottom-end',
              title: ' &#10004;	Update branch success',
              showConfirmButton: false,
              timer: 1500,
              width: '25%',
              background: '#047857',
              didOpen: () => {
                const swalTitle = Swal.getTitle();
                if (swalTitle) swalTitle.style.color = '#fff';
                swalTitle.style.fontSize = '15px';
              }
            });

            overview();
            load_branch_Table();
          }
          else {
            Swal.fire({
              position: 'bottom-end',
              title: ' &#10006;	Update failed',
              showConfirmButton: false,
              timer: 1500,
              width: '25%',
              background: '#800000',
              didOpen: () => {
                const swalTitle = Swal.getTitle();
                if (swalTitle) swalTitle.style.color = '#fff';
                swalTitle.style.fontSize = '15px';
              }
            });
          }
        } catch (e) {
          Swal.fire({
            position: 'bottom-end',
            title: ' &#10006;	Server error',
            showConfirmButton: false,
            timer: 1500,
            width: '25%',
            background: '#800000',
            didOpen: () => {
              const swalTitle = Swal.getTitle();
              if (swalTitle) swalTitle.style.color = '#fff';
              swalTitle.style.fontSize = '15px';
            }
          });
        }
      }
    };

  }
}

function BranchDelete(id) {
  Swal.fire({
    title: "Are you sure?",
    text: "This action cannot be undone!",
    icon: "warning",
    showCancelButton: true,
    confirmButtonText: "Yes, delete it!",
    didOpen: () => {
      const confirmButton = Swal.getConfirmButton();
      if (confirmButton) confirmButton.style.backgroundColor = '#047857';
    }
  }).then((result) => {
    if (result.isConfirmed) {
      const xhttp = new XMLHttpRequest();
      xhttp.open("POST", "./assets/php/delete-branch.php", true); // Use POST if PHP expects it
      xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");

      xhttp.onreadystatechange = function () {
        if (this.readyState === 4) {
          const res = JSON.parse(this.responseText);

          if (this.status === 200 && !res.error) {
            Swal.fire({
              position: 'bottom-end',
              title: '✔ Branch deleted successfully',
              showConfirmButton: false,
              timer: 1500,
              width: '25%',
              background: '#047857',
              didOpen: () => {
                const swalTitle = Swal.getTitle();
                if (swalTitle) {
                  swalTitle.style.color = '#fff';
                  swalTitle.style.fontSize = '15px';
                }
              }
            });
            load_branch_Table();
            overview();
            loadEmployeeTable();
          } else {
            Swal.fire({
              position: 'bottom-end',
              title: '✘ Failed to delete branch',
              showConfirmButton: false,
              timer: 1500,
              width: '25%',
              background: '#800000',
              didOpen: () => {
                const swalTitle = Swal.getTitle();
                if (swalTitle) {
                  swalTitle.style.color = '#fff';
                  swalTitle.style.fontSize = '15px';
                }
              }
            });
          }
        }
      };

      xhttp.send(JSON.stringify({ id: id }));
    }
  });
}

// Render Pagination
function render_branch_Pagination(totalItems) {
  const totalPages = Math.ceil(totalItems / branch_rows_PerPage);
  let paginationHTML = "";

  paginationHTML += `<li class="page-item ${current_branch_Page === 1 ? "disabled" : ""}">
      <a class="page-link" href="#" onclick="change_branch_Page(${current_branch_Page - 1})">Previous</a>
    </li>`;

  for (let i = 1; i <= totalPages; i++) {
    paginationHTML += `<li class="page-item ${current_branch_Page === i ? "active" : ""}">
      <a class="page-link" href="#" onclick="change_branch_Page(${i})">${i}</a>
    </li>`;
  }

  paginationHTML += `<li class="page-item color-greey ${current_branch_Page === totalPages ? "disabled" : ""}">
      <a class="page-link" href="#" onclick="change_branch_Page(${current_branch_Page + 1})">Next</a>
    </li>`;

  document.getElementById("pagination_branch").innerHTML = paginationHTML;
}

// Page Change
function change_branch_Page(page) {
  const totalPages = Math.ceil(filteredBranchData.length / branch_rows_PerPage);
  if (page >= 1 && page <= totalPages) {
    render_branch_Table(page);
    render_branch_Pagination(filteredBranchData.length);
  }
}

// Filter/Search
function filter_brannch_Table(query) {
  query = query.toLowerCase();
  filteredBranchData = BranchData.filter((branch) => {
    return (
      branch.branch_id.toString().includes(query) ||
      branch.name.toLowerCase().includes(query) ||
      branch.address.toLowerCase().includes(query) ||
      branch.city.toLowerCase().includes(query) ||
      branch.phone_number.toLowerCase().includes(query) ||
      branch.street.toLowerCase().includes(query)
    );
  });

  current_branch_Page = 1; // Reset to first page
  render_branch_Table(current_branch_Page);
  render_branch_Pagination(filteredBranchData.length);
}

async function show_product_branch(account_id) {
  try {
    let branch = null;
    let allowBranchSelect = false;

    // Check position
    if (Employee_position === "Human Resources" || Employee_position === "IT") {
      allowBranchSelect = true;

      const allBranches = await new Promise((resolve, reject) => {
        const xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
          if (this.readyState === 4) {
            if (this.status === 200) {
              try {
                const data = JSON.parse(this.responseText);
                resolve(data);
              } catch (e) {
                reject(new Error("Invalid JSON response"));
              }
            } else {
              reject(new Error("Failed to fetch all branches"));
            }
          }
        };
        xhttp.open("GET", "./assets/php/get_all_branches.php", true);
        xhttp.send();
      });
      branch = { allBranches };

    } else {
      // Fetch branch assigned to employee
      const branchRes = await fetch(`./assets/php/get-branch-by-account_id.php?account_id=${account_id}`);
      if (!branchRes.ok) throw new Error("Failed to fetch branch data");
      branch = await branchRes.json();
    }

    // Show popup
    await Swal.fire({
      title: "Add product",
      showConfirmButton: false,
      html: `
        <div class="formbold-main-wrapper mt-4">
          <div class="formbold-form-wrapper">
            <form class="text-start" id="add_product_to_branch">

              ${allowBranchSelect ? `
                <div class="formbold-mb-3">
                  <label class="formbold-form-label">Select Branch</label>
                  <select id="branch_id" class="formbold-form-input">
                    ${branch.allBranches.map(b => `<option value="${b.branch_id}">${b.name}</option>`).join('')}
                  </select>
                </div>
              ` : `
                <input type="text" id="branch_id" class="hidden formbold-form-input" value="${branch.branch_id}" disabled />
                <div class="formbold-mb-3">
                  <label class="formbold-form-label">Branch</label>
                  <input type="text" id="branch_name" class="formbold-form-input" value="${branch.branch_name}" readonly />
                </div>
              `}

              <div class="formbold-input-flex">
                <div class="formbold-mb-3">
                  <label class="formbold-form-label">Categories</label>
                  <select class="formbold-form-input" id="all_Categories"></select>
                </div>
                <div class="formbold-mb-3">
                  <label class="formbold-form-label">Products</label>
                  <select class="formbold-form-input" id="all_Products"></select>
                </div>
              </div>

              <div class="formbold-mb-3">
                <label class="formbold-form-label">Quantity</label>
                <input type="number" class="formbold-form-input" id="total_stock_quantity" placeholder="The quantity more than one product" min="1" />
              </div>

              <p class="add_product_branch_error ErrorClear text-danger allertview text-sm"></p>
            </form>
            <button type="submit" id="add_product_to_branch_btn" onclick="add_product_branch()" class="btn btn-primary button_setting m-2 mb-4">Add product to branch</button>
          </div>
        </div>
      `,
      didOpen: async () => {
        const categorySelect = document.getElementById("all_Categories");
        const productSelect = document.getElementById("all_Products");

        // Fetch category-product data
        const prodRes = await fetch("./assets/php/get-product-group-category.php");
        if (!prodRes.ok) throw new Error("Failed to fetch products");
        const data = await prodRes.json();

        // Populate category options
        data.forEach(cat => {
          const opt = document.createElement("option");
          opt.value = cat.category_id;
          opt.text = cat.category_name;
          categorySelect.appendChild(opt);
        });

        // Update product list when category changes
        categorySelect.addEventListener("change", () => {
          const selId = categorySelect.value;
          productSelect.innerHTML = "";
          const selCat = data.find(c => c.category_id == selId);
          if (selCat && selCat.products.length > 0) {
            selCat.products.forEach(p => {
              const opt = document.createElement("option");
              opt.value = p.product_id;
              opt.text = p.product_name;
              productSelect.appendChild(opt);
            });
          } else {
            const opt = document.createElement("option");
            opt.text = "No products available";
            productSelect.appendChild(opt);
          }
        });

        // Trigger initial category load
        if (categorySelect.options.length > 0) {
          categorySelect.selectedIndex = 0;
          categorySelect.dispatchEvent(new Event("change"));
        }
      }
    });

  } catch (err) {
    console.error(err);
    Swal.fire("Error", err.message, "error");
  }
}


async function add_product_branch() {
  const branch_id = document.getElementById("branch_id").value;
  const product_id = document.getElementById("all_Products").value;
  const category_id = document.getElementById("all_Categories").value;
  const quantity = document.getElementById("total_stock_quantity");
  const error_Text = document.querySelector(".add_product_branch_error");

  let isValid = true;

  // Validate quantity
  if (quantity.value < 1) {
    quantity.classList.add("is-invalid");
    error_Text.classList.remove("allertview");
    error_Text.innerHTML = "The quantity must be at least one product.";
    isValid = false;
  } else {
    quantity.classList.remove("is-invalid");
    error_Text.classList.add("allertview");
    error_Text.innerHTML = "";
  }

  // Validate no product
  if (product_id === "No products available") {
    error_Text.classList.remove("allertview");
    error_Text.innerHTML = "There is no product to add.";
    isValid = false;
  }

  // Validate required fields
  if (!branch_id || !category_id || !product_id || quantity.value === "") {
    error_Text.classList.remove("allertview");
    error_Text.innerHTML = "Make sure to fill all boxes.";
    isValid = false;
  }

  if (!isValid) return;

  const data = {
    branch_id: branch_id,
    product_id: product_id,
    total_stock_quantity: quantity.value,
    product_condition: "Product request"
  };

  try {
    const response = await fetch("./assets/php/add-product-to-branch.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(data)
    });

    const result = await response.json();

    if (response.ok && !result.errors) {
      Swal.fire({
        position: 'bottom-end',
        title: ' &#10004; Add product to branch success',
        showConfirmButton: false,
        timer: 1500,
        width: '25%',
        background: '#047857',
        didOpen: () => {
          const swalTitle = Swal.getTitle();
          if (swalTitle) {
            swalTitle.style.color = '#fff';
            swalTitle.style.fontSize = '15px';
          }

        }

      });
      load_branch_Table();
      loadWatingproductTable();

      overview(); // Refresh or reload UI if needed
    } else {
      Swal.fire({
        position: 'bottom-end',
        title: `❌ ${result.errors || "Something went wrong"}`,
        showConfirmButton: false,
        timer: 1500,
        width: '25%',
        background: '#800000',

      });
    }
  } catch (error) {
    Swal.fire({
      position: 'bottom-end',
      title: '❌ Server error',
      showConfirmButton: false,
      timer: 1500,
      width: '25%',
      background: '#800000',
      didOpen: () => {
        const swalTitle = Swal.getTitle();
        if (swalTitle) {
          swalTitle.style.color = '#fff';
          swalTitle.style.fontSize = '15px';
        }
      }
    });
    console.error("Fetch error:", error);
  }
}


async function products_in_branch(account_id) {
  try {
    // Get branch by account_id
    const branchRes = await fetch(`./assets/php/get-branch-by-account_id.php?account_id=${account_id}`);
    if (!branchRes.ok) throw new Error("Failed to fetch branch data");
    const branchData = await branchRes.json();

    const branch_id = branchData.branch_id;

    // Get products in the branch
    const productRes = await fetch(`./assets/php/get-products-by-branch_id.php?branch_id=${branch_id}`);
    if (!productRes.ok) throw new Error("Failed to fetch products in branch");
    const productData = await productRes.json();

    if (productData.status !== "success") {
      throw new Error("Failed to retrieve product data");
    }

    const products = productData.data;

    // Build HTML
    let html_return = "";
    if (products.length === 0) {
      html_return = `<tr><td colspan="5" class="text-center py-4">No products found in this branch.</td></tr>`;
    } else {
      html_return = products.map(product => `
        <tr class="border-b dark:border-gray-700">
          <th scope="row" class="px-4 py-3 font-medium text-black whitespace-nowrap">
              ${product.category_name}
          </th>
          <td class="px-4 py-3">${product.product_name}</td>
          <td class="px-4 py-3">${product.total_stock_quantity}</td>
          <td class="px-4 py-3">${product.product_condition}</td>
          <td class="px-4 py-3 hover:cursor-pointer" onclick="deleteBranchProduct(${product.branch_product_id},${account_id})">
              <i class="fa-solid fa-trash fa-xl" style="color: #a00808;"></i>
              <span style="color: #d61a1a;">Remove</span>
          </td>
        </tr>
      `).join('');
    }

    document.getElementById("Product_in_branch_list").innerHTML = html_return;

  } catch (error) {
    console.error("Error:", error.message);
    document.getElementById("Product_in_branch_list").innerHTML = `<tr><td colspan="5" class="text-center text-red-600 py-4">Error: ${error.message}</td></tr>`;
  }
}

async function deleteBranchProduct(branch_product_id, currentAccountId) {
  const result = await Swal.fire({
    title: "Are you sure?",
    text: "This action cannot be undone!",
    icon: "warning",
    showCancelButton: true,
    confirmButtonText: "Yes, delete it!",
    didOpen: () => {
      const confirmButton = Swal.getConfirmButton();
      if (confirmButton) confirmButton.style.backgroundColor = '#047857';
    }
  });

  if (result.isConfirmed) {
    const xhttp = new XMLHttpRequest();
    xhttp.open("POST", "./assets/php/delete-branch-product.php", true);
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

    xhttp.onreadystatechange = function () {
      if (xhttp.readyState === 4) {
        if (xhttp.status === 200) {
          try {
            const data = JSON.parse(xhttp.responseText);

            if (data.status === "success") {
              Swal.fire({
                position: 'bottom-end',
                title: +' &#10004; Product deleted successfully',
                showConfirmButton: false,
                timer: 1500,
                width: '25%',
                background: '#047857',
                didOpen: () => {
                  const swalTitle = Swal.getTitle();
                  if (swalTitle) {
                    swalTitle.style.color = '#fff';
                    swalTitle.style.fontSize = '15px';
                  }
                }
              });

              // Refresh the product list
              products_in_branch(currentAccountId);
              loadWatingproductTable();
              overview();
            } else {
              Swal.fire({
                icon: "error",
                title: "Error!",
                text: data.message || "Failed to delete product."
              });
            }
          } catch (err) {
            console.error("JSON parse error:", xhttp.responseText);
            Swal.fire({
              icon: "error",
              title: "Error!",
              text: "Invalid response from server."
            });
          }
        } else {
          console.error("Request failed:", xhttp.status, xhttp.statusText);
          Swal.fire({
            icon: "error",
            title: "Error!",
            text: "Server error while deleting product."
          });
        }
      }
    };

    xhttp.send(`branch_product_id=${encodeURIComponent(branch_product_id)}`);
  }
}






